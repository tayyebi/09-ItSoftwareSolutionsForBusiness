﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EUFA
{
    public partial class OrderedView : Masters.Father
    {
        public OrderedView()
        {
            InitializeComponent();
        }

        private void OrderedView_Load(object sender, EventArgs e)
        {

        }
    }
}
