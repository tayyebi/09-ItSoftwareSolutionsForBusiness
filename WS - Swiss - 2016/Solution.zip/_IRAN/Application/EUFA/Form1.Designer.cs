﻿namespace EUFA
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rexaButton3 = new EUFA.Components.RexaButton(this.components);
            this.rexaButton2 = new EUFA.Components.RexaButton(this.components);
            this.rexaButton1 = new EUFA.Components.RexaButton(this.components);
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.manageTournamentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageTeamsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageExecutionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rexaGrid1 = new EUFA.Components.RexaGrid(this.components);
            this.rexaGrid2 = new EUFA.Components.RexaGrid(this.components);
            this.rexaGrid3 = new EUFA.Components.RexaGrid(this.components);
            this.rexaGrid4 = new EUFA.Components.RexaGrid(this.components);
            this.rexaGrid5 = new EUFA.Components.RexaGrid(this.components);
            this.rexaGrid6 = new EUFA.Components.RexaGrid(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.rexaGrid7 = new EUFA.Components.RexaGrid(this.components);
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.rexaGrid8 = new EUFA.Components.RexaGrid(this.components);
            this.label11 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.rexaGrid9 = new EUFA.Components.RexaGrid(this.components);
            this.rexaGrid10 = new EUFA.Components.RexaGrid(this.components);
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.rexaGrid11 = new EUFA.Components.RexaGrid(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid11)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Font = new System.Drawing.Font("Tahoma", 8.75F);
            this.panel1.Location = new System.Drawing.Point(0, 24);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.panel1.Size = new System.Drawing.Size(884, 39);
            this.panel1.Controls.SetChildIndex(this.pictureBox1, 0);
            this.panel1.Controls.SetChildIndex(this.label1, 0);
            this.panel1.Controls.SetChildIndex(this.label2, 0);
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Tahoma", 15.75F);
            this.label1.Location = new System.Drawing.Point(32, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Size = new System.Drawing.Size(852, 25);
            this.label1.Text = "European Championship 2016";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.pictureBox1.Size = new System.Drawing.Size(32, 39);
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(32, 25);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(852, 14);
            this.label2.TabIndex = 2;
            this.label2.Text = "label2";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(143)))), ((int)(((byte)(164)))), ((int)(((byte)(59)))));
            this.panel2.Controls.Add(this.rexaButton3);
            this.panel2.Controls.Add(this.rexaButton2);
            this.panel2.Controls.Add(this.rexaButton1);
            this.panel2.Controls.Add(this.comboBox1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Font = new System.Drawing.Font("Tahoma", 6.75F);
            this.panel2.Location = new System.Drawing.Point(0, 546);
            this.panel2.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(884, 45);
            this.panel2.TabIndex = 1;
            // 
            // rexaButton3
            // 
            this.rexaButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton3.ForeColor = System.Drawing.Color.White;
            this.rexaButton3.Location = new System.Drawing.Point(480, 3);
            this.rexaButton3.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.rexaButton3.Name = "rexaButton3";
            this.rexaButton3.Size = new System.Drawing.Size(132, 32);
            this.rexaButton3.TabIndex = 2;
            this.rexaButton3.Text = "Manage Execution";
            this.rexaButton3.UseVisualStyleBackColor = false;
            this.rexaButton3.Click += new System.EventHandler(this.manageExecutionToolStripMenuItem_Click);
            // 
            // rexaButton2
            // 
            this.rexaButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton2.ForeColor = System.Drawing.Color.White;
            this.rexaButton2.Location = new System.Drawing.Point(343, 3);
            this.rexaButton2.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.rexaButton2.Name = "rexaButton2";
            this.rexaButton2.Size = new System.Drawing.Size(132, 32);
            this.rexaButton2.TabIndex = 2;
            this.rexaButton2.Text = "Manage Teams";
            this.rexaButton2.UseVisualStyleBackColor = false;
            this.rexaButton2.Click += new System.EventHandler(this.manageTeamsToolStripMenuItem_Click);
            // 
            // rexaButton1
            // 
            this.rexaButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton1.ForeColor = System.Drawing.Color.White;
            this.rexaButton1.Location = new System.Drawing.Point(207, 3);
            this.rexaButton1.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.rexaButton1.Name = "rexaButton1";
            this.rexaButton1.Size = new System.Drawing.Size(132, 32);
            this.rexaButton1.TabIndex = 2;
            this.rexaButton1.Text = "Manage Tournaments";
            this.rexaButton1.UseVisualStyleBackColor = false;
            this.rexaButton1.Click += new System.EventHandler(this.manageTournamentsToolStripMenuItem_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(78, 10);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(116, 19);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 14);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 11);
            this.label3.TabIndex = 0;
            this.label3.Text = "Tournament";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.manageToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(3, 1, 0, 1);
            this.menuStrip1.Size = new System.Drawing.Size(884, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 22);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // manageToolStripMenuItem1
            // 
            this.manageToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.manageTournamentsToolStripMenuItem,
            this.manageTeamsToolStripMenuItem,
            this.manageExecutionToolStripMenuItem});
            this.manageToolStripMenuItem1.Name = "manageToolStripMenuItem1";
            this.manageToolStripMenuItem1.Size = new System.Drawing.Size(62, 22);
            this.manageToolStripMenuItem1.Text = "Manage";
            // 
            // manageTournamentsToolStripMenuItem
            // 
            this.manageTournamentsToolStripMenuItem.Name = "manageTournamentsToolStripMenuItem";
            this.manageTournamentsToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.manageTournamentsToolStripMenuItem.Text = "Manage Tournaments";
            this.manageTournamentsToolStripMenuItem.Click += new System.EventHandler(this.manageTournamentsToolStripMenuItem_Click);
            // 
            // manageTeamsToolStripMenuItem
            // 
            this.manageTeamsToolStripMenuItem.Name = "manageTeamsToolStripMenuItem";
            this.manageTeamsToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.manageTeamsToolStripMenuItem.Text = "Manage Teams";
            this.manageTeamsToolStripMenuItem.Click += new System.EventHandler(this.manageTeamsToolStripMenuItem_Click);
            // 
            // manageExecutionToolStripMenuItem
            // 
            this.manageExecutionToolStripMenuItem.Name = "manageExecutionToolStripMenuItem";
            this.manageExecutionToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.manageExecutionToolStripMenuItem.Text = "Manage Execution";
            this.manageExecutionToolStripMenuItem.Click += new System.EventHandler(this.manageExecutionToolStripMenuItem_Click);
            // 
            // rexaGrid1
            // 
            this.rexaGrid1.AllowUserToAddRows = false;
            this.rexaGrid1.AllowUserToDeleteRows = false;
            this.rexaGrid1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid1.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid1.ColumnHeadersVisible = false;
            this.rexaGrid1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid1.GridColor = System.Drawing.Color.White;
            this.rexaGrid1.Location = new System.Drawing.Point(12, 307);
            this.rexaGrid1.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.rexaGrid1.MultiSelect = false;
            this.rexaGrid1.Name = "rexaGrid1";
            this.rexaGrid1.ReadOnly = true;
            this.rexaGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.rexaGrid1.RowHeadersVisible = false;
            this.rexaGrid1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.rexaGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid1.Size = new System.Drawing.Size(200, 63);
            this.rexaGrid1.TabIndex = 3;
            // 
            // rexaGrid2
            // 
            this.rexaGrid2.AllowUserToAddRows = false;
            this.rexaGrid2.AllowUserToDeleteRows = false;
            this.rexaGrid2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid2.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid2.ColumnHeadersVisible = false;
            this.rexaGrid2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid2.GridColor = System.Drawing.Color.White;
            this.rexaGrid2.Location = new System.Drawing.Point(12, 225);
            this.rexaGrid2.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.rexaGrid2.MultiSelect = false;
            this.rexaGrid2.Name = "rexaGrid2";
            this.rexaGrid2.ReadOnly = true;
            this.rexaGrid2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.rexaGrid2.RowHeadersVisible = false;
            this.rexaGrid2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.rexaGrid2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid2.Size = new System.Drawing.Size(200, 63);
            this.rexaGrid2.TabIndex = 3;
            // 
            // rexaGrid3
            // 
            this.rexaGrid3.AllowUserToAddRows = false;
            this.rexaGrid3.AllowUserToDeleteRows = false;
            this.rexaGrid3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid3.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid3.ColumnHeadersVisible = false;
            this.rexaGrid3.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid3.GridColor = System.Drawing.Color.White;
            this.rexaGrid3.Location = new System.Drawing.Point(218, 307);
            this.rexaGrid3.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.rexaGrid3.MultiSelect = false;
            this.rexaGrid3.Name = "rexaGrid3";
            this.rexaGrid3.ReadOnly = true;
            this.rexaGrid3.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.rexaGrid3.RowHeadersVisible = false;
            this.rexaGrid3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.rexaGrid3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid3.Size = new System.Drawing.Size(200, 63);
            this.rexaGrid3.TabIndex = 3;
            // 
            // rexaGrid4
            // 
            this.rexaGrid4.AllowUserToAddRows = false;
            this.rexaGrid4.AllowUserToDeleteRows = false;
            this.rexaGrid4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid4.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid4.ColumnHeadersVisible = false;
            this.rexaGrid4.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid4.GridColor = System.Drawing.Color.White;
            this.rexaGrid4.Location = new System.Drawing.Point(218, 225);
            this.rexaGrid4.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.rexaGrid4.MultiSelect = false;
            this.rexaGrid4.Name = "rexaGrid4";
            this.rexaGrid4.ReadOnly = true;
            this.rexaGrid4.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.rexaGrid4.RowHeadersVisible = false;
            this.rexaGrid4.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.rexaGrid4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid4.Size = new System.Drawing.Size(200, 63);
            this.rexaGrid4.TabIndex = 3;
            // 
            // rexaGrid5
            // 
            this.rexaGrid5.AllowUserToAddRows = false;
            this.rexaGrid5.AllowUserToDeleteRows = false;
            this.rexaGrid5.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid5.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid5.ColumnHeadersVisible = false;
            this.rexaGrid5.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid5.GridColor = System.Drawing.Color.White;
            this.rexaGrid5.Location = new System.Drawing.Point(425, 307);
            this.rexaGrid5.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.rexaGrid5.MultiSelect = false;
            this.rexaGrid5.Name = "rexaGrid5";
            this.rexaGrid5.ReadOnly = true;
            this.rexaGrid5.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.rexaGrid5.RowHeadersVisible = false;
            this.rexaGrid5.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.rexaGrid5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid5.Size = new System.Drawing.Size(200, 63);
            this.rexaGrid5.TabIndex = 3;
            // 
            // rexaGrid6
            // 
            this.rexaGrid6.AllowUserToAddRows = false;
            this.rexaGrid6.AllowUserToDeleteRows = false;
            this.rexaGrid6.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid6.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid6.ColumnHeadersVisible = false;
            this.rexaGrid6.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid6.GridColor = System.Drawing.Color.White;
            this.rexaGrid6.Location = new System.Drawing.Point(425, 225);
            this.rexaGrid6.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.rexaGrid6.MultiSelect = false;
            this.rexaGrid6.Name = "rexaGrid6";
            this.rexaGrid6.ReadOnly = true;
            this.rexaGrid6.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.rexaGrid6.RowHeadersVisible = false;
            this.rexaGrid6.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.rexaGrid6.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid6.Size = new System.Drawing.Size(200, 63);
            this.rexaGrid6.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(217, 208);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(204, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Group B";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(12, 208);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(200, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Group A";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(425, 208);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(200, 16);
            this.label6.TabIndex = 4;
            this.label6.Text = "Group C";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(12, 290);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(200, 16);
            this.label7.TabIndex = 4;
            this.label7.Text = "Group D";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(218, 290);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(200, 16);
            this.label8.TabIndex = 4;
            this.label8.Text = "Group E";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(425, 290);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(200, 16);
            this.label9.TabIndex = 4;
            this.label9.Text = "Group F";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rexaGrid7
            // 
            this.rexaGrid7.AllowUserToAddRows = false;
            this.rexaGrid7.AllowUserToDeleteRows = false;
            this.rexaGrid7.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid7.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid7.ColumnHeadersVisible = false;
            this.rexaGrid7.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid7.GridColor = System.Drawing.Color.White;
            this.rexaGrid7.Location = new System.Drawing.Point(12, 82);
            this.rexaGrid7.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.rexaGrid7.MultiSelect = false;
            this.rexaGrid7.Name = "rexaGrid7";
            this.rexaGrid7.ReadOnly = true;
            this.rexaGrid7.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.rexaGrid7.RowHeadersVisible = false;
            this.rexaGrid7.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.rexaGrid7.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid7.Size = new System.Drawing.Size(182, 116);
            this.rexaGrid7.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(12, 65);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(181, 16);
            this.label10.TabIndex = 4;
            this.label10.Text = "Round of 16";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(192, 82);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(63, 29);
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(192, 111);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(63, 29);
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Location = new System.Drawing.Point(192, 140);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(63, 29);
            this.pictureBox4.TabIndex = 5;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Location = new System.Drawing.Point(192, 169);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(63, 29);
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            // 
            // rexaGrid8
            // 
            this.rexaGrid8.AllowUserToAddRows = false;
            this.rexaGrid8.AllowUserToDeleteRows = false;
            this.rexaGrid8.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid8.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid8.ColumnHeadersVisible = false;
            this.rexaGrid8.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid8.GridColor = System.Drawing.Color.White;
            this.rexaGrid8.Location = new System.Drawing.Point(255, 82);
            this.rexaGrid8.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.rexaGrid8.MultiSelect = false;
            this.rexaGrid8.Name = "rexaGrid8";
            this.rexaGrid8.ReadOnly = true;
            this.rexaGrid8.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.rexaGrid8.RowHeadersVisible = false;
            this.rexaGrid8.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.rexaGrid8.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid8.Size = new System.Drawing.Size(106, 116);
            this.rexaGrid8.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(253, 65);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(104, 16);
            this.label11.TabIndex = 4;
            this.label11.Text = "Quarter-finals";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.BackgroundImage")));
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox6.Location = new System.Drawing.Point(361, 93);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(42, 38);
            this.pictureBox6.TabIndex = 5;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox7.BackgroundImage")));
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox7.Location = new System.Drawing.Point(361, 152);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(42, 46);
            this.pictureBox7.TabIndex = 5;
            this.pictureBox7.TabStop = false;
            // 
            // rexaGrid9
            // 
            this.rexaGrid9.AllowUserToAddRows = false;
            this.rexaGrid9.AllowUserToDeleteRows = false;
            this.rexaGrid9.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid9.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid9.ColumnHeadersVisible = false;
            this.rexaGrid9.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid9.GridColor = System.Drawing.Color.Black;
            this.rexaGrid9.Location = new System.Drawing.Point(402, 93);
            this.rexaGrid9.MultiSelect = false;
            this.rexaGrid9.Name = "rexaGrid9";
            this.rexaGrid9.ReadOnly = true;
            this.rexaGrid9.RowHeadersVisible = false;
            this.rexaGrid9.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.rexaGrid9.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid9.Size = new System.Drawing.Size(66, 38);
            this.rexaGrid9.TabIndex = 6;
            // 
            // rexaGrid10
            // 
            this.rexaGrid10.AllowUserToAddRows = false;
            this.rexaGrid10.AllowUserToDeleteRows = false;
            this.rexaGrid10.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid10.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid10.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid10.ColumnHeadersVisible = false;
            this.rexaGrid10.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid10.GridColor = System.Drawing.Color.Black;
            this.rexaGrid10.Location = new System.Drawing.Point(402, 151);
            this.rexaGrid10.MultiSelect = false;
            this.rexaGrid10.Name = "rexaGrid10";
            this.rexaGrid10.ReadOnly = true;
            this.rexaGrid10.RowHeadersVisible = false;
            this.rexaGrid10.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.rexaGrid10.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid10.Size = new System.Drawing.Size(66, 46);
            this.rexaGrid10.TabIndex = 6;
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(402, 77);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 16);
            this.label12.TabIndex = 4;
            this.label12.Text = "Semi-final";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox8.BackgroundImage")));
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox8.Location = new System.Drawing.Point(469, 93);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(42, 104);
            this.pictureBox8.TabIndex = 5;
            this.pictureBox8.TabStop = false;
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(402, 136);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(66, 16);
            this.label13.TabIndex = 4;
            this.label13.Text = "Semi-final";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(511, 107);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(109, 16);
            this.label14.TabIndex = 4;
            this.label14.Text = "Final";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rexaGrid11
            // 
            this.rexaGrid11.AllowUserToAddRows = false;
            this.rexaGrid11.AllowUserToDeleteRows = false;
            this.rexaGrid11.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid11.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid11.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid11.ColumnHeadersVisible = false;
            this.rexaGrid11.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid11.GridColor = System.Drawing.Color.Black;
            this.rexaGrid11.Location = new System.Drawing.Point(511, 123);
            this.rexaGrid11.MultiSelect = false;
            this.rexaGrid11.Name = "rexaGrid11";
            this.rexaGrid11.ReadOnly = true;
            this.rexaGrid11.RowHeadersVisible = false;
            this.rexaGrid11.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.rexaGrid11.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid11.Size = new System.Drawing.Size(109, 38);
            this.rexaGrid11.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(5F, 11F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 591);
            this.Controls.Add(this.rexaGrid7);
            this.Controls.Add(this.rexaGrid10);
            this.Controls.Add(this.rexaGrid11);
            this.Controls.Add(this.rexaGrid9);
            this.Controls.Add(this.rexaGrid6);
            this.Controls.Add(this.rexaGrid5);
            this.Controls.Add(this.rexaGrid4);
            this.Controls.Add(this.rexaGrid3);
            this.Controls.Add(this.rexaGrid8);
            this.Controls.Add(this.rexaGrid2);
            this.Controls.Add(this.rexaGrid1);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Tahoma", 6.75F);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MinimumSize = new System.Drawing.Size(900, 630);
            this.Name = "Form1";
            this.Text = "Tournoment Dashboard";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Controls.SetChildIndex(this.menuStrip1, 0);
            this.Controls.SetChildIndex(this.panel2, 0);
            this.Controls.SetChildIndex(this.label5, 0);
            this.Controls.SetChildIndex(this.label6, 0);
            this.Controls.SetChildIndex(this.label7, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.label9, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.label10, 0);
            this.Controls.SetChildIndex(this.label11, 0);
            this.Controls.SetChildIndex(this.label12, 0);
            this.Controls.SetChildIndex(this.label13, 0);
            this.Controls.SetChildIndex(this.label14, 0);
            this.Controls.SetChildIndex(this.pictureBox2, 0);
            this.Controls.SetChildIndex(this.pictureBox6, 0);
            this.Controls.SetChildIndex(this.pictureBox8, 0);
            this.Controls.SetChildIndex(this.pictureBox3, 0);
            this.Controls.SetChildIndex(this.pictureBox4, 0);
            this.Controls.SetChildIndex(this.pictureBox7, 0);
            this.Controls.SetChildIndex(this.pictureBox5, 0);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.rexaGrid1, 0);
            this.Controls.SetChildIndex(this.rexaGrid2, 0);
            this.Controls.SetChildIndex(this.rexaGrid8, 0);
            this.Controls.SetChildIndex(this.rexaGrid3, 0);
            this.Controls.SetChildIndex(this.rexaGrid4, 0);
            this.Controls.SetChildIndex(this.rexaGrid5, 0);
            this.Controls.SetChildIndex(this.rexaGrid6, 0);
            this.Controls.SetChildIndex(this.rexaGrid9, 0);
            this.Controls.SetChildIndex(this.rexaGrid11, 0);
            this.Controls.SetChildIndex(this.rexaGrid10, 0);
            this.Controls.SetChildIndex(this.rexaGrid7, 0);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid11)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private Components.RexaButton rexaButton2;
        private Components.RexaButton rexaButton1;
        private System.Windows.Forms.ComboBox comboBox1;
        private Components.RexaButton rexaButton3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageTournamentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageTeamsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageExecutionToolStripMenuItem;
        private Components.RexaGrid rexaGrid1;
        private Components.RexaGrid rexaGrid2;
        private Components.RexaGrid rexaGrid3;
        private Components.RexaGrid rexaGrid4;
        private Components.RexaGrid rexaGrid5;
        private Components.RexaGrid rexaGrid6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private Components.RexaGrid rexaGrid7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private Components.RexaGrid rexaGrid8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private Components.RexaGrid rexaGrid9;
        private Components.RexaGrid rexaGrid10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private Components.RexaGrid rexaGrid11;
    }
}

