﻿namespace EUFA
{
    partial class TeamCrud
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rexaButton4 = new EUFA.Components.RexaButton(this.components);
            this.rexaButton3 = new EUFA.Components.RexaButton(this.components);
            this.rexaButton2 = new EUFA.Components.RexaButton(this.components);
            this.rexaGrid1 = new EUFA.Components.RexaGrid(this.components);
            this.rexaButton1 = new EUFA.Components.RexaButton(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.rexaButton5 = new EUFA.Components.RexaButton(this.components);
            this.rexaButton6 = new EUFA.Components.RexaButton(this.components);
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Size = new System.Drawing.Size(520, 43);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(34, 0);
            this.label1.Size = new System.Drawing.Size(486, 43);
            this.label1.Text = "Father";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Size = new System.Drawing.Size(34, 43);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Team name";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(117, 59);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(266, 23);
            this.textBox1.TabIndex = 2;
            this.textBox1.TextChanged += new System.EventHandler(this.OnChange);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(268, 107);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(115, 24);
            this.comboBox1.TabIndex = 3;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(389, 59);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(110, 39);
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rexaButton4);
            this.groupBox1.Controls.Add(this.rexaButton3);
            this.groupBox1.Controls.Add(this.rexaButton2);
            this.groupBox1.Controls.Add(this.rexaGrid1);
            this.groupBox1.Location = new System.Drawing.Point(37, 136);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(462, 325);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Players (0)";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // rexaButton4
            // 
            this.rexaButton4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton4.ForeColor = System.Drawing.Color.White;
            this.rexaButton4.Location = new System.Drawing.Point(346, 90);
            this.rexaButton4.Name = "rexaButton4";
            this.rexaButton4.Size = new System.Drawing.Size(110, 28);
            this.rexaButton4.TabIndex = 6;
            this.rexaButton4.Text = "Delete";
            this.rexaButton4.UseVisualStyleBackColor = false;
            this.rexaButton4.Click += new System.EventHandler(this.rexaButton4_Click);
            // 
            // rexaButton3
            // 
            this.rexaButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton3.ForeColor = System.Drawing.Color.White;
            this.rexaButton3.Location = new System.Drawing.Point(346, 56);
            this.rexaButton3.Name = "rexaButton3";
            this.rexaButton3.Size = new System.Drawing.Size(110, 28);
            this.rexaButton3.TabIndex = 6;
            this.rexaButton3.Text = "Edit";
            this.rexaButton3.UseVisualStyleBackColor = false;
            this.rexaButton3.Click += new System.EventHandler(this.rexaButton3_Click);
            // 
            // rexaButton2
            // 
            this.rexaButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton2.ForeColor = System.Drawing.Color.White;
            this.rexaButton2.Location = new System.Drawing.Point(346, 22);
            this.rexaButton2.Name = "rexaButton2";
            this.rexaButton2.Size = new System.Drawing.Size(110, 28);
            this.rexaButton2.TabIndex = 6;
            this.rexaButton2.Text = "Add";
            this.rexaButton2.UseVisualStyleBackColor = false;
            this.rexaButton2.Click += new System.EventHandler(this.rexaButton2_Click);
            // 
            // rexaGrid1
            // 
            this.rexaGrid1.AllowUserToAddRows = false;
            this.rexaGrid1.AllowUserToDeleteRows = false;
            this.rexaGrid1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid1.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid1.Dock = System.Windows.Forms.DockStyle.Left;
            this.rexaGrid1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid1.GridColor = System.Drawing.Color.Black;
            this.rexaGrid1.Location = new System.Drawing.Point(3, 19);
            this.rexaGrid1.MultiSelect = false;
            this.rexaGrid1.Name = "rexaGrid1";
            this.rexaGrid1.ReadOnly = true;
            this.rexaGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid1.Size = new System.Drawing.Size(337, 303);
            this.rexaGrid1.TabIndex = 0;
            // 
            // rexaButton1
            // 
            this.rexaButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton1.ForeColor = System.Drawing.Color.White;
            this.rexaButton1.Location = new System.Drawing.Point(389, 104);
            this.rexaButton1.Name = "rexaButton1";
            this.rexaButton1.Size = new System.Drawing.Size(110, 28);
            this.rexaButton1.TabIndex = 6;
            this.rexaButton1.Text = "Select flag";
            this.rexaButton1.UseVisualStyleBackColor = false;
            this.rexaButton1.Click += new System.EventHandler(this.rexaButton1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Country Code";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(215, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "Region";
            // 
            // rexaButton5
            // 
            this.rexaButton5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton5.ForeColor = System.Drawing.Color.White;
            this.rexaButton5.Location = new System.Drawing.Point(389, 467);
            this.rexaButton5.Name = "rexaButton5";
            this.rexaButton5.Size = new System.Drawing.Size(110, 28);
            this.rexaButton5.TabIndex = 6;
            this.rexaButton5.Text = "Close";
            this.rexaButton5.UseVisualStyleBackColor = false;
            this.rexaButton5.Click += new System.EventHandler(this.rexaButton5_Click);
            // 
            // rexaButton6
            // 
            this.rexaButton6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton6.Enabled = false;
            this.rexaButton6.ForeColor = System.Drawing.Color.White;
            this.rexaButton6.Location = new System.Drawing.Point(273, 467);
            this.rexaButton6.Name = "rexaButton6";
            this.rexaButton6.Size = new System.Drawing.Size(110, 28);
            this.rexaButton6.TabIndex = 6;
            this.rexaButton6.Text = "Save and Close";
            this.rexaButton6.UseVisualStyleBackColor = false;
            this.rexaButton6.Click += new System.EventHandler(this.rexaButton6_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(117, 107);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(92, 23);
            this.textBox2.TabIndex = 2;
            this.textBox2.TextChanged += new System.EventHandler(this.OnChange);
            // 
            // TeamCrud
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(520, 520);
            this.Controls.Add(this.rexaButton6);
            this.Controls.Add(this.rexaButton5);
            this.Controls.Add(this.rexaButton1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "TeamCrud";
            this.Text = "Add/Edit Team";
            this.Load += new System.EventHandler(this.TeamCrud_Load);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.textBox1, 0);
            this.Controls.SetChildIndex(this.textBox2, 0);
            this.Controls.SetChildIndex(this.comboBox1, 0);
            this.Controls.SetChildIndex(this.pictureBox2, 0);
            this.Controls.SetChildIndex(this.groupBox1, 0);
            this.Controls.SetChildIndex(this.rexaButton1, 0);
            this.Controls.SetChildIndex(this.rexaButton5, 0);
            this.Controls.SetChildIndex(this.rexaButton6, 0);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private Components.RexaButton rexaButton1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private Components.RexaButton rexaButton4;
        private Components.RexaButton rexaButton3;
        private Components.RexaButton rexaButton2;
        private Components.RexaGrid rexaGrid1;
        private Components.RexaButton rexaButton5;
        private Components.RexaButton rexaButton6;
        private System.Windows.Forms.TextBox textBox2;
    }
}