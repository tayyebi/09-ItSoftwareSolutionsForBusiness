﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EUFA
{
    public partial class EditGame : Masters.Father
    {
        public EditGame()
        {
            InitializeComponent();
        }

        public Models.Result MyGameResult { get; set; }

        public void MyRefresh()
        {


            //db = new Models.MainModel();

            if (MyGameResult.Status == "Finished" || MyGameResult.Status == "Running")
            {
                rexaButton2.Enabled =
                rexaButton3.Enabled =
                rexaButton4.Enabled =
                rexaButton5.Enabled =
                false;
            }

            if (MyGameResult.Status == "Finished")
            {
                checkBox1.Checked = true;
                checkBox2.Checked = true;
                checkBox2.Enabled = true;
                checkBox1.Enabled = false;
            }
            else if (MyGameResult.Status == "Running")
            {
                tabControl1.SelectedIndex = 1;
                panel2.Enabled = true;
                checkBox1.Checked = true;
                checkBox2.Checked = false;
                checkBox2.Enabled = true;
            }
            else if (MyGameResult.Status == "Scheduled")
            {
                checkBox1.Checked = false;
                checkBox2.Checked = false;
                panel2.Enabled = false;
            }
            label1.Text = "Result " + MyGameResult.TeamAlfaName + " - " + MyGameResult.TeamBetaName + " " + MyGameResult.Results;
            label2.Text = "Team " + MyGameResult.TeamAlfaName;
            label3.Text = "Team " + MyGameResult.TeamBetaName;

            rexaGrid1.DataSource = db.PlayerGames
                //.Local
                .Where(x => x.team_id == MyGameResult.TeamAlfaId && x.GameId == MyGameResult.GameId)
                .Select(x => new { x.GameId, x.PlayerId, x.TeamId, Name = x.firstname, Surname = x.lastname, Position = x.PositionOn })
                .OrderBy(x => x.Surname)
                .ToList();

            rexaGrid2.DataSource = db.PlayerGames
                //.Local
                .Where(x => x.team_id == MyGameResult.TeamBetaId && x.GameId == MyGameResult.GameId)
                .Select(x => new { x.GameId, x.PlayerId, x.TeamId, Name = x.firstname, Surname = x.lastname, Position = x.PositionOn })
                .OrderBy(x => x.Surname)
                .ToList();


            rexaGrid1.Columns[0].Visible = false;
            rexaGrid1.Columns[1].Visible = false;
            rexaGrid1.Columns[2].Visible = false;
            rexaGrid2.Columns[0].Visible = false;
            rexaGrid2.Columns[2].Visible = false;
            rexaGrid2.Columns[1].Visible = false;






            // Events


            rexaGrid3.DataSource = (

                from a in db.Events


                join b in db.Teams
                on a.TeamId equals b.id

                select new
                {
                    ID = a.Id,
                    Min = a.Minute,
                    Team = b.name,
                    Event = a.Name,
                    AddInf = a.Info
                }

                )
                .OrderBy(x => x.Min)
                .ToList();

            rexaGrid3.Columns["Id"].Visible = false;
            rexaGrid3.Columns["Min"].HeaderText = "Min.";
            rexaGrid3.Columns["AddInf"].HeaderText = "Additional Information";
        }


        private void EditGame_Load(object sender, EventArgs e)
        {
            db.PlayerGames.ToList();
            db.Players.ToList();
            db.Positions.ToList();
            MyRefresh();
        }

        private void rexaButton7_Click(object sender, EventArgs e)
        {

        }

        private void rexaButton7_Click_1(object sender, EventArgs e)
        {
            Close();
        }

        private void rexaButton1_Click(object sender, EventArgs e)
        {
            var this_game = db.Games.Where(x => x.Id == MyGameResult.GameId).FirstOrDefault();

            if (checkBox1.Checked)
            {

                var playersAlfa =
                db.PlayerGames
                .Where(x => x.team_id == MyGameResult.TeamAlfaId &&
                x.GameId == MyGameResult.GameId);

                var playersBeta =
                db.PlayerGames
                .Where(x => x.team_id == MyGameResult.TeamBetaId &&
                x.GameId == MyGameResult.GameId);

                if (!(playersAlfa.Count() == 11 && playersAlfa.Where(x => x.PositionOn == "Goalkeeper").Count() == 1
                    && playersBeta.Count() == 11 && playersBeta.Where(x => x.PositionOn == "Goalkeeper").Count() == 1
                    ))

                {
                    MessageBox.Show("There must be 11 players in each team starting grid which exactly contains 1 goalkeeper.");
                    return;
                }

                this_game.Status = "Running";

            }
            if (checkBox2.Checked)
                this_game.Status = "Finished";
            if (!checkBox1.Checked && !checkBox2.Checked)
                this_game.Status = "Scheduled";

            this_game.TeamAlfaGoals = (short)db.Events.Where(x => x.Name == "Goal" && x.TeamId == MyGameResult.TeamAlfaId).Count();
            this_game.TeamBetaGoals = (short)db.Events.Where(x => x.Name == "Goal" && x.TeamId == MyGameResult.TeamBetaGoals).Count();

            this_game.WinnerPoints = (this_game.TeamAlfaGoals == this_game.TeamBetaGoals) ? 1 : 3;

            db.SaveChanges();
            Close();
        }

        private void rexaButton2_Click(object sender, EventArgs e)
        {
            var frm = new AddPlayer
            {
                MyGameId = MyGameResult.GameId,
                MyTeamId = (int)MyGameResult.TeamAlfaId
            };
            frm.label2.Text = label2.Text;
            frm.ShowDialog();
            MyRefresh();
        }

        private void rexaButton4_Click(object sender, EventArgs e)
        {
            var frm = new AddPlayer
            {
                MyGameId = MyGameResult.GameId,
                MyTeamId = (int)MyGameResult.TeamBetaId
            };

            frm.label2.Text = label3.Text;
            frm.ShowDialog();
            MyRefresh();
        }

        private void rexaButton3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure to delete this player from starting grid?", "WARNING!", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {

                int teamId = Convert.ToInt32(rexaGrid1.SelectedRows[0].Cells["TeamId"].Value);
                int playerId = Convert.ToInt32(rexaGrid1.SelectedRows[0].Cells["PlayerId"].Value);
                int gameId = Convert.ToInt32(rexaGrid1.SelectedRows[0].Cells["GameId"].Value);

                var g = db.Grids.Where(x => x.TeamId == teamId
                && x.PlayerId == playerId
                && x.GameId == gameId);

                db.Grids.RemoveRange(g);
                db.SaveChanges();
                MyRefresh();
            }
        }

        private void rexaButton5_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure to delete this player from starting grid?", "WARNING!", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {

                int teamId = Convert.ToInt32(rexaGrid2.SelectedRows[0].Cells["TeamId"].Value);
                int playerId = Convert.ToInt32(rexaGrid2.SelectedRows[0].Cells["PlayerId"].Value);
                int gameId = Convert.ToInt32(rexaGrid2.SelectedRows[0].Cells["GameId"].Value);

                var g = db.Grids.Where(x => x.TeamId == teamId
                && x.PlayerId == playerId
                && x.GameId == gameId);

                db.Grids.RemoveRange(g);
                db.SaveChanges();
                MyRefresh();
            }
        }

        private void rexaButton9_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure to delete this record?", "WARNING!", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                int id = Convert.ToInt32(rexaGrid3.SelectedRows[0].Cells["ID"].Value);
                var record = db.Events.Find(id);
                db.Events.Remove(record);
                db.SaveChanges();
                MyRefresh();

            }
        }

        private void rexaButton6_Click(object sender, EventArgs e)
        {
            var frm = new AddEditEvent();
            frm.Game = MyGameResult;
            frm.radioButton1.Text = MyGameResult.TeamAlfaName;
            frm.radioButton2.Text = MyGameResult.TeamBetaName;
            frm.ShowDialog();
            MyRefresh();
        }

        private void rexaButton8_Click(object sender, EventArgs e)
        {
            var frm = new AddEditEvent();
            frm.Game = MyGameResult;
            int id = Convert.ToInt32(rexaGrid3.SelectedRows[0].Cells["ID"].Value);
            var record = db.Events.Find(id);
            frm.MyProperty = record;
            frm.radioButton1.Text = MyGameResult.TeamAlfaName;
            frm.radioButton2.Text = MyGameResult.TeamBetaName;
            frm.ShowDialog();
            MyRefresh();

        }
    }
}
