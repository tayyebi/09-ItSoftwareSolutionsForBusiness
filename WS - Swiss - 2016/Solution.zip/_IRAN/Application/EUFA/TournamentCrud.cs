﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EUFA
{
    public partial class TournamentCrud : Masters.Father
    {

        public Models.Tournament MyProperty { get; set; }
        public TournamentCrud()
        {
            InitializeComponent();
        }

        private void TournamentCrud_Load(object sender, EventArgs e)
        {

            foreach (var item in db.Regions)
            {

                var t = new RadioButton { Text = item.region1, Name = "Region_" + item.Id, Dock = DockStyle.Top };
                t.CheckedChanged += delegate
                {
                    if (t.Checked == true)
                    {
                        dataGridView1.Columns.Clear();

                        string _id = t.Name.Substring(7, t.Name.Length - 7);
                        int id = int.Parse(_id);
                        dataGridView1.DataSource = (
                        from a in db.Teams

                        where a.region == id

                        select new
                        {
                            a.id,
                            Team = a.name
                        }

                        ).ToList();
                        dataGridView1.Columns[0].Visible = false;
                        dataGridView1.Columns.Add(new DataGridViewCheckBoxColumn
                        {
                            HeaderText = "Participation",
                            DisplayIndex = 0,
                            ReadOnly = false,
                        });
                    }
                };
                groupBox1.Controls.Add(t);
            }

            if (MyProperty == null)
                return;

            textBox1.Text = MyProperty.name;
            //dateTimePicker1.CustomFormat = dateTimePicker2.CustomFormat = "dd/MM/yyyy";
            //dateTimePicker1.Value = Convert.ToDateTime(MyProperty.start_date );
            //dateTimePicker2.Value = DateTime.Parse(MyProperty.end_date);

            dateTimePicker1.Value = DateTime.Now;
            dateTimePicker2.Value = DateTime.Now.AddMonths(1);

        }

        private void rexaButton2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void rexaButton1_Click(object sender, EventArgs e)
        {

            if (teamIds.Count != 24)
            {
                MessageBox.Show("You must select exactly 24 teams");
                return;
            }


            if (dateTimePicker1.Value > dateTimePicker2.Value)
            {
                MessageBox.Show("Please enter valid dates.");
                return;
            }


            int tourid;

            if (MyProperty == null)
            {
                var tour = new Models.Tournament
                {
                    name = textBox1.Text,
                    start_date = dateTimePicker1.Value.ToString("dd/MM/yyyy"),
                    end_date = dateTimePicker2.Value.ToString("dd/MM/yyyy")
                };
                db.Tournaments.Add(tour);
                db.SaveChanges();
                tourid = tour.Id;
            }
            else
            {
                var tour = db.Tournaments.Find(MyProperty.Id);

                tour.name = textBox1.Text;
                tour.start_date = dateTimePicker1.Value.ToString("dd/MM/yyyy");
                tour.end_date = dateTimePicker2.Value.ToString("dd/MM/yyyy");

                db.Tournaments.Attach(tour);
                db.Entry(tour).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                tourid = tour.Id;
            }

            foreach (var item in teamIds)
            {
                db.Participates.Add(new Models.Participate
                {
                    TeamId = item,
                    TournamentId = tourid
                });
            }
            db.SaveChanges();

            Close();
        }

        private void OnChange(object sender, EventArgs e)
        {
            if (textBox1.Text != string.Empty)
            {

                rexaButton1.Enabled = true;
            }
        }

        List<int> teamIds = new List<int>();

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 2)
            {
                //var val = dataGridView1.Rows[e.RowIndex].Cells[2] as DataGridViewCheckBoxCell;
                var teamId = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value);
                if (teamIds.Where(x => x == teamId).Count() == 0)
                    teamIds.Add(teamId);
                else
                    teamIds.Remove(teamId);

                label6.Text = teamIds.Count() + " / 24";

                //var state = if ()
                // (dataGridView1.Rows[e.RowIndex].Cells[1] as  DataGridViewCheckBoxCell). = .c
            }
        }
    }
}