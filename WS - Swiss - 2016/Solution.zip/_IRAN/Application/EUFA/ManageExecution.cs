﻿using EUFA.Components;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EUFA
{
    public partial class ManageExecution : Masters.Father
    {
        public ManageExecution()
        {
            InitializeComponent();
        }
        bool allocate = true;
        public void MyRefresh()
        {
            if (db.Games.Where(x => x.TournamentId == Program.SelectedTournament).Count() != 0)
            {
                label4.Text = "Yes";
                rexaButton2.Enabled = true;
                allocate = false;
            }


            if (db.Games.Where(x => x.TournamentId == Program.SelectedTournament).Where(y => y.Level == "24" && y.Status == "Finished").Count() == 36 &&
                   db.Games.Where(x => x.TournamentId == Program.SelectedTournament).Where(y => y.Level == "24").Count() != 0)
            {
                label5.Text = "Yes";
                rexaButton3.Enabled = true;


                if (db.Games.Where(x => x.TournamentId == Program.SelectedTournament).Where(y => y.Level == "16" && y.Status == "Finished").Count()
                    == db.Games.Where(x => x.TournamentId == Program.SelectedTournament).Where(y => y.Level == "16").Count()
                    &&
                   db.Games.Where(x => x.TournamentId == Program.SelectedTournament).Where(y => y.Level == "16").Count() != 0)
                {
                    label6.Text = "Yes";
                    rexaButton4.Enabled = true;



                    if (db.Games.Where(x => x.TournamentId == Program.SelectedTournament).Where(y => y.Level == "8" && y.Status == "Finished").Count() == db.Games.Where(x => x.TournamentId == Program.SelectedTournament).Where(y => y.Level == "8").Count() &&
                   db.Games.Where(x => x.TournamentId == Program.SelectedTournament).Where(y => y.Level == "8").Count() != 0)
                    {
                        label7.Text = "Yes";
                        rexaButton5.Enabled = true;

                        if (db.Games.Where(x => x.TournamentId == Program.SelectedTournament).Where(y => y.Level == "4" && y.Status == "Finished").Count() == db.Games.Where(x => x.TournamentId == Program.SelectedTournament).Where(y => y.Level == "8").Count() &&
                   db.Games.Where(x => x.TournamentId == Program.SelectedTournament).Where(y => y.Level == "8").Count() != 0)
                        {
                            label8.Text = "Yes";
                            rexaButton6.Enabled = true;

                            if (db.Games.Where(x => x.TournamentId == Program.SelectedTournament).Where(y => y.Level == "2" && y.Status == "Finished").Count() == db.Games.Where(x => x.TournamentId == Program.SelectedTournament).Where(y => y.Level == "8").Count() &&
                   db.Games.Where(x => x.TournamentId == Program.SelectedTournament).Where(y => y.Level == "2").Count() != 0)
                            {
                                label7.Text = "Yes";
                                rexaButton5.Enabled = true;

                                if (db.Games.Where(x => x.TournamentId == Program.SelectedTournament).Where(y => y.Level == "1" && y.Status == "Finished").Count() == 1)
                                {
                                    label8.Text = "Yes";
                                }
                            }
                        }
                    }
                }
            }
        }

        private void ManageExecution_Load(object sender, EventArgs e)
        {
            MyRefresh();
        }

        private void rexaButton7_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void rexaButton1_Click(object sender, EventArgs e)
        {
            Hide();
            var frm = new AllocateTeams();
            frm.rexaButton2.Enabled = allocate;
            frm.ShowDialog();
            Show();
            MyRefresh();
        }

        private void Manage_Click(object sender, EventArgs e)
        {
            var frm = new ManageGames();

            frm.Text = (sender as RexaButton).Text;


            if ((sender as RexaButton).Text == "Manage Group Stage Games...")
            {
                frm.MyLevel = "24";
                frm.rexaButton1.Text = "Finish Group Stage";
            }
            else if ((sender as RexaButton).Text == "Manage Round 16 Games...")
            {
                frm.MyLevel = "16";
                frm.rexaButton1.Text = "Finish Round 16";
            }
            else if ((sender as RexaButton).Text == "Manage Quarter-Final Games...")
            {
                frm.MyLevel = "4";
                frm.rexaButton1.Text = "Finish Quarter-Final";
            }
            else if ((sender as RexaButton).Text == "Manage Semi-Final Games...")
            {
                frm.MyLevel = "2";
                frm.rexaButton1.Text = "Finish Semi-Final";
            }
            else if ((sender as RexaButton).Text == "Manage Final Games...")
            {
                frm.MyLevel = "1";
                frm.rexaButton1.Text = "Finish Final";
            }

            frm.ShowDialog();
            MyRefresh();
        }
    }
}
