﻿using EUFA.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EUFA.Masters
{
    public partial class Father : Form
    {
       public MainModel db = new MainModel();
        public Father()
        {
            InitializeComponent();
        }

        private void Father_Load(object sender, EventArgs e)
        {
            label1.Text = Text;

        }
    }
}
