﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EUFA
{
    public partial class ManageTeams : Masters.Father
    {
        public ManageTeams()
        {
            InitializeComponent();
        }
        public void MyRefresh()
        {
            File.ReadAllBytes("flags\\" + "bulgaria.png");
            var query = db.Teams
                .Where(x => x.name.ToUpper().Contains(textBox1.Text.ToUpper()) ||
                textBox1.Text == string.Empty
                )
                .ToList().Select(a => new
                {
                    Id = a.id,
                    Flag = File.ReadAllBytes("flags\\" + (a.flag_url ?? "default.png")),
                    Team = a.name,
                    Code = a.countrycode
                }).ToList();




            rexaGrid1.DataSource = query;

            foreach (DataGridViewRow row in rexaGrid1.Rows)
            {
                (row.Cells["Flag"] as DataGridViewImageCell).ImageLayout = DataGridViewImageCellLayout.Zoom;
            }

        }
        private void ManageTeams_Load(object sender, EventArgs e)
        {
            MyRefresh();


        }

        private void rexaButton4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            MyRefresh();
        }

        private void rexaButton1_Click(object sender, EventArgs e)
        {
            new TeamCrud().ShowDialog();
            MyRefresh();
        }

        private void rexaButton3_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(rexaGrid1.SelectedRows[0].Cells[0].Value);
            if (db.Participates.Where(x => x.TeamId == id).Count() != 0)
            {
                MessageBox.Show("This team shouldn't be participted in a tournament");
                return;
            }
            if (MessageBox.Show("Are you sure to delete this item?", "WARNING", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                var team = db.Teams.Find(id);
                db.Teams.Remove(team);
                db.SaveChanges();
                MyRefresh();
            }
        }

        private void rexaButton2_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(rexaGrid1.SelectedRows[0].Cells[0].Value);
            var team = db.Teams.Find(id);
            new TeamCrud { MyProperty = team }.ShowDialog();
            MyRefresh();
        }
    }
}
