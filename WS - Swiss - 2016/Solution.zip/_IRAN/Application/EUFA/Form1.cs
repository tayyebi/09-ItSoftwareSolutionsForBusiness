﻿using EUFA.Components;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EUFA
{
    public partial class Form1 : Masters.Father
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {


            comboBox1.ValueMember = "Id";
            comboBox1.DisplayMember = "name";
            comboBox1.DataSource = db.Tournaments.ToList();




        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void manageTournamentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Hide();
            new ManageTournaments().ShowDialog();
            Show();
        }

        private void manageTeamsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Hide();
            new ManageTeams().ShowDialog();
            Show();

        }

        private void manageExecutionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Hide();
            new ManageExecution().ShowDialog();
            Show();

        }


        private void MyMethod1(string level, string group, RexaGrid grid)
        {

            //new Thread(new ThreadStart(() =>
            //{
                var query1 = db.Results.Local.Where(x => x.Level == level && x.Group == group).ToList().Select(x => new { x.TeamAlfaName, f_a = File.ReadAllBytes("flags\\" + (x.TeamAlfaFlagUrl ?? "default.png")), x.Results, f_b = File.ReadAllBytes("flags\\" + (x.TeamBetaFlagUrl ?? "default.png")), x.TeamBetaName }).ToList();
                grid.RowTemplate.Height = grid.Height / query1.Count;

                //this.Invoke((MethodInvoker)delegate ()
                //{
                    grid.DataSource = query1;
                    foreach (DataGridViewRow row in grid.Rows)
                    {
                        (row.Cells["f_a"] as DataGridViewImageCell).ImageLayout = DataGridViewImageCellLayout.Zoom;
                        (row.Cells["f_b"] as DataGridViewImageCell).ImageLayout = DataGridViewImageCellLayout.Zoom;
                    }
            //    });
            //})).Start();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            db.Results.ToList();



            rexaGrid1.DataSource =
            rexaGrid2.DataSource =
            rexaGrid3.DataSource =
            rexaGrid4.DataSource =
            rexaGrid5.DataSource =
            rexaGrid6.DataSource =
            rexaGrid7.DataSource =
            rexaGrid8.DataSource =
            rexaGrid9.DataSource =
            rexaGrid10.DataSource =
            rexaGrid11.DataSource =
            new List<Models.Result>();



            int d = Convert.ToInt32(comboBox1.SelectedValue);
            var tour = db.Tournaments.Find(d);
            label1.Text = tour.name;
            label2.Text = tour.start_date + " " + tour.end_date;
            Program.SelectedTournament = d;

            if (db.Games.Where(x => x.TournamentId == Program.SelectedTournament && x.Level == "24").Count() < 36)
                return;


            MyMethod1("24", "A", rexaGrid2);
            MyMethod1("24", "B", rexaGrid4);
            MyMethod1("24", "C", rexaGrid6);
            MyMethod1("24", "D", rexaGrid1);
            MyMethod1("24", "E", rexaGrid3);
            MyMethod1("24", "F", rexaGrid5);

            if (db.Games.Where(x => x.TournamentId == Program.SelectedTournament && x.Level == "16").Count() < 8)
                return;

            MyMethod1("16", "A", rexaGrid7);




        }
    }
}
