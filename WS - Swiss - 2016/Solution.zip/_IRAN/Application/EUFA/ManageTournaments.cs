﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EUFA
{
    public partial class ManageTournaments : Masters.Father
    {
        public ManageTournaments()
        {
            InitializeComponent();
        }

        private void ManageTournaments_Load(object sender, EventArgs e)
        {
            MyRefresh();
        }

        private void MyRefresh()
        {
            rexaGrid1.DataSource = (
                from a in db.Tournaments

                select new
                {
                    Id = a.Id,
                    Tournament = a.name,
                    Date = a.start_date + " - " + a.end_date
                }
                ).ToList();
        }

        private void rexaButton4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void rexaButton1_Click(object sender, EventArgs e)
        {
            new TournamentCrud().ShowDialog();
            MyRefresh();
        }

        private void rexaButton3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure to delete this item?", "WARNING!", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                var id = Convert.ToInt32(rexaGrid1.SelectedRows[0].Cells["Id"].Value);
                var tour = db.Tournaments.Find(id);
                db.Tournaments.Remove(tour);
                db.SaveChanges();
                MyRefresh();
            }

        }

        private void rexaButton2_Click(object sender, EventArgs e)
        {
            var id = Convert.ToInt32(rexaGrid1.SelectedRows[0].Cells["Id"].Value);
            var tour = db.Tournaments.Find(id);
            var frm = new TournamentCrud();
            frm.MyProperty = tour;
            frm.ShowDialog();
            MyRefresh();
        }
    }
}
