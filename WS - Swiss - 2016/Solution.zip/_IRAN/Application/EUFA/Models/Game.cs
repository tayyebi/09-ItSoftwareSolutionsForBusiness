namespace EUFA.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Game
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Game()
        {
            Events = new HashSet<Event>();
            Grids = new HashSet<Grid>();
        }

        public long Id { get; set; }

        [Required]
        [StringLength(1)]
        public string Group { get; set; }

        [Required]
        [StringLength(2)]
        public string Level { get; set; }

        public int TeamAlfaId { get; set; }

        public int TeamBetaId { get; set; }

        public short TeamAlfaGoals { get; set; }

        public short TeamBetaGoals { get; set; }

        [Required]
        [StringLength(10)]
        public string Status { get; set; }

        public int TournamentId { get; set; }

        public int TeamAlfaScores { get; set; }

        public int TeamBetaScores { get; set; }

        public int? WinnerId { get; set; }

        public int WinnerPoints { get; set; }

        public int TeamAlfaPenalty { get; set; }

        public int TeamBetaPenalty { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Event> Events { get; set; }

        public virtual Team Team { get; set; }

        public virtual Team Team1 { get; set; }

        public virtual Tournament Tournament { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Grid> Grids { get; set; }
    }
}
