namespace EUFA.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Event
    {
        public long Id { get; set; }

        public long GameId { get; set; }

        [Required]
        [StringLength(300)]
        public string Name { get; set; }

        [StringLength(4000)]
        public string Info { get; set; }

        public short Minute { get; set; }

        public int TeamId { get; set; }

        public virtual Game Game { get; set; }
    }
}
