namespace EUFA.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class MainModel : DbContext
    {
        public MainModel()
            : base("name=MainModel")
        {
        }

        public virtual DbSet<Event> Events { get; set; }
        public virtual DbSet<Game> Games { get; set; }
        public virtual DbSet<Grid> Grids { get; set; }
        public virtual DbSet<Participate> Participates { get; set; }
        public virtual DbSet<Player> Players { get; set; }
        public virtual DbSet<Position> Positions { get; set; }
        public virtual DbSet<Region> Regions { get; set; }
        public virtual DbSet<sysdiagram> sysdiagrams { get; set; }
        public virtual DbSet<Team> Teams { get; set; }
        public virtual DbSet<Tournament> Tournaments { get; set; }
        public virtual DbSet<PlayerGame> PlayerGames { get; set; }
        public virtual DbSet<Result> Results { get; set; }
        public virtual DbSet<TeamTournament> TeamTournaments { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Game>()
                .Property(e => e.Group)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Game>()
                .Property(e => e.Level)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Game>()
                .Property(e => e.Status)
                .IsUnicode(false);

            modelBuilder.Entity<Game>()
                .HasMany(e => e.Events)
                .WithRequired(e => e.Game)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Game>()
                .HasMany(e => e.Grids)
                .WithRequired(e => e.Game)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Player>()
                .HasMany(e => e.Grids)
                .WithRequired(e => e.Player)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Position>()
                .HasMany(e => e.Grids)
                .WithRequired(e => e.Position)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Position>()
                .HasMany(e => e.Players)
                .WithOptional(e => e.Position1)
                .HasForeignKey(e => e.position);

            modelBuilder.Entity<Region>()
                .HasMany(e => e.Teams)
                .WithOptional(e => e.Region1)
                .HasForeignKey(e => e.region);

            modelBuilder.Entity<Team>()
                .HasMany(e => e.Games)
                .WithRequired(e => e.Team)
                .HasForeignKey(e => e.TeamAlfaId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Team>()
                .HasMany(e => e.Games1)
                .WithRequired(e => e.Team1)
                .HasForeignKey(e => e.TeamBetaId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Team>()
                .HasMany(e => e.Grids)
                .WithRequired(e => e.Team)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Team>()
                .HasMany(e => e.Participates)
                .WithRequired(e => e.Team)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Team>()
                .HasMany(e => e.Players)
                .WithOptional(e => e.Team)
                .HasForeignKey(e => e.team_id)
                .WillCascadeOnDelete();

            modelBuilder.Entity<Tournament>()
                .HasMany(e => e.Games)
                .WithRequired(e => e.Tournament)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Tournament>()
                .HasMany(e => e.Participates)
                .WithRequired(e => e.Tournament)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Result>()
                .Property(e => e.Group)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Result>()
                .Property(e => e.Level)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Result>()
                .Property(e => e.Status)
                .IsUnicode(false);

            modelBuilder.Entity<Result>()
                .Property(e => e.Results)
                .IsUnicode(false);
        }
    }
}
