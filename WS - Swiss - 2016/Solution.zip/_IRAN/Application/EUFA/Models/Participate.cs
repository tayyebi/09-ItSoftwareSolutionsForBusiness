namespace EUFA.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Participate")]
    public partial class Participate
    {
        public int Id { get; set; }

        public int TeamId { get; set; }

        public int TournamentId { get; set; }

        public virtual Team Team { get; set; }

        public virtual Tournament Tournament { get; set; }
    }
}
