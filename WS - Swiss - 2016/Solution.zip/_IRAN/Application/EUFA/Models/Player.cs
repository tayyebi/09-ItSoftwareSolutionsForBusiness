namespace EUFA.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Player
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Player()
        {
            Grids = new HashSet<Grid>();
        }

        public int Id { get; set; }

        [StringLength(255)]
        public string lastname { get; set; }

        [StringLength(255)]
        public string firstname { get; set; }

        public int? shirt_number { get; set; }

        public int? position { get; set; }

        [StringLength(255)]
        public string date_of_birth { get; set; }

        public int? team_id { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Grid> Grids { get; set; }

        public virtual Position Position1 { get; set; }

        public virtual Team Team { get; set; }
    }
}
