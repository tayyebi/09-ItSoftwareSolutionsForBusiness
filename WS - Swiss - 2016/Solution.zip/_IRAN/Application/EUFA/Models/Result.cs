namespace EUFA.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Result
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long GameId { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(1)]
        public string Group { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(2)]
        public string Level { get; set; }

        [Key]
        [Column(Order = 3)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int TeamAlfaId { get; set; }

        [Key]
        [Column(Order = 4)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int TeamBetaId { get; set; }

        [StringLength(255)]
        public string TeamAlfaName { get; set; }

        [StringLength(255)]
        public string TeamBetaName { get; set; }

        [StringLength(255)]
        public string TeamAlfaCountryCode { get; set; }

        [StringLength(255)]
        public string TeamBetaCountryCode { get; set; }

        [StringLength(255)]
        public string TeamBetaFlagUrl { get; set; }

        [StringLength(255)]
        public string TeamAlfaFlagUrl { get; set; }

        [Key]
        [Column(Order = 5)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public short TeamAlfaGoals { get; set; }

        [Key]
        [Column(Order = 6)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public short TeamBetaGoals { get; set; }

        [Key]
        [Column(Order = 7)]
        [StringLength(10)]
        public string Status { get; set; }

        [Key]
        [Column(Order = 8)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int TournamentId { get; set; }

        [StringLength(30)]
        public string Results { get; set; }

        [Key]
        [Column(Order = 9)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int TeamAlfaScores { get; set; }

        [Key]
        [Column(Order = 10)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int TeamBetaScores { get; set; }

        public int? WinnerId { get; set; }

        [Key]
        [Column(Order = 11)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int WinnerPoints { get; set; }

        public int? GoalsDifference { get; set; }

        [Key]
        [Column(Order = 12)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int TeamAlfaPenalty { get; set; }

        [Key]
        [Column(Order = 13)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int TeamBetaPenalty { get; set; }
    }
}
