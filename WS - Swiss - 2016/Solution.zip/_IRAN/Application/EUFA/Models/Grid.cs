namespace EUFA.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Grid
    {
        public long Id { get; set; }

        public int TeamId { get; set; }

        public long GameId { get; set; }

        public int PlayerId { get; set; }

        public int PositionId { get; set; }

        public virtual Game Game { get; set; }

        public virtual Player Player { get; set; }

        public virtual Position Position { get; set; }

        public virtual Team Team { get; set; }
    }
}
