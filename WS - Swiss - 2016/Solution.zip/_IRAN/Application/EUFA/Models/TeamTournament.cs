namespace EUFA.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("TeamTournament")]
    public partial class TeamTournament
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int TournamentId { get; set; }

        [StringLength(255)]
        public string TournamentName { get; set; }

        [StringLength(255)]
        public string start_date { get; set; }

        [StringLength(255)]
        public string end_date { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int TeamId { get; set; }

        [StringLength(255)]
        public string TeamName { get; set; }

        [StringLength(255)]
        public string countrycode { get; set; }

        [StringLength(255)]
        public string flag_url { get; set; }

        public int? region { get; set; }
    }
}
