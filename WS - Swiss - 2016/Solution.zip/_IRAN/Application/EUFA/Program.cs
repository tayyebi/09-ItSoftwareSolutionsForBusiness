﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EUFA
{
    static class Program
    {


        static public int SelectedTournament { get; set; }

        [STAThread]
        static void Main()
        {
            Application.ThreadException += (sender, args) => MyError(sender, args.Exception);
            AppDomain.CurrentDomain.UnhandledException += (sender, args) => MyError(sender, args.ExceptionObject as Exception);


            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);


            //SelectedTournament = 274;
            //Application.Run(new ManageExecution());

            Application.Run(new Form1());

        }

        private static void MyError(object sender, Exception e)
        {
            MessageBox.Show("There was an error\r\n" + e.Message);
        }
    }
}
