﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EUFA
{
    public partial class AllocateTeams : Masters.Father
    {
        public AllocateTeams()
        {
            InitializeComponent();
        }


        private class MyTeam
        {
            public string Name { get; set; }
            public string Code { get; set; }
            public int Id { get; set; }
            public string Group { get; set; }

        }
        List<MyTeam> teams;
        private void MyRefresh()
        {

            teams = new List<MyTeam>();

            var games = db.Games.Local
                .Where(x => x.Level == "24"
                && x.TournamentId == Program.SelectedTournament)
                //.OrderBy(x => Guid.NewGuid())
                //.ToList();
                ;

            foreach (var item in games)
            {
                if (teams.Where(x => x.Id == item.TeamAlfaId).Count() == 0)
                     teams.Add(new MyTeam
                    {
                        Id = item.TeamAlfaId,
                        Name = db.Teams.Find(item.TeamAlfaId).name,
                        Code = db.Teams.Find(item.TeamAlfaId).countrycode,
                        Group = item.Group
                    });
                if (teams.Where(x => x.Id == item.TeamBetaId).Count() == 0)
                    teams.Add(new MyTeam
                    {
                    Id = item.TeamBetaId,
                    Name = db.Teams.Find(item.TeamBetaId).name,
                    Code = db.Teams.Find(item.TeamBetaId).countrycode,
                    Group = item.Group
                });
            }

            foreach (var item in teams)
            {
                switch (item.Group)
                {
                    case "A":
                        rexaGrid1.DataSource = teams
                            .Where(x => x.Group == "A")
                            .Select(x =>
                        new
                        {
                            Shortname = x.Code,
                            Team = x.Name
                        })
                        .ToList()
                        ;
                        break;
                    case "B":
                        rexaGrid2.DataSource = teams
                            .Where(x => x.Group == "B")
                            .Select(x =>
                        new
                        {
                            Shortname = x.Code,
                            Team = x.Name
                        })
                        .ToList();
                        break;
                    case "C":
                        rexaGrid3.DataSource = teams
                            .Where(x => x.Group == "C")
                            .Select(x =>
                        new
                        {
                            Shortname = x.Code,
                            Team = x.Name
                        }).ToList();
                        break;
                    case "D":
                        rexaGrid4.DataSource = teams
                            .Where(x => x.Group == "D")
                            .Select(x =>
                        new
                        {
                            Shortname = x.Code,
                            Team = x.Name
                        }).ToList();
                        break;
                    case "E":
                        rexaGrid5.DataSource = teams
                            .Where(x => x.Group == "E")
                            .Select(x =>
                        new
                        {
                            Shortname = x.Code,
                            Team = x.Name
                        }).ToList();
                        break;
                    case "F":
                        rexaGrid6.DataSource = teams
                            .Where(x => x.Group == "F")
                            .Select(x =>
                        new
                        {
                            Shortname = x.Code,
                            Team = x.Name
                        }).ToList();
                        break;
                }
            }

        }

        private void AllocateTeams_Load(object sender, EventArgs e)
        {
            db.Games.ToList();
            foreach (var item in db.TeamTournaments.Where(c => c.TournamentId == Program.SelectedTournament).OrderBy(n => n.TeamName).ToList())
            {
                listBox1.Items.Add(item.TeamName);
            }
            MyRefresh();
        }

        private void rexaButton7_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void rexaButton1_Click(object sender, EventArgs e)
        {
            db.SaveChanges();
            Close();
        }

        public string GroupName(int i)
        {
            switch (i)
            {
                case 2:
                    return "B";
                case 3:
                    return "C";
                case 4:
                    return "D";
                case 5:
                    return "E";
                case 6:
                    return "F";
                default:
                    return "A";
            }


        }

        private void rexaButton2_Click(object sender, EventArgs e)
        {
            var list = db.TeamTournaments.Where(c => c.TournamentId == Program.SelectedTournament).OrderBy(n => Guid.NewGuid()).ToList();


            for (int i = 0; i < 6; i++)
            {

                int scaller = ((i + 1) * 4) - 4;

                db.Games.Add(new Models.Game { Status = "Scheduled", Group = GroupName(i + 1), Level = "24", TournamentId = Program.SelectedTournament, TeamAlfaId = list[(1 - 1) + scaller].TeamId, TeamBetaId = list[(2 - 1) + scaller].TeamId });
                db.Games.Add(new Models.Game { Status = "Scheduled", Group = GroupName(i + 1), Level = "24", TournamentId = Program.SelectedTournament, TeamAlfaId = list[(1 - 1) + scaller].TeamId, TeamBetaId = list[(3 - 1) + scaller].TeamId });
                db.Games.Add(new Models.Game { Status = "Scheduled", Group = GroupName(i + 1), Level = "24", TournamentId = Program.SelectedTournament, TeamAlfaId = list[(1 - 1) + scaller].TeamId, TeamBetaId = list[(4 - 1) + scaller].TeamId });
                db.Games.Add(new Models.Game { Status = "Scheduled", Group = GroupName(i + 1), Level = "24", TournamentId = Program.SelectedTournament, TeamAlfaId = list[(2 - 1) + scaller].TeamId, TeamBetaId = list[(3 - 1) + scaller].TeamId });
                db.Games.Add(new Models.Game { Status = "Scheduled", Group = GroupName(i + 1), Level = "24", TournamentId = Program.SelectedTournament, TeamAlfaId = list[(2 - 1) + scaller].TeamId, TeamBetaId = list[(4 - 1) + scaller].TeamId });
                db.Games.Add(new Models.Game { Status = "Scheduled", Group = GroupName(i + 1), Level = "24", TournamentId = Program.SelectedTournament, TeamAlfaId = list[(3 - 1) + scaller].TeamId, TeamBetaId = list[(4 - 1) + scaller].TeamId });
            }
            //db.SaveChanges();
            rexaButton2.Enabled = false;
            MyRefresh();
            
        }
    }
}
