﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EUFA
{
    public partial class PlayerCrud : Masters.Father
    {

        public Models.Player MyProperty { get; set; }
        public PlayerCrud()
        {
            InitializeComponent();
        }

        private void PlayerCrud_Load(object sender, EventArgs e)
        {
            comboBox1.DataSource
                 = db.Positions.ToList();
            comboBox1.DisplayMember = "Name";
        }

        private void rexaButton2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void rexaButton1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == string.Empty || Convert.ToInt32(maskedTextBox1.Text) == 0)
            {
                MessageBox.Show("Invalid data");
                return;
            }
        }
    }
}
