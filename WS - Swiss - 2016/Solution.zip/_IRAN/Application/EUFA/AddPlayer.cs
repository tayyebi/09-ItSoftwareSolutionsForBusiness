﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EUFA
{
    public partial class AddPlayer : Masters.Father
    {
        public int MyTeamId { get; set; }
        public long MyGameId { get; set; }


        public AddPlayer()
        {
            InitializeComponent();
        }

        private void AddPlayer_Load(object sender, EventArgs e)
        {
            db = new Models.MainModel();

            comboBox1.DisplayMember = "Name";
            comboBox1.ValueMember = "Id";
            comboBox1.DataSource = db.Players.Where(x => x.team_id == MyTeamId)
            .Select(x => new { Name = x.firstname + " " + x.lastname, Id = x.Id })
            .ToList();

            comboBox2.DisplayMember = "Name";
            comboBox2.ValueMember = "Id";
            comboBox2.DataSource = db.Positions.ToList();
        }

        private void rexaButton1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void rexaButton2_Click(object sender, EventArgs e)
        {
            db.Grids.Add(new Models.Grid
            {
                GameId = MyGameId,
                TeamId = MyTeamId,
                PlayerId = Convert.ToInt32(comboBox1.SelectedValue),
                PositionId = Convert.ToInt32(comboBox2.SelectedValue),
            });
            db.SaveChanges();
            Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int player = Convert.ToInt32(comboBox1.SelectedValue);
            comboBox2.SelectedValue = db.Players
                .Where(x => x.Id == player).FirstOrDefault().position;

        }
    }
}
