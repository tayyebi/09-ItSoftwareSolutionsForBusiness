﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EUFA
{
    public partial class TeamCrud : Masters.Father
    {
        public Models.Team MyProperty { get; set; }
        public TeamCrud()
        {
            InitializeComponent();
        }

        private void TeamCrud_Load(object sender, EventArgs e)
        {
            comboBox1.ValueMember = "Id";
            comboBox1.DisplayMember = "region1";
            comboBox1.DataSource = db.Regions.ToList();

            MyRefresh();
        }

        private void MyRefresh()
        {
            if (MyProperty == null)
                return;


            textBox1.Text = MyProperty.name;
            textBox2.Text = MyProperty.countrycode;
            comboBox1.SelectedValue = MyProperty.region;

            var query = (

                from a in db.Players

                join p in db.Positions
                on a.position equals p.Id

                join t in db.Teams
                on a.team_id equals t.id

                where t.id == MyProperty.id


                select new
                {
                    a.Id,
                    Number = a.shirt_number,
                    Name = a.firstname + " " + a.lastname,
                    Position = p.Name,

                }
                )
                .ToList();

            rexaGrid1.DataSource = query;

            groupBox1.Text = "Players (" + query.Count.ToString() + ")";
            rexaGrid1.Columns[0].Visible = false;
        }

        private void OnChange(object sender, EventArgs e)
        {
            rexaButton6.Enabled = true;
            if (textBox1.Text == string.Empty || textBox2.Text == string.Empty || textBox2.Text.Length != 3)
            {
                rexaButton6.Enabled = false;

            }
        }

        private void rexaButton1_Click(object sender, EventArgs e)
        {
            var ofd = new OpenFileDialog();
            ofd.Filter = "PNG|*.png";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox2.BackgroundImage = Image.FromFile(ofd.FileName);
            }
        }

        private void rexaButton6_Click(object sender, EventArgs e)
        {
            if (MyProperty != null)
            {
                var team = db.Teams.Find(MyProperty.id);

                // team.flag_url = 
                team.countrycode = textBox2.Text;
                team.name = textBox1.Text;
                team.region = Convert.ToInt32(comboBox1.SelectedValue);

                db.Teams.Attach(team);
                db.Entry(team).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
            else
            {

                var prop = new Models.Team
                {
                    // flag_url = 
                    countrycode = textBox2.Text,
                    name = textBox1.Text,
                    region = Convert.ToInt32(comboBox1.SelectedValue),

                };
                db.Teams.Add(prop);
                db.SaveChanges();


                MyProperty = prop;
            }
            MyRefresh();
            Close();
        }

        private void rexaButton5_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void rexaButton2_Click(object sender, EventArgs e)
        {
            new PlayerCrud().ShowDialog();
            MyRefresh();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void rexaButton3_Click(object sender, EventArgs e)
        {
            new PlayerCrud().ShowDialog();
            MyRefresh();
        }

        private void rexaButton4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure to delete this item?", "WARNING!", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                int id = Convert.ToInt32(rexaGrid1.SelectedRows[0].Cells["Id"].Value);
                var player = db.Players.Where(x=>x.Id == id).FirstOrDefault();
                db.Players.Remove(player);
                db.SaveChanges();
                MyRefresh();
            }
        }
    }
}
