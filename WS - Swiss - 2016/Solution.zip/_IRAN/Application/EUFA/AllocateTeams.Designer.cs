﻿namespace EUFA
{
    partial class AllocateTeams
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.rexaButton7 = new EUFA.Components.RexaButton(this.components);
            this.rexaButton1 = new EUFA.Components.RexaButton(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.rexaButton2 = new EUFA.Components.RexaButton(this.components);
            this.rexaGrid1 = new EUFA.Components.RexaGrid(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.rexaGrid2 = new EUFA.Components.RexaGrid(this.components);
            this.label4 = new System.Windows.Forms.Label();
            this.rexaGrid3 = new EUFA.Components.RexaGrid(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.rexaGrid4 = new EUFA.Components.RexaGrid(this.components);
            this.label7 = new System.Windows.Forms.Label();
            this.rexaGrid5 = new EUFA.Components.RexaGrid(this.components);
            this.rexaGrid6 = new EUFA.Components.RexaGrid(this.components);
            this.label8 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid6)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Size = new System.Drawing.Size(699, 45);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(34, 0);
            this.label1.Size = new System.Drawing.Size(665, 45);
            this.label1.Text = "Father";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Size = new System.Drawing.Size(34, 45);
            // 
            // rexaButton7
            // 
            this.rexaButton7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton7.ForeColor = System.Drawing.Color.White;
            this.rexaButton7.Location = new System.Drawing.Point(540, 527);
            this.rexaButton7.Name = "rexaButton7";
            this.rexaButton7.Size = new System.Drawing.Size(139, 29);
            this.rexaButton7.TabIndex = 4;
            this.rexaButton7.Text = "Close";
            this.rexaButton7.UseVisualStyleBackColor = false;
            this.rexaButton7.Click += new System.EventHandler(this.rexaButton7_Click);
            // 
            // rexaButton1
            // 
            this.rexaButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton1.ForeColor = System.Drawing.Color.White;
            this.rexaButton1.Location = new System.Drawing.Point(396, 527);
            this.rexaButton1.Name = "rexaButton1";
            this.rexaButton1.Size = new System.Drawing.Size(139, 29);
            this.rexaButton1.TabIndex = 4;
            this.rexaButton1.Text = "Save and Close";
            this.rexaButton1.UseVisualStyleBackColor = false;
            this.rexaButton1.Click += new System.EventHandler(this.rexaButton1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(15, 144);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "Group A";
            // 
            // rexaButton2
            // 
            this.rexaButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton2.ForeColor = System.Drawing.Color.White;
            this.rexaButton2.Location = new System.Drawing.Point(13, 85);
            this.rexaButton2.Name = "rexaButton2";
            this.rexaButton2.Size = new System.Drawing.Size(139, 29);
            this.rexaButton2.TabIndex = 4;
            this.rexaButton2.Text = "Allocate Randomly";
            this.rexaButton2.UseVisualStyleBackColor = false;
            this.rexaButton2.Click += new System.EventHandler(this.rexaButton2_Click);
            // 
            // rexaGrid1
            // 
            this.rexaGrid1.AllowUserToAddRows = false;
            this.rexaGrid1.AllowUserToDeleteRows = false;
            this.rexaGrid1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.rexaGrid1.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid1.GridColor = System.Drawing.Color.Black;
            this.rexaGrid1.Location = new System.Drawing.Point(13, 163);
            this.rexaGrid1.MultiSelect = false;
            this.rexaGrid1.Name = "rexaGrid1";
            this.rexaGrid1.ReadOnly = true;
            this.rexaGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid1.Size = new System.Drawing.Size(139, 150);
            this.rexaGrid1.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(183, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Group B";
            // 
            // rexaGrid2
            // 
            this.rexaGrid2.AllowUserToAddRows = false;
            this.rexaGrid2.AllowUserToDeleteRows = false;
            this.rexaGrid2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.rexaGrid2.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid2.GridColor = System.Drawing.Color.Black;
            this.rexaGrid2.Location = new System.Drawing.Point(179, 163);
            this.rexaGrid2.MultiSelect = false;
            this.rexaGrid2.Name = "rexaGrid2";
            this.rexaGrid2.ReadOnly = true;
            this.rexaGrid2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid2.Size = new System.Drawing.Size(139, 150);
            this.rexaGrid2.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(344, 144);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "Group C";
            // 
            // rexaGrid3
            // 
            this.rexaGrid3.AllowUserToAddRows = false;
            this.rexaGrid3.AllowUserToDeleteRows = false;
            this.rexaGrid3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid3.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.rexaGrid3.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid3.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid3.GridColor = System.Drawing.Color.Black;
            this.rexaGrid3.Location = new System.Drawing.Point(342, 163);
            this.rexaGrid3.MultiSelect = false;
            this.rexaGrid3.Name = "rexaGrid3";
            this.rexaGrid3.ReadOnly = true;
            this.rexaGrid3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid3.Size = new System.Drawing.Size(139, 150);
            this.rexaGrid3.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 331);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "Group D";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(183, 331);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Group E";
            // 
            // rexaGrid4
            // 
            this.rexaGrid4.AllowUserToAddRows = false;
            this.rexaGrid4.AllowUserToDeleteRows = false;
            this.rexaGrid4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid4.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.rexaGrid4.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid4.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid4.GridColor = System.Drawing.Color.Black;
            this.rexaGrid4.Location = new System.Drawing.Point(13, 351);
            this.rexaGrid4.MultiSelect = false;
            this.rexaGrid4.Name = "rexaGrid4";
            this.rexaGrid4.ReadOnly = true;
            this.rexaGrid4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid4.Size = new System.Drawing.Size(139, 150);
            this.rexaGrid4.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(344, 331);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 16);
            this.label7.TabIndex = 5;
            this.label7.Text = "Group F";
            // 
            // rexaGrid5
            // 
            this.rexaGrid5.AllowUserToAddRows = false;
            this.rexaGrid5.AllowUserToDeleteRows = false;
            this.rexaGrid5.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid5.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.rexaGrid5.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid5.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid5.GridColor = System.Drawing.Color.Black;
            this.rexaGrid5.Location = new System.Drawing.Point(179, 351);
            this.rexaGrid5.MultiSelect = false;
            this.rexaGrid5.Name = "rexaGrid5";
            this.rexaGrid5.ReadOnly = true;
            this.rexaGrid5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid5.Size = new System.Drawing.Size(139, 150);
            this.rexaGrid5.TabIndex = 6;
            // 
            // rexaGrid6
            // 
            this.rexaGrid6.AllowUserToAddRows = false;
            this.rexaGrid6.AllowUserToDeleteRows = false;
            this.rexaGrid6.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid6.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.rexaGrid6.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid6.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid6.GridColor = System.Drawing.Color.Black;
            this.rexaGrid6.Location = new System.Drawing.Point(342, 351);
            this.rexaGrid6.MultiSelect = false;
            this.rexaGrid6.Name = "rexaGrid6";
            this.rexaGrid6.ReadOnly = true;
            this.rexaGrid6.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid6.Size = new System.Drawing.Size(139, 150);
            this.rexaGrid6.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(517, 144);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 16);
            this.label8.TabIndex = 5;
            this.label8.Text = "Teams";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(519, 163);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(159, 340);
            this.listBox1.TabIndex = 7;
            // 
            // AllocateTeams
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(699, 569);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.rexaGrid6);
            this.Controls.Add(this.rexaGrid3);
            this.Controls.Add(this.rexaGrid5);
            this.Controls.Add(this.rexaGrid2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.rexaGrid4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.rexaGrid1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.rexaButton2);
            this.Controls.Add(this.rexaButton1);
            this.Controls.Add(this.rexaButton7);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "AllocateTeams";
            this.Tag = " ";
            this.Text = "Allocate Teams To Groups";
            this.Load += new System.EventHandler(this.AllocateTeams_Load);
            this.Controls.SetChildIndex(this.rexaButton7, 0);
            this.Controls.SetChildIndex(this.rexaButton1, 0);
            this.Controls.SetChildIndex(this.rexaButton2, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.label5, 0);
            this.Controls.SetChildIndex(this.rexaGrid1, 0);
            this.Controls.SetChildIndex(this.label6, 0);
            this.Controls.SetChildIndex(this.rexaGrid4, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.label7, 0);
            this.Controls.SetChildIndex(this.rexaGrid2, 0);
            this.Controls.SetChildIndex(this.rexaGrid5, 0);
            this.Controls.SetChildIndex(this.rexaGrid3, 0);
            this.Controls.SetChildIndex(this.rexaGrid6, 0);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.listBox1, 0);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Components.RexaButton rexaButton7;
        private Components.RexaButton rexaButton1;
        private System.Windows.Forms.Label label2;
        private Components.RexaGrid rexaGrid1;
        private System.Windows.Forms.Label label3;
        private Components.RexaGrid rexaGrid2;
        private System.Windows.Forms.Label label4;
        private Components.RexaGrid rexaGrid3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private Components.RexaGrid rexaGrid4;
        private System.Windows.Forms.Label label7;
        private Components.RexaGrid rexaGrid5;
        private Components.RexaGrid rexaGrid6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ListBox listBox1;
        public Components.RexaButton rexaButton2;
    }
}