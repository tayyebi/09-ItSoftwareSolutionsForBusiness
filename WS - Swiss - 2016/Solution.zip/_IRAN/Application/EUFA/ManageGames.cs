﻿using EUFA.Components;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EUFA
{
    public partial class ManageGames : Masters.Father
    {
        public ManageGames()
        {
            InitializeComponent();
        }
        public string MyLevel { get; set; }
        private void ManageGames_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            if (Text == "Manage Group Stage Games...")
                comboBox1.Visible = true;

            //MyRefresh();
        }

        private void rexaButton7_Click(object sender, EventArgs e)
        {
            Close();
        }

        public void MyRefresh()
        {

            //rexaGrid1.DataSource = db.Games.Where(x => x.TournamentId == Program.SelectedTournament
            //&&
            //x.Level == Level
            //&&
            //x.Group == comboBox1.SelectedText
            //).
            //Select(x=>
            //new
            //{
            //    Game =
            //    db.Teams.Find((int)x.TeamAlfaId).name+" - "+
            //    db.Teams.Find((int)x.TeamBetaId).name
            //    Result = 
            //}).
            //ToList();


            //string group =
            //    comboBox1.Text.Substring(6, comboBox1.Text.Length - 7);
            string group =
                comboBox1.Text.Replace("Group ", string.Empty);


            rexaGrid1.DataSource = db.Results.
            Where(
            x => x.TournamentId == Program.SelectedTournament
            &&
            x.Level == MyLevel
            &&
            x.Group == group
            ).
            Select(x =>
            new
            {
                Id = x.GameId,
                Game =
                x.TeamAlfaName + " - " +
                 x.TeamBetaName,
                Result = x.Results
            }).
            ToList();
            rexaGrid1.Columns[0].DisplayIndex = 3;
            rexaGrid1.Columns[1].Visible = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            MyRefresh();
        }

        class MyTeam
        {
            public int TeamId { get; set; }
            public string Level { get; set; }
            public string Group { get; set; }
            public int SumPoints { get; set; }
            public int SumGoalDifferences { get; set; }
            public int SumGoals { get; set; }

        }

        private void rexaButton1_Click(object sender, EventArgs e)
        {
            List<MyTeam> teams = new List<MyTeam>();

            var games = db.Results.Where(x => x.TournamentId == Program.SelectedTournament).ToList();

            foreach (var item in games)
            {
                if (teams.Where(x => x.TeamId == item.TeamAlfaId).Count() == 0)
                {
                    teams.Add(new MyTeam
                    {
                        TeamId = item.TeamAlfaId,
                        Group = item.Group,
                        Level = item.Level,
                        SumGoalDifferences = item.GoalsDifference ?? 0,
                        SumGoals = item.TeamAlfaGoals,
                        SumPoints = item.WinnerPoints 
                    });
                }
                else
                {
                    var this_team = teams.Where(x => x.TeamId == item.TeamAlfaId).FirstOrDefault();

                    this_team.SumGoalDifferences += item.GoalsDifference ?? 0;
                    this_team.SumGoals += item.TeamAlfaGoals;
                    this_team.SumPoints += item.WinnerPoints;
                }

                if (teams.Where(x => x.TeamId == item.TeamBetaId).Count() == 0)
                {
                    teams.Add(new MyTeam
                    {
                        TeamId = item.TeamBetaId,
                        Group = item.Group,
                        Level = item.Level,
                        SumGoalDifferences = item.GoalsDifference ?? 0,
                        SumGoals = item.TeamBetaGoals,
                        SumPoints = item.WinnerPoints 
                    });
                }
                else
                {
                    var this_team = teams.Where(x => x.TeamId == item.TeamBetaId).FirstOrDefault();

                    this_team.SumGoalDifferences += item.GoalsDifference ?? 0;
                    this_team.SumGoals += item.TeamBetaGoals;
                    this_team.SumPoints += item.WinnerPoints;
                }
            }


            teams = teams
                .OrderBy(x => x.Level)
                .OrderBy(x => x.Group)
                .OrderBy(x => x.SumPoints)
                .OrderBy(x => x.SumGoalDifferences)
                .OrderBy(x => x.SumGoals)
                .ToList();

            var frm = new OrderedView();
            frm.rexaGrid1.DataSource = teams;
            frm.ShowDialog();

            if (MyLevel == "24")
            {
                if (db.Games.Where(x => x.TournamentId == Program.SelectedTournament).Where(y => y.Level == "24" && y.Status == "Finished").Count() == db.Games.Where(x => x.TournamentId == Program.SelectedTournament).Where(y => y.Level == "24").Count() && db.Games.Where(x => x.TournamentId == Program.SelectedTournament).Where(y => y.Level == "24").Count() != 0)
                {
                    MessageBox.Show("There are stil games that are not finished");
                    return;
                }

            }
            else if (MyLevel == "16")
            {

            }
            else if (MyLevel == "8")
            {

            }
            else if (MyLevel == "4")
            {

            }
            else if (MyLevel == "2")
            {

            }
            else if (MyLevel == "1")
            {

            }
        }

        private void rexaGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                db = new Models.MainModel();
                int y = Convert.ToInt32(rexaGrid1.Rows[e.RowIndex].Cells["Id"].Value);
                var res = db.Results.Where
                    (x => x.GameId ==
                    y
                    ).FirstOrDefault();

                new EditGame
                {
                    MyGameResult = res


                }.ShowDialog();
                MyRefresh();
            }
        }
    }
}
