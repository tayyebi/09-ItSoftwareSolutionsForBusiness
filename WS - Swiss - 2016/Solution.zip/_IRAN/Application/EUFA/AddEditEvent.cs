﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EUFA
{
    public partial class AddEditEvent : Masters.Father
    {
        public AddEditEvent()
        {
            InitializeComponent();
        }

        public Models.Result Game { get; set; }
        public Models.Event MyProperty { get; set; }
        private void AddEditEvent_Load(object sender, EventArgs e)
        {

            comboBox1.Items.Add("Goal");
            comboBox1.Items.Add("Foul");
            comboBox1.Items.Add("Free kick");
            comboBox1.Items.Add("Corner");
            comboBox1.Items.Add("Penalty");
            comboBox1.Items.Add("Substitute");
            comboBox1.Items.Add("Yellow Card");
            comboBox1.Items.Add("Red Card");
            comboBox1.SelectedIndex = 0;

            if (MyProperty != null)
            {
                if (MyProperty.TeamId == Game.TeamBetaId)
                    radioButton2.Checked = true;
            else radioButton1.Checked = true;
                textBox1.Text = MyProperty.Info;
                comboBox1.Text = MyProperty.Name;
                maskedTextBox1.Text = MyProperty.Minute.ToString();
            }
            else radioButton1.Checked = true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void rexaButton1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void rexaButton2_Click(object sender, EventArgs e)
        {
            if (MyProperty == null)
            {
                db.Events.Add(new Models.Event
                {
                    GameId = Game.GameId,
                    Info = textBox1.Text,
                    Minute = Convert.ToInt16(maskedTextBox1.Text.Replace("_", string.Empty)),
                    Name = comboBox1.Text,
                    TeamId = (int)(radioButton1.Checked ? Game.TeamAlfaId : Game.TeamBetaId)
                });
            }
            else
            {
                var ev = db.Events.Where(x => x.Id == MyProperty.Id).FirstOrDefault();
                db.Events.Attach(ev);
                ev.GameId = Game.GameId;
                ev.Info = textBox1.Text;
                ev.Minute = Convert.ToInt16(maskedTextBox1.Text.Replace("_", string.Empty));
                ev.Name = comboBox1.Text;
                ev.TeamId = (int)(radioButton1.Checked ? Game.TeamAlfaId : Game.TeamBetaId);
                db.Entry(ev).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
            db.SaveChanges();
            Close();
        }

        private void OnChange(object sender, EventArgs e)
        {
            rexaButton2.Enabled = true;
            if (maskedTextBox1.Text.Contains("_")
                || textBox1.Text == string.Empty
                )
                rexaButton2.Enabled = false;
        }
    }
}
