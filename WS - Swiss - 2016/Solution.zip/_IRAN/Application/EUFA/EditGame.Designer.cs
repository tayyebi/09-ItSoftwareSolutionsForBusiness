﻿namespace EUFA
{
    partial class EditGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.rexaButton5 = new EUFA.Components.RexaButton(this.components);
            this.rexaButton3 = new EUFA.Components.RexaButton(this.components);
            this.rexaButton4 = new EUFA.Components.RexaButton(this.components);
            this.rexaButton2 = new EUFA.Components.RexaButton(this.components);
            this.rexaGrid2 = new EUFA.Components.RexaGrid(this.components);
            this.rexaGrid1 = new EUFA.Components.RexaGrid(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rexaButton9 = new EUFA.Components.RexaButton(this.components);
            this.rexaButton8 = new EUFA.Components.RexaButton(this.components);
            this.rexaButton6 = new EUFA.Components.RexaButton(this.components);
            this.rexaGrid3 = new EUFA.Components.RexaGrid(this.components);
            this.rexaButton1 = new EUFA.Components.RexaButton(this.components);
            this.rexaButton7 = new EUFA.Components.RexaButton(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid3)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.checkBox2);
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Size = new System.Drawing.Size(738, 49);
            this.panel1.Controls.SetChildIndex(this.pictureBox1, 0);
            this.panel1.Controls.SetChildIndex(this.label1, 0);
            this.panel1.Controls.SetChildIndex(this.checkBox1, 0);
            this.panel1.Controls.SetChildIndex(this.checkBox2, 0);
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Left;
            this.label1.Location = new System.Drawing.Point(32, 0);
            this.label1.Size = new System.Drawing.Size(572, 49);
            this.label1.Text = "Father";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Size = new System.Drawing.Size(32, 49);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(610, 3);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(106, 20);
            this.checkBox1.TabIndex = 2;
            this.checkBox1.Text = "Game Started";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Enabled = false;
            this.checkBox2.Location = new System.Drawing.Point(610, 26);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(111, 20);
            this.checkBox2.TabIndex = 2;
            this.checkBox2.Text = "Game Finished";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 55);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(714, 412);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.rexaButton5);
            this.tabPage1.Controls.Add(this.rexaButton3);
            this.tabPage1.Controls.Add(this.rexaButton4);
            this.tabPage1.Controls.Add(this.rexaButton2);
            this.tabPage1.Controls.Add(this.rexaGrid2);
            this.tabPage1.Controls.Add(this.rexaGrid1);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(706, 383);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Starting Grid";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // rexaButton5
            // 
            this.rexaButton5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton5.ForeColor = System.Drawing.Color.White;
            this.rexaButton5.Location = new System.Drawing.Point(507, 310);
            this.rexaButton5.Name = "rexaButton5";
            this.rexaButton5.Size = new System.Drawing.Size(75, 29);
            this.rexaButton5.TabIndex = 2;
            this.rexaButton5.Text = "Delete";
            this.rexaButton5.UseVisualStyleBackColor = false;
            this.rexaButton5.Click += new System.EventHandler(this.rexaButton5_Click);
            // 
            // rexaButton3
            // 
            this.rexaButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton3.ForeColor = System.Drawing.Color.White;
            this.rexaButton3.Location = new System.Drawing.Point(90, 311);
            this.rexaButton3.Name = "rexaButton3";
            this.rexaButton3.Size = new System.Drawing.Size(75, 29);
            this.rexaButton3.TabIndex = 2;
            this.rexaButton3.Text = "Delete";
            this.rexaButton3.UseVisualStyleBackColor = false;
            this.rexaButton3.Click += new System.EventHandler(this.rexaButton3_Click);
            // 
            // rexaButton4
            // 
            this.rexaButton4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton4.ForeColor = System.Drawing.Color.White;
            this.rexaButton4.Location = new System.Drawing.Point(426, 311);
            this.rexaButton4.Name = "rexaButton4";
            this.rexaButton4.Size = new System.Drawing.Size(75, 29);
            this.rexaButton4.TabIndex = 2;
            this.rexaButton4.Text = "Add...";
            this.rexaButton4.UseVisualStyleBackColor = false;
            this.rexaButton4.Click += new System.EventHandler(this.rexaButton4_Click);
            // 
            // rexaButton2
            // 
            this.rexaButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton2.ForeColor = System.Drawing.Color.White;
            this.rexaButton2.Location = new System.Drawing.Point(9, 312);
            this.rexaButton2.Name = "rexaButton2";
            this.rexaButton2.Size = new System.Drawing.Size(75, 29);
            this.rexaButton2.TabIndex = 2;
            this.rexaButton2.Text = "Add...";
            this.rexaButton2.UseVisualStyleBackColor = false;
            this.rexaButton2.Click += new System.EventHandler(this.rexaButton2_Click);
            // 
            // rexaGrid2
            // 
            this.rexaGrid2.AllowUserToAddRows = false;
            this.rexaGrid2.AllowUserToDeleteRows = false;
            this.rexaGrid2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid2.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid2.GridColor = System.Drawing.Color.Black;
            this.rexaGrid2.Location = new System.Drawing.Point(426, 22);
            this.rexaGrid2.MultiSelect = false;
            this.rexaGrid2.Name = "rexaGrid2";
            this.rexaGrid2.ReadOnly = true;
            this.rexaGrid2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid2.Size = new System.Drawing.Size(263, 284);
            this.rexaGrid2.TabIndex = 1;
            // 
            // rexaGrid1
            // 
            this.rexaGrid1.AllowUserToAddRows = false;
            this.rexaGrid1.AllowUserToDeleteRows = false;
            this.rexaGrid1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid1.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid1.GridColor = System.Drawing.Color.Black;
            this.rexaGrid1.Location = new System.Drawing.Point(9, 22);
            this.rexaGrid1.MultiSelect = false;
            this.rexaGrid1.Name = "rexaGrid1";
            this.rexaGrid1.ReadOnly = true;
            this.rexaGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid1.Size = new System.Drawing.Size(263, 284);
            this.rexaGrid1.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(423, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "label2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "label2";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(706, 383);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Events";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rexaButton9);
            this.panel2.Controls.Add(this.rexaButton8);
            this.panel2.Controls.Add(this.rexaButton6);
            this.panel2.Controls.Add(this.rexaGrid3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Enabled = false;
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(700, 377);
            this.panel2.TabIndex = 0;
            // 
            // rexaButton9
            // 
            this.rexaButton9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton9.ForeColor = System.Drawing.Color.White;
            this.rexaButton9.Location = new System.Drawing.Point(199, 342);
            this.rexaButton9.Name = "rexaButton9";
            this.rexaButton9.Size = new System.Drawing.Size(92, 32);
            this.rexaButton9.TabIndex = 1;
            this.rexaButton9.Text = "Delete";
            this.rexaButton9.UseVisualStyleBackColor = false;
            this.rexaButton9.Click += new System.EventHandler(this.rexaButton9_Click);
            // 
            // rexaButton8
            // 
            this.rexaButton8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton8.ForeColor = System.Drawing.Color.White;
            this.rexaButton8.Location = new System.Drawing.Point(101, 342);
            this.rexaButton8.Name = "rexaButton8";
            this.rexaButton8.Size = new System.Drawing.Size(92, 32);
            this.rexaButton8.TabIndex = 1;
            this.rexaButton8.Text = "Edit...";
            this.rexaButton8.UseVisualStyleBackColor = false;
            this.rexaButton8.Click += new System.EventHandler(this.rexaButton8_Click);
            // 
            // rexaButton6
            // 
            this.rexaButton6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton6.ForeColor = System.Drawing.Color.White;
            this.rexaButton6.Location = new System.Drawing.Point(3, 342);
            this.rexaButton6.Name = "rexaButton6";
            this.rexaButton6.Size = new System.Drawing.Size(92, 32);
            this.rexaButton6.TabIndex = 1;
            this.rexaButton6.Text = "Add...";
            this.rexaButton6.UseVisualStyleBackColor = false;
            this.rexaButton6.Click += new System.EventHandler(this.rexaButton6_Click);
            // 
            // rexaGrid3
            // 
            this.rexaGrid3.AllowUserToAddRows = false;
            this.rexaGrid3.AllowUserToDeleteRows = false;
            this.rexaGrid3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rexaGrid3.BackgroundColor = System.Drawing.Color.White;
            this.rexaGrid3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rexaGrid3.Dock = System.Windows.Forms.DockStyle.Top;
            this.rexaGrid3.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.rexaGrid3.GridColor = System.Drawing.Color.Black;
            this.rexaGrid3.Location = new System.Drawing.Point(0, 0);
            this.rexaGrid3.MultiSelect = false;
            this.rexaGrid3.Name = "rexaGrid3";
            this.rexaGrid3.ReadOnly = true;
            this.rexaGrid3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rexaGrid3.Size = new System.Drawing.Size(700, 333);
            this.rexaGrid3.TabIndex = 0;
            // 
            // rexaButton1
            // 
            this.rexaButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.rexaButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton1.ForeColor = System.Drawing.Color.White;
            this.rexaButton1.Location = new System.Drawing.Point(442, 474);
            this.rexaButton1.Name = "rexaButton1";
            this.rexaButton1.Size = new System.Drawing.Size(182, 30);
            this.rexaButton1.TabIndex = 5;
            this.rexaButton1.Text = "Save and Close";
            this.rexaButton1.UseVisualStyleBackColor = false;
            this.rexaButton1.Click += new System.EventHandler(this.rexaButton1_Click);
            // 
            // rexaButton7
            // 
            this.rexaButton7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.rexaButton7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(103)))), ((int)(((byte)(59)))));
            this.rexaButton7.ForeColor = System.Drawing.Color.White;
            this.rexaButton7.Location = new System.Drawing.Point(630, 474);
            this.rexaButton7.Name = "rexaButton7";
            this.rexaButton7.Size = new System.Drawing.Size(92, 30);
            this.rexaButton7.TabIndex = 6;
            this.rexaButton7.Text = "Close";
            this.rexaButton7.UseVisualStyleBackColor = false;
            this.rexaButton7.Click += new System.EventHandler(this.rexaButton7_Click_1);
            // 
            // EditGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(738, 516);
            this.Controls.Add(this.rexaButton1);
            this.Controls.Add(this.rexaButton7);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "EditGame";
            this.Text = "EditGames";
            this.Load += new System.EventHandler(this.EditGame_Load);
            this.Controls.SetChildIndex(this.tabControl1, 0);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.rexaButton7, 0);
            this.Controls.SetChildIndex(this.rexaButton1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rexaGrid3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        public Components.RexaButton rexaButton1;
        private Components.RexaButton rexaButton7;
        private System.Windows.Forms.Label label2;
        private Components.RexaGrid rexaGrid2;
        private Components.RexaGrid rexaGrid1;
        private System.Windows.Forms.Label label3;
        private Components.RexaButton rexaButton5;
        private Components.RexaButton rexaButton3;
        private Components.RexaButton rexaButton4;
        private Components.RexaButton rexaButton2;
        private System.Windows.Forms.Panel panel2;
        private Components.RexaGrid rexaGrid3;
        private Components.RexaButton rexaButton9;
        private Components.RexaButton rexaButton8;
        private Components.RexaButton rexaButton6;
    }
}