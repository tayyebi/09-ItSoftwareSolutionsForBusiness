﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Judo.Reports
{
    public partial class MatsView : Master
    {
        public MatsView()
        {
            InitializeComponent();
        }

        private void MatsView_Load(object sender, EventArgs e)
        {
            MatsReportLayoutBindingSource.DataSource =
                (
                from f in db.Fights

                join w in db.Competitors
                on f.WhiteCompetitorId equals w.Id

                join r in db.Competitors
                on f.RedCompetitorId equals r.Id

                select new MatsReportLayout
                {
                    MatNumber = f.MatNumber.ToString(),
                    Gender = f.GroupGenderClass,
                    AgeClass = f.GroupAgeClass.ToString(),

                    RedCompetitorName = r.Name,
                    RedCompetitorSurname = r.Surname,
                    RedCompetitorClub = r.SportsClub,

                    WhiteCompetitorName = w.Name,
                    WhiteCompetitorSurname = w.Surname,
                    WhiteCompetitorClub = w.SportsClub,
                }

                ).ToList();
            this.reportViewer1.RefreshReport();
        }
    }
}
