﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Judo.Reports
{
    class Certificate
    {
        public string AgeClass { get; set; }
        public string WeightClass { get; set; }
        public string Gender { get; set; }
        public string Fullname { get; set; }
        public string SportsClub { get; set; }
    }
}
