﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Judo.Reports
{
    class PosterLayout
    {
        public string FileName { get; set; }
        public byte[] Image { get; set; }
        public Bitmap MyBitmap { get; set; }
        public Image MyImage { get; set; }
    }
}
