﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Judo.Reports
{
    public partial class CompetitorsView : Master
    {
        public CompetitorsView()
        {
            InitializeComponent();
        }

        private void CompetitorsView_Load(object sender, EventArgs e)
        {
            View_CompetitorsBindingSource.DataSource = db.View_Competitors.ToList();
            this.reportViewer1.RefreshReport();
        }
    }
}
