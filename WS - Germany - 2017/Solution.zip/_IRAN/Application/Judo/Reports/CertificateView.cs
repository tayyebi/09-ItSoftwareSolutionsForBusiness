﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Judo.Reports
{
    public partial class CertificateView : Master
    {
        public CertificateView()
        {
            InitializeComponent();
        }

        private void CertificateView_Load(object sender, EventArgs e)
        {
            List<Tuple<string, string, int, decimal>> results =
                new List<Tuple<string, string, int, decimal>>();

            var fights = db.Fights.Where(x => x.Status == "End").ToList();

            foreach (var fight in fights)
            {
                results.Add(new Tuple<string, string, int, decimal>(fight.GroupName, fight.SubGroupName, fight.WhiteCompetitorId, fight.WhiteCompetitorPoints ?? 0));
                results.Add(new Tuple<string, string, int, decimal>(fight.GroupName, fight.SubGroupName, fight.RedCompetitorId, fight.RedCompetitorPoints ?? 0));
            }

            var query = (
                from competitor in results

                group competitor by new { competitor.Item1, competitor.Item2, competitor.Item3 }
                into g

                select new Tuple<string, string, int, decimal>
                (
                    g.Key.Item1,         
                    g.Key.Item2,         
                    g.Key.Item3,         
                    g.Sum(x => x.Item4)  

                )



                ).ToList();

            var query_l2 =
                (
                from a in query
                
                group a by new { a.Item1, a.Item2 }
                into g

                select new Tuple<string, string, int, decimal>
                (
                    g.Key.Item1,                                        // Group Name
                    g.Key.Item2,                                        // SubGroup
                    query                                               // Competitor ID
                        .Where(x=>x.Item4 == g.Max(y => y.Item4))     
                        .Select(x=>x.Item3)
                        .FirstOrDefault(),
                    g.Max(x=>x.Item4)                                   // Points
                )
                ).ToList();


            var final = (

                from a in query_l2

                join competitor in db.Competitors
                on a.Item3 equals competitor.Id

                select new Reports.Certificate
                {
                    //fight.GroupName,
                    AgeClass = db.Fights.Where(x=>x.GroupName == a.Item1)
                                        .FirstOrDefault()
                                        .GroupAgeClass.ToString(),
                    Gender = db.Fights.Where(x => x.GroupName == a.Item1)
                                        .FirstOrDefault().GroupGenderClass,
                    WeightClass = db.Fights.Where(x => x.GroupName == a.Item1)
                                        .FirstOrDefault().GroupWeightClass.ToString(),

                    Fullname = competitor.Name + " " + competitor.Surname,
                    SportsClub = competitor.SportsClub,
                }
                ).ToList();

            CertificateBindingSource.DataSource = final;
            this.reportViewer1.RefreshReport();
        }
    }
}
