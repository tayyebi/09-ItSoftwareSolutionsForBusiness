﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Judo.Reports
{
    class MatsReportLayout
    {
        public string MatNumber { get; set; }
        public string AgeClass { get; set; }

        public string weightClass { get; set; }

        public string Gender { get; set; }
        public string RedCompetitorName { get; set; }
        public string RedCompetitorSurname { get; set; }
        public string RedCompetitorClub { get; set; }
        public string WhiteCompetitorName { get; set; }
        public string WhiteCompetitorSurname { get; set; }
        public string WhiteCompetitorClub { get; set; }

    }
}
