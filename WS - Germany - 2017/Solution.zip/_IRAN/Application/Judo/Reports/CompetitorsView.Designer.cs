﻿namespace Judo.Reports
{
    partial class CompetitorsView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.View_CompetitorsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.View_CompetitorsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(7, 7);
            this.panel1.Size = new System.Drawing.Size(943, 73);
            // 
            // label1
            // 
            this.label1.Size = new System.Drawing.Size(877, 73);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(877, 0);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.reportViewer1);
            this.panel2.Location = new System.Drawing.Point(7, 80);
            this.panel2.Size = new System.Drawing.Size(943, 363);
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(7, 443);
            this.panel3.Size = new System.Drawing.Size(943, 38);
            // 
            // rexaButton1
            // 
            this.rexaButton1.Location = new System.Drawing.Point(848, 0);
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.View_CompetitorsBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Judo.Reports.CompetitorsReport.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(943, 363);
            this.reportViewer1.TabIndex = 0;
            // 
            // View_CompetitorsBindingSource
            // 
            this.View_CompetitorsBindingSource.DataSource = typeof(Judo.Models.View_Competitors);
            // 
            // CompetitorsView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(957, 488);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "CompetitorsView";
            this.Padding = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.Text = "CompetitorsView";
            this.Load += new System.EventHandler(this.CompetitorsView_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.View_CompetitorsBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource View_CompetitorsBindingSource;
    }
}