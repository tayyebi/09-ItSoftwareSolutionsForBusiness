﻿namespace Judo
{
    partial class Competitors
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label birthdateLabel;
            System.Windows.Forms.Label genderLabel;
            System.Windows.Forms.Label homeTownWithPostalCodeLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label sportsClubLabel;
            System.Windows.Forms.Label surnameLabel;
            System.Windows.Forms.Label weightLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Competitors));
            this.competitorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.competitorBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.competitorBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.competitorDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.genderComboBox = new System.Windows.Forms.ComboBox();
            this.homeTownWithPostalCodeTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.sportsClubTextBox = new System.Windows.Forms.TextBox();
            this.surnameTextBox = new System.Windows.Forms.TextBox();
            this.rexaButton2 = new Judo.Components.RexaButton(this.components);
            this.rexaButton3 = new Judo.Components.RexaButton(this.components);
            this.rexaButton4 = new Judo.Components.RexaButton(this.components);
            this.weightNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.rexaButton5 = new Judo.Components.RexaButton(this.components);
            birthdateLabel = new System.Windows.Forms.Label();
            genderLabel = new System.Windows.Forms.Label();
            homeTownWithPostalCodeLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            sportsClubLabel = new System.Windows.Forms.Label();
            surnameLabel = new System.Windows.Forms.Label();
            weightLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.competitorBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.competitorBindingNavigator)).BeginInit();
            this.competitorBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.competitorDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.weightNumericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(7, 7);
            this.panel1.Size = new System.Drawing.Size(896, 73);
            // 
            // label1
            // 
            this.label1.Size = new System.Drawing.Size(830, 73);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(830, 0);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(weightLabel);
            this.panel2.Controls.Add(this.weightNumericUpDown);
            this.panel2.Controls.Add(this.rexaButton4);
            this.panel2.Controls.Add(this.rexaButton3);
            this.panel2.Controls.Add(this.rexaButton5);
            this.panel2.Controls.Add(this.rexaButton2);
            this.panel2.Controls.Add(birthdateLabel);
            this.panel2.Controls.Add(this.birthdateDateTimePicker);
            this.panel2.Controls.Add(genderLabel);
            this.panel2.Controls.Add(this.genderComboBox);
            this.panel2.Controls.Add(homeTownWithPostalCodeLabel);
            this.panel2.Controls.Add(this.homeTownWithPostalCodeTextBox);
            this.panel2.Controls.Add(nameLabel);
            this.panel2.Controls.Add(this.nameTextBox);
            this.panel2.Controls.Add(sportsClubLabel);
            this.panel2.Controls.Add(this.sportsClubTextBox);
            this.panel2.Controls.Add(surnameLabel);
            this.panel2.Controls.Add(this.surnameTextBox);
            this.panel2.Controls.Add(this.competitorDataGridView);
            this.panel2.Location = new System.Drawing.Point(7, 80);
            this.panel2.Size = new System.Drawing.Size(896, 389);
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(7, 469);
            this.panel3.Size = new System.Drawing.Size(896, 38);
            // 
            // rexaButton1
            // 
            this.rexaButton1.Location = new System.Drawing.Point(801, 0);
            // 
            // birthdateLabel
            // 
            birthdateLabel.AutoSize = true;
            birthdateLabel.Location = new System.Drawing.Point(45, 111);
            birthdateLabel.Name = "birthdateLabel";
            birthdateLabel.Size = new System.Drawing.Size(64, 16);
            birthdateLabel.TabIndex = 1;
            birthdateLabel.Text = "Birthdate:";
            // 
            // genderLabel
            // 
            genderLabel.AutoSize = true;
            genderLabel.Location = new System.Drawing.Point(55, 138);
            genderLabel.Name = "genderLabel";
            genderLabel.Size = new System.Drawing.Size(54, 16);
            genderLabel.TabIndex = 3;
            genderLabel.Text = "Gender:";
            // 
            // homeTownWithPostalCodeLabel
            // 
            homeTownWithPostalCodeLabel.AutoSize = true;
            homeTownWithPostalCodeLabel.Location = new System.Drawing.Point(29, 171);
            homeTownWithPostalCodeLabel.Name = "homeTownWithPostalCodeLabel";
            homeTownWithPostalCodeLabel.Size = new System.Drawing.Size(185, 16);
            homeTownWithPostalCodeLabel.TabIndex = 5;
            homeTownWithPostalCodeLabel.Text = "Home Town With Postal Code:";
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(63, 54);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(46, 16);
            nameLabel.TabIndex = 9;
            nameLabel.Text = "Name:";
            // 
            // sportsClubLabel
            // 
            sportsClubLabel.AutoSize = true;
            sportsClubLabel.Location = new System.Drawing.Point(29, 306);
            sportsClubLabel.Name = "sportsClubLabel";
            sportsClubLabel.Size = new System.Drawing.Size(80, 16);
            sportsClubLabel.TabIndex = 11;
            sportsClubLabel.Text = "Sports Club:";
            // 
            // surnameLabel
            // 
            surnameLabel.AutoSize = true;
            surnameLabel.Location = new System.Drawing.Point(45, 82);
            surnameLabel.Name = "surnameLabel";
            surnameLabel.Size = new System.Drawing.Size(64, 16);
            surnameLabel.TabIndex = 13;
            surnameLabel.Text = "Surname:";
            // 
            // weightLabel
            // 
            weightLabel.AutoSize = true;
            weightLabel.Location = new System.Drawing.Point(56, 276);
            weightLabel.Name = "weightLabel";
            weightLabel.Size = new System.Drawing.Size(53, 16);
            weightLabel.TabIndex = 17;
            weightLabel.Text = "Weight:";
            // 
            // competitorBindingSource
            // 
            this.competitorBindingSource.DataSource = typeof(Judo.Models.Competitor);
            // 
            // competitorBindingNavigator
            // 
            this.competitorBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.competitorBindingNavigator.BindingSource = this.competitorBindingSource;
            this.competitorBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.competitorBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.competitorBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.competitorBindingNavigatorSaveItem});
            this.competitorBindingNavigator.Location = new System.Drawing.Point(7, 80);
            this.competitorBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.competitorBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.competitorBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.competitorBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.competitorBindingNavigator.Name = "competitorBindingNavigator";
            this.competitorBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.competitorBindingNavigator.Size = new System.Drawing.Size(888, 25);
            this.competitorBindingNavigator.TabIndex = 2;
            this.competitorBindingNavigator.Text = "bindingNavigator1";
            this.competitorBindingNavigator.Visible = false;
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // competitorBindingNavigatorSaveItem
            // 
            this.competitorBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.competitorBindingNavigatorSaveItem.Enabled = false;
            this.competitorBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("competitorBindingNavigatorSaveItem.Image")));
            this.competitorBindingNavigatorSaveItem.Name = "competitorBindingNavigatorSaveItem";
            this.competitorBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.competitorBindingNavigatorSaveItem.Text = "Save Data";
            // 
            // competitorDataGridView
            // 
            this.competitorDataGridView.AllowUserToAddRows = false;
            this.competitorDataGridView.AllowUserToDeleteRows = false;
            this.competitorDataGridView.AutoGenerateColumns = false;
            this.competitorDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.competitorDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.competitorDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn9});
            this.competitorDataGridView.DataSource = this.competitorBindingSource;
            this.competitorDataGridView.Dock = System.Windows.Forms.DockStyle.Right;
            this.competitorDataGridView.Location = new System.Drawing.Point(328, 0);
            this.competitorDataGridView.Name = "competitorDataGridView";
            this.competitorDataGridView.ReadOnly = true;
            this.competitorDataGridView.Size = new System.Drawing.Size(568, 389);
            this.competitorDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn1.HeaderText = "Id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn3.HeaderText = "Name";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Surname";
            this.dataGridViewTextBoxColumn4.HeaderText = "Surname";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Gender";
            this.dataGridViewTextBoxColumn9.HeaderText = "Gender";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // birthdateDateTimePicker
            // 
            this.birthdateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.competitorBindingSource, "Birthdate", true));
            this.birthdateDateTimePicker.Location = new System.Drawing.Point(115, 106);
            this.birthdateDateTimePicker.Name = "birthdateDateTimePicker";
            this.birthdateDateTimePicker.Size = new System.Drawing.Size(200, 22);
            this.birthdateDateTimePicker.TabIndex = 2;
            // 
            // genderComboBox
            // 
            this.genderComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.competitorBindingSource, "Gender", true));
            this.genderComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.genderComboBox.FormattingEnabled = true;
            this.genderComboBox.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.genderComboBox.Location = new System.Drawing.Point(115, 134);
            this.genderComboBox.Name = "genderComboBox";
            this.genderComboBox.Size = new System.Drawing.Size(200, 24);
            this.genderComboBox.TabIndex = 4;
            // 
            // homeTownWithPostalCodeTextBox
            // 
            this.homeTownWithPostalCodeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.competitorBindingSource, "HomeTownWithPostalCode", true));
            this.homeTownWithPostalCodeTextBox.Location = new System.Drawing.Point(115, 200);
            this.homeTownWithPostalCodeTextBox.Multiline = true;
            this.homeTownWithPostalCodeTextBox.Name = "homeTownWithPostalCodeTextBox";
            this.homeTownWithPostalCodeTextBox.Size = new System.Drawing.Size(200, 68);
            this.homeTownWithPostalCodeTextBox.TabIndex = 6;
            // 
            // nameTextBox
            // 
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.competitorBindingSource, "Name", true));
            this.nameTextBox.Location = new System.Drawing.Point(115, 50);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(200, 22);
            this.nameTextBox.TabIndex = 10;
            // 
            // sportsClubTextBox
            // 
            this.sportsClubTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.competitorBindingSource, "SportsClub", true));
            this.sportsClubTextBox.Location = new System.Drawing.Point(115, 302);
            this.sportsClubTextBox.Name = "sportsClubTextBox";
            this.sportsClubTextBox.Size = new System.Drawing.Size(200, 22);
            this.sportsClubTextBox.TabIndex = 12;
            // 
            // surnameTextBox
            // 
            this.surnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.competitorBindingSource, "Surname", true));
            this.surnameTextBox.Location = new System.Drawing.Point(115, 78);
            this.surnameTextBox.Name = "surnameTextBox";
            this.surnameTextBox.Size = new System.Drawing.Size(200, 22);
            this.surnameTextBox.TabIndex = 14;
            // 
            // rexaButton2
            // 
            this.rexaButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton2.ForeColor = System.Drawing.Color.White;
            this.rexaButton2.Location = new System.Drawing.Point(159, 7);
            this.rexaButton2.Name = "rexaButton2";
            this.rexaButton2.Size = new System.Drawing.Size(75, 37);
            this.rexaButton2.TabIndex = 17;
            this.rexaButton2.Text = "new";
            this.rexaButton2.UseVisualStyleBackColor = false;
            this.rexaButton2.Click += new System.EventHandler(this.rexaButton2_Click);
            // 
            // rexaButton3
            // 
            this.rexaButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton3.ForeColor = System.Drawing.Color.White;
            this.rexaButton3.Location = new System.Drawing.Point(240, 7);
            this.rexaButton3.Name = "rexaButton3";
            this.rexaButton3.Size = new System.Drawing.Size(75, 37);
            this.rexaButton3.TabIndex = 17;
            this.rexaButton3.Text = "delete";
            this.rexaButton3.UseVisualStyleBackColor = false;
            this.rexaButton3.Click += new System.EventHandler(this.rexaButton3_Click);
            // 
            // rexaButton4
            // 
            this.rexaButton4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton4.ForeColor = System.Drawing.Color.White;
            this.rexaButton4.Location = new System.Drawing.Point(240, 330);
            this.rexaButton4.Name = "rexaButton4";
            this.rexaButton4.Size = new System.Drawing.Size(75, 37);
            this.rexaButton4.TabIndex = 17;
            this.rexaButton4.Text = "save";
            this.rexaButton4.UseVisualStyleBackColor = false;
            this.rexaButton4.Click += new System.EventHandler(this.rexaButton4_Click);
            // 
            // weightNumericUpDown
            // 
            this.weightNumericUpDown.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.competitorBindingSource, "Weight", true));
            this.weightNumericUpDown.DecimalPlaces = 1;
            this.weightNumericUpDown.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.weightNumericUpDown.Location = new System.Drawing.Point(115, 274);
            this.weightNumericUpDown.Name = "weightNumericUpDown";
            this.weightNumericUpDown.Size = new System.Drawing.Size(120, 22);
            this.weightNumericUpDown.TabIndex = 18;
            this.weightNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.weightNumericUpDown.ThousandsSeparator = true;
            // 
            // rexaButton5
            // 
            this.rexaButton5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton5.ForeColor = System.Drawing.Color.White;
            this.rexaButton5.Location = new System.Drawing.Point(78, 7);
            this.rexaButton5.Name = "rexaButton5";
            this.rexaButton5.Size = new System.Drawing.Size(75, 37);
            this.rexaButton5.TabIndex = 17;
            this.rexaButton5.Text = "view";
            this.rexaButton5.UseVisualStyleBackColor = false;
            this.rexaButton5.Click += new System.EventHandler(this.rexaButton5_Click);
            // 
            // Competitors
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(910, 514);
            this.Controls.Add(this.competitorBindingNavigator);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "Competitors";
            this.Padding = new System.Windows.Forms.Padding(7);
            this.Text = "Competitors";
            this.Load += new System.EventHandler(this.Competitors_Load);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.panel3, 0);
            this.Controls.SetChildIndex(this.panel2, 0);
            this.Controls.SetChildIndex(this.competitorBindingNavigator, 0);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.competitorBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.competitorBindingNavigator)).EndInit();
            this.competitorBindingNavigator.ResumeLayout(false);
            this.competitorBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.competitorDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.weightNumericUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.BindingSource competitorBindingSource;
        private System.Windows.Forms.BindingNavigator competitorBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton competitorBindingNavigatorSaveItem;
        private Components.RexaButton rexaButton3;
        private Components.RexaButton rexaButton2;
        private System.Windows.Forms.DateTimePicker birthdateDateTimePicker;
        private System.Windows.Forms.ComboBox genderComboBox;
        private System.Windows.Forms.TextBox homeTownWithPostalCodeTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox sportsClubTextBox;
        private System.Windows.Forms.TextBox surnameTextBox;
        private System.Windows.Forms.DataGridView competitorDataGridView;
        private Components.RexaButton rexaButton4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.NumericUpDown weightNumericUpDown;
        private Components.RexaButton rexaButton5;
    }
}