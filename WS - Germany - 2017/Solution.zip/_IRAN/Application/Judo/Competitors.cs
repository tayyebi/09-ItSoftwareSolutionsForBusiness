﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Judo
{
    public partial class Competitors : Master
    {
        public Competitors()
        {
            InitializeComponent();
        }
        private void myRefresh()
        {
            db = new Models.MainModel();
            db.Competitors.ToList();
            competitorBindingSource.DataSource = db.Competitors.Local;
            competitorBindingSource.ResetBindings(true);
        }
        private void Competitors_Load(object sender, EventArgs e)
        {
            myRefresh();
        }

        private void rexaButton3_Click(object sender, EventArgs e)
        {
            competitorBindingSource.RemoveCurrent();
        }

        private void rexaButton4_Click(object sender, EventArgs e)
        {
            db.SaveChanges();
            myRefresh();
        }

        private void rexaButton2_Click(object sender, EventArgs e)
        {
            competitorBindingSource.AddNew();
        }

        private void rexaButton5_Click(object sender, EventArgs e)
        {
            new Reports.CompetitorsView().ShowDialog();
        }
    }
}
