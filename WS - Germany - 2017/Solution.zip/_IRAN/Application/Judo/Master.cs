﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Judo
{
    public partial class Master : Form
    {
        public Models.MainModel db = new Models.MainModel();
        public Master()
        {
            InitializeComponent();
        }

        private void Master_Load(object sender, EventArgs e)
        {

        }

        private void rexaButton1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
