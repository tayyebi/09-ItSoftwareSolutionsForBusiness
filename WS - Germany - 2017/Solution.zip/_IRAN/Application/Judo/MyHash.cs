﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Judo
{
    class MyHash
    {
        public string GetBase25(int number)
        {
            List<Tuple<int, char>> remains = new List<Tuple<int, char>>();

            int theBase = Convert.ToInt16('Z')- Convert.ToInt16('A'); // 25
            int i = 0;
            while (number > theBase)
            {
                int devide = number / theBase;
                int remain = number - (devide * theBase);
                char ascii = Convert.ToChar(remain -1+ Convert.ToInt16('A'));
                remains.Add(new Tuple<int, char>(i, ascii));
                number = devide;
                i++;
            }
            if (number <= theBase)
            {
                remains.Add(new Tuple<int, char>(i, Convert.ToChar(number-1 + Convert.ToInt16('A'))));
            }

            return remains.OrderByDescending(x => x.Item1).Select(x => x.Item2).Aggregate(string.Empty, (current, next) => current + next);
        }
        public string GetMd5(string input)
        {
            return input;
        }
    }
}
