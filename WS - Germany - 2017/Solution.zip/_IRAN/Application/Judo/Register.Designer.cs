﻿namespace Judo
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.rexaTextBox2 = new Judo.Components.RexaTextBox(this.components);
            this.rexaTextBox1 = new Judo.Components.RexaTextBox(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.rexaTextBox3 = new Judo.Components.RexaTextBox(this.components);
            this.rexaButton3 = new Judo.Components.RexaButton(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(7, 7);
            this.panel1.Size = new System.Drawing.Size(719, 73);
            // 
            // label1
            // 
            this.label1.Size = new System.Drawing.Size(653, 73);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(653, 0);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rexaTextBox3);
            this.panel2.Controls.Add(this.rexaTextBox2);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.rexaTextBox1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(7, 80);
            this.panel2.Size = new System.Drawing.Size(719, 358);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.rexaButton3);
            this.panel3.Location = new System.Drawing.Point(7, 438);
            this.panel3.Size = new System.Drawing.Size(719, 38);
            this.panel3.Controls.SetChildIndex(this.rexaButton1, 0);
            this.panel3.Controls.SetChildIndex(this.rexaButton3, 0);
            // 
            // rexaButton1
            // 
            this.rexaButton1.Location = new System.Drawing.Point(624, 0);
            // 
            // rexaTextBox2
            // 
            this.rexaTextBox2.BackColor = System.Drawing.Color.White;
            this.rexaTextBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaTextBox2.Location = new System.Drawing.Point(329, 148);
            this.rexaTextBox2.Name = "rexaTextBox2";
            this.rexaTextBox2.PasswordChar = '•';
            this.rexaTextBox2.Size = new System.Drawing.Size(157, 22);
            this.rexaTextBox2.TabIndex = 1;
            // 
            // rexaTextBox1
            // 
            this.rexaTextBox1.BackColor = System.Drawing.Color.White;
            this.rexaTextBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaTextBox1.Location = new System.Drawing.Point(329, 92);
            this.rexaTextBox1.Name = "rexaTextBox1";
            this.rexaTextBox1.Size = new System.Drawing.Size(157, 22);
            this.rexaTextBox1.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(254, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Password:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(252, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Username:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(219, 209);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Password agian:";
            // 
            // rexaTextBox3
            // 
            this.rexaTextBox3.BackColor = System.Drawing.Color.White;
            this.rexaTextBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaTextBox3.Location = new System.Drawing.Point(329, 206);
            this.rexaTextBox3.Name = "rexaTextBox3";
            this.rexaTextBox3.PasswordChar = '•';
            this.rexaTextBox3.Size = new System.Drawing.Size(157, 22);
            this.rexaTextBox3.TabIndex = 2;
            // 
            // rexaButton3
            // 
            this.rexaButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton3.Dock = System.Windows.Forms.DockStyle.Right;
            this.rexaButton3.ForeColor = System.Drawing.Color.White;
            this.rexaButton3.Location = new System.Drawing.Point(459, 0);
            this.rexaButton3.Name = "rexaButton3";
            this.rexaButton3.Size = new System.Drawing.Size(165, 38);
            this.rexaButton3.TabIndex = 0;
            this.rexaButton3.Text = "Register";
            this.rexaButton3.UseVisualStyleBackColor = false;
            this.rexaButton3.Click += new System.EventHandler(this.rexaButton3_Click);
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(733, 483);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "Register";
            this.Padding = new System.Windows.Forms.Padding(7);
            this.Text = "Register";
            this.Load += new System.EventHandler(this.Register_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Components.RexaTextBox rexaTextBox3;
        private Components.RexaTextBox rexaTextBox2;
        private System.Windows.Forms.Label label4;
        private Components.RexaTextBox rexaTextBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private Components.RexaButton rexaButton3;
    }
}