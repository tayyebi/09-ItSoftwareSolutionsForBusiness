﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Judo
{
    static class Program
    {

        static public Models.ProgramUser myUser { get; set; }


        [STAThread]
        static void Main()
        {
            Application.ThreadException +=(sender, args)  => MyError(sender, args.Exception);
            AppDomain.CurrentDomain.UnhandledException += (sender, args) => MyError(sender, args.ExceptionObject as Exception);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Login());
        }

        private static void MyError(object sender, Exception e)
        {
            MessageBox.Show("There was something wrong.\r\n" + e.Message);
        }
    }
}
