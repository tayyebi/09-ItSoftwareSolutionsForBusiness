﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Judo
{
    public partial class Register : Master
    {
        bool change_password = false;
        public Register(bool ChangePass = false)
        {
            InitializeComponent();
            change_password = ChangePass;
        }

        private void Register_Load(object sender, EventArgs e)
        {
            if (change_password)
            {
                rexaButton3.Text = "Change Password";
                rexaTextBox1.ReadOnly = true;
                rexaTextBox1.Text = Program.myUser.Username;
                rexaTextBox1.BackColor = rexaTextBox2.BackColor;
            }
        }

        private void rexaButton3_Click(object sender, EventArgs e)
        {
            if (rexaTextBox2.Text != rexaTextBox3.Text)
            {
                MessageBox.Show("Mismatch on password and its confirm");
                return;
            }
            if (change_password)
            {
                db.ProgramUsers.Attach(Program.myUser);
                Program.myUser.Password = rexaTextBox2.Text;
                db.SaveChanges();
                Close();
                return;
            }
            db.ProgramUsers.Add(
            new Models.ProgramUser
            {
                Password = rexaTextBox2.Text,
                Username = rexaTextBox1.Text,
                Role = "User"
            }
            );
            db.SaveChanges();
            MessageBox.Show("Done!");
            Close();
        }
    }
}
