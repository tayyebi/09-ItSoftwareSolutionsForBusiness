﻿namespace Judo
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rexaTextBox1 = new Judo.Components.RexaTextBox(this.components);
            this.rexaTextBox2 = new Judo.Components.RexaTextBox(this.components);
            this.rexaButton2 = new Judo.Components.RexaButton(this.components);
            this.rexaButton3 = new Judo.Components.RexaButton(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(7, 7);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rexaTextBox2);
            this.panel2.Controls.Add(this.rexaTextBox1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(7, 80);
            this.panel2.Size = new System.Drawing.Size(776, 361);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.rexaButton3);
            this.panel3.Controls.Add(this.rexaButton2);
            this.panel3.Location = new System.Drawing.Point(7, 441);
            this.panel3.Controls.SetChildIndex(this.rexaButton1, 0);
            this.panel3.Controls.SetChildIndex(this.rexaButton2, 0);
            this.panel3.Controls.SetChildIndex(this.rexaButton3, 0);
            // 
            // rexaButton1
            // 
            this.rexaButton1.BackColor = System.Drawing.Color.White;
            this.rexaButton1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton1.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(266, 179);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Password:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(264, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Username:";
            // 
            // rexaTextBox1
            // 
            this.rexaTextBox1.BackColor = System.Drawing.Color.White;
            this.rexaTextBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaTextBox1.Location = new System.Drawing.Point(341, 120);
            this.rexaTextBox1.Name = "rexaTextBox1";
            this.rexaTextBox1.Size = new System.Drawing.Size(157, 22);
            this.rexaTextBox1.TabIndex = 0;
            this.rexaTextBox1.Text = "admin";
            // 
            // rexaTextBox2
            // 
            this.rexaTextBox2.BackColor = System.Drawing.Color.White;
            this.rexaTextBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaTextBox2.Location = new System.Drawing.Point(341, 176);
            this.rexaTextBox2.Name = "rexaTextBox2";
            this.rexaTextBox2.PasswordChar = '•';
            this.rexaTextBox2.Size = new System.Drawing.Size(157, 22);
            this.rexaTextBox2.TabIndex = 1;
            this.rexaTextBox2.Text = "admin";
            // 
            // rexaButton2
            // 
            this.rexaButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton2.Dock = System.Windows.Forms.DockStyle.Right;
            this.rexaButton2.ForeColor = System.Drawing.Color.White;
            this.rexaButton2.Location = new System.Drawing.Point(583, 0);
            this.rexaButton2.Name = "rexaButton2";
            this.rexaButton2.Size = new System.Drawing.Size(98, 38);
            this.rexaButton2.TabIndex = 1;
            this.rexaButton2.Text = "Login";
            this.rexaButton2.UseVisualStyleBackColor = false;
            this.rexaButton2.Click += new System.EventHandler(this.rexaButton2_Click);
            // 
            // rexaButton3
            // 
            this.rexaButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton3.Dock = System.Windows.Forms.DockStyle.Right;
            this.rexaButton3.ForeColor = System.Drawing.Color.White;
            this.rexaButton3.Location = new System.Drawing.Point(485, 0);
            this.rexaButton3.Name = "rexaButton3";
            this.rexaButton3.Size = new System.Drawing.Size(98, 38);
            this.rexaButton3.TabIndex = 0;
            this.rexaButton3.Text = "Register";
            this.rexaButton3.UseVisualStyleBackColor = false;
            this.rexaButton3.Click += new System.EventHandler(this.rexaButton3_Click);
            // 
            // Login
            // 
            this.AcceptButton = this.rexaButton2;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(790, 486);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "Login";
            this.Padding = new System.Windows.Forms.Padding(7);
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private Components.RexaTextBox rexaTextBox2;
        private Components.RexaTextBox rexaTextBox1;
        private Components.RexaButton rexaButton2;
        private Components.RexaButton rexaButton3;
    }
}

