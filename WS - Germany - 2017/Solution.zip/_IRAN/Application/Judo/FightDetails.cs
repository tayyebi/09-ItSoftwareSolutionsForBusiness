﻿using Judo.Components;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Judo
{
    public partial class FightDetails : Master
    {
        public FightDetails()
        {
            InitializeComponent();
        }

        public List<Models.Fight> Fights;
        public int CurrentIndex { get; set; }



        private void FightDetails_Load(object sender, EventArgs e)
        {
            MyRefresh();
        }

        private int holding;

        public int Holding
        {
            get { return holding; }
            set
            {
                label5.Text =
                label25.Text =
                value.ToString();

                holding = value;
            }
        }

        private int time;

        public int Time
        {
            get { return time; }
            set
            {
                label7.Text =
                label26.Text =
                value.ToString();

                time = value;
            }
        }

        public void MyRefresh()
        {
            if (Fights.Count > CurrentIndex)
            {
                label11.Text = $"U{Fights[CurrentIndex + 1].GroupAgeClass} – {Fights[CurrentIndex + 1].GroupGenderClass.Substring(0, 1)} – {Fights[CurrentIndex + 1].GroupWeightClass} kg";

                var next_redCompetitorId = Fights[CurrentIndex + 1].RedCompetitorId;
                var next_whiteCompetitorId = Fights[CurrentIndex + 1].WhiteCompetitorId;

                var next_red_competitor =
                    db.Competitors.Where(x => x.Id == next_redCompetitorId).FirstOrDefault();
                label9.Text = next_red_competitor.Name +
                    " " + next_red_competitor.Surname;

                var next_white_competitor =
                    db.Competitors.Where(x => x.Id == next_whiteCompetitorId).FirstOrDefault();
                label10.Text = next_white_competitor.Name +
                    " " + next_white_competitor.Surname;

                label34.Text = Fights[CurrentIndex + 1].MatNumber.ToString();
                label2.Text = Fights[CurrentIndex].MatNumber.ToString();


                label13.Text = $"U{Fights[CurrentIndex].GroupAgeClass} – {Fights[CurrentIndex].GroupGenderClass.Substring(0, 1)} – {Fights[CurrentIndex].GroupWeightClass} kg";

                int redCompetitorId = Fights[CurrentIndex].RedCompetitorId;
                int whiteCompetitorId = Fights[CurrentIndex].WhiteCompetitorId;

                var red_competitor =
                    db.Competitors.Where(x => x.Id == redCompetitorId).FirstOrDefault();
                label12.Text = red_competitor.Name +
                    " " + red_competitor.Surname;

                var white_competitor =
                    db.Competitors.Where(x => x.Id == whiteCompetitorId).FirstOrDefault();
                label14.Text = white_competitor.Name +
                    " " + white_competitor.Surname;

                var fight_id =
                    Fights[CurrentIndex].Id;

                var fight_details =
                    db.FightDetails.Where(
                        x => x.FightId == fight_id
                        ).ToList();

                label17.Text = fight_details.Count(x => x.Name == "Ippon" && x.CompetitorId == redCompetitorId).ToString();
                label18.Text = fight_details.Count(x => x.Name == "Waza-ari" && x.CompetitorId == redCompetitorId).ToString();
                label19.Text = fight_details.Count(x => x.Name == "Warning" && x.CompetitorId == redCompetitorId).ToString();

                label20.Text = fight_details.Count(x => x.Name == "Ippon" && x.CompetitorId == whiteCompetitorId).ToString();
                label21.Text = fight_details.Count(x => x.Name == "Waza-ari" && x.CompetitorId == whiteCompetitorId).ToString();
                label22.Text = fight_details.Count(x => x.Name == "Warning" && x.CompetitorId == whiteCompetitorId).ToString();

                holding = Fights[CurrentIndex].HoldingTimeInSeconds;
                time = Fights[CurrentIndex].TimeInSeconds;

                var fight = db.Fights.Find(Fights[CurrentIndex].Id);
                fight.Status = "Battle";
                db.Entry(fight).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
        }
        private void timer_small_Tick(object sender, EventArgs e)
        {
            Holding++;
        }

        private void timer_large_Tick(object sender, EventArgs e)
        {
            Time++;
        }

        private void rexaButton11_Click(object sender, EventArgs e)
        {
            if (timer_large.Enabled)
            {
                timer_large.Enabled = false;
                timer_small.Enabled = true;
            }
            else
            {
                timer_large.Enabled = true;
                timer_small.Enabled = false;
            }

        }

        private void rexaButton10_Click(object sender, EventArgs e)
        {
            if (timer_small.Enabled)
            {
                timer_small.Enabled = false;
                timer_large.Enabled = true;

            }
            else
            {
                timer_small.Enabled = true;
                timer_large.Enabled = false;

            }
        }

        private void rexaButton8_Click(object sender, EventArgs e)
        {
            var btn = (sender as RexaButton);

            int point = 0;

            switch (btn.Text)
            {
                case "Waza-ari":
                    point = 2;
                    break;
                case "Ippon":
                    point = 1;
                    break;
                case "Warning":
                    point = -1;
                    break;
            }

            db.FightDetails.Add(new Models.FightDetail
            {
                CompetitorId = btn.BackColor == rexaButton3.BackColor ?
                    Fights[CurrentIndex].RedCompetitorId :
                    Fights[CurrentIndex].WhiteCompetitorId,
                Name = btn.Text,
                TimeInSeconds = time + holding,
                FightId = Fights[CurrentIndex].Id,
                Point = point
            }
            );
            db.SaveChanges();

            MyRefresh();
        }

        private void rexaButton9_Click(object sender, EventArgs e)
        {
            var fight_id = Fights[CurrentIndex].Id;
            var detail = db.FightDetails
                .Where(x => x.FightId == fight_id)
                .OrderByDescending(x => x.Id)
                .FirstOrDefault();

            if (detail == null)
                return;

            if (
                    MessageBox.Show($"Are you sure to discard {detail.Name}({detail.Point})?", "Really?", MessageBoxButtons.OKCancel)
                    ==
                    DialogResult.Cancel
                )
                return;
            db.FightDetails.Remove(detail);
            db.SaveChanges();
            MyRefresh();
        }

        private void rexaButton2_Click(object sender, EventArgs e)
        {
            var fight = db.Fights.Find(Fights[CurrentIndex].Id);
            fight.Status = "End";
            fight.TimeInSeconds = time;
            fight.HoldingTimeInSeconds = holding;


            var fight_id = Fights[CurrentIndex].Id;
            var details = db.FightDetails
                .Where(x => x.FightId == fight_id)
                .ToList();


            int redCompetitorId = Fights[CurrentIndex].RedCompetitorId;
            int whiteCompetitorId = Fights[CurrentIndex].WhiteCompetitorId;


            decimal sum_red_points = details.
                Where(x => x.CompetitorId == redCompetitorId)
                .Sum(x => x.Point);
            decimal sum_white_points = details.
                Where(x => x.CompetitorId == whiteCompetitorId)
                .Sum(x => x.Point);

            decimal score = sum_red_points - sum_white_points < 0 ?
                sum_white_points - sum_red_points :
                sum_red_points - sum_white_points;


            if (sum_red_points > 0)
            {
                fight.RedCompetitorPoints = score;
                fight.WhiteCompetitorPoints = score * -1;
            }
            else if (sum_white_points > 0)
            {
                fight.WhiteCompetitorPoints = score;
                fight.RedCompetitorPoints = score * -1;
            }

            db.Entry(fight).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();

            CurrentIndex++;
            MyRefresh();
        }
    }
}
