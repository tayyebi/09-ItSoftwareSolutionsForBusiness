﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Judo
{
    public partial class PosterGenerator : Master
    {
        public PosterGenerator()
        {
            InitializeComponent();
        }

        private void PosterGenerator_Load(object sender, EventArgs e)
        {

        }

        List<string> FileNames = new List<string>();

        private void rexaButton2_Click(object sender, EventArgs e)
        {
            flowLayoutPanel1.Controls.Clear();

            var ofd = new OpenFileDialog();
            ofd.Filter = "All files|*";
            ofd.Multiselect = true;
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                foreach (var item in ofd.FileNames)
                {
                    var p = new PictureBox();
                    p.Size = new Size(100, 100);
                    p.BackgroundImage = Image.FromFile(item);
                    FileNames.Add(item);
                    p.BackgroundImageLayout = ImageLayout.Zoom;
                    flowLayoutPanel1.Controls.Add(p);
                }
            }
        }

        private void rexaButton3_Click(object sender, EventArgs e)
        {
            var frm = new Reports.PosterView();

            frm.PosterLayoutBindingSource.DataSource = FileNames
                .Select(x => new Reports.PosterLayout
                {
                    FileName = x,
                    Image = File.ReadAllBytes(x),
                    // MyImage= Image.FromFile(x)

                })
                .ToList();
            frm.reportViewer1.LocalReport.EnableExternalImages = true;
            frm.reportViewer1.RefreshReport();

            frm.ShowDialog();
        }
    }
}
