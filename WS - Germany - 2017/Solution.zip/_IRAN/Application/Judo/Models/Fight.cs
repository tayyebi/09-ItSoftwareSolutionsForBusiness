namespace Judo.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Fight
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Fight()
        {
            FightDetails = new HashSet<FightDetail>();
        }

        public long Id { get; set; }

        [Required]
        [StringLength(4)]
        public string GroupName { get; set; }

        [Required]
        [StringLength(4)]
        public string SubGroupName { get; set; }

        public int GroupAgeClass { get; set; }

        [Required]
        [StringLength(6)]
        public string GroupGenderClass { get; set; }

        public int GroupWeightClass { get; set; }

        public int WhiteCompetitorId { get; set; }

        public int RedCompetitorId { get; set; }

        public decimal? WhiteCompetitorPoints { get; set; }

        public decimal? RedCompetitorPoints { get; set; }

        public int MatNumber { get; set; }

        [Required]
        [StringLength(10)]
        public string Status { get; set; }

        public int TimeInSeconds { get; set; }

        public int HoldingTimeInSeconds { get; set; }

        public virtual Competitor Competitor { get; set; }

        public virtual Competitor Competitor1 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<FightDetail> FightDetails { get; set; }
    }
}
