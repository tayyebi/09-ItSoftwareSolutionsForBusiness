namespace Judo.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class MainModel : DbContext
    {
        public MainModel()
            : base("name=MainModel")
        {
        }

        public virtual DbSet<Competitor> Competitors { get; set; }
        public virtual DbSet<FightDetail> FightDetails { get; set; }
        public virtual DbSet<Fight> Fights { get; set; }
        public virtual DbSet<ProgramUser> ProgramUsers { get; set; }
        public virtual DbSet<sysdiagram> sysdiagrams { get; set; }
        public virtual DbSet<View_Competitors> View_Competitors { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Competitor>()
                .Property(e => e.Weight)
                .HasPrecision(4, 1);

            modelBuilder.Entity<Competitor>()
                .Property(e => e.Gender)
                .IsUnicode(false);

            modelBuilder.Entity<Competitor>()
                .HasMany(e => e.FightDetails)
                .WithRequired(e => e.Competitor)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Competitor>()
                .HasMany(e => e.Fights)
                .WithRequired(e => e.Competitor)
                .HasForeignKey(e => e.WhiteCompetitorId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Competitor>()
                .HasMany(e => e.Fights1)
                .WithRequired(e => e.Competitor1)
                .HasForeignKey(e => e.RedCompetitorId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<FightDetail>()
                .Property(e => e.Point)
                .HasPrecision(4, 2);

            modelBuilder.Entity<Fight>()
                .Property(e => e.GroupName)
                .IsUnicode(false);

            modelBuilder.Entity<Fight>()
                .Property(e => e.SubGroupName)
                .IsUnicode(false);

            modelBuilder.Entity<Fight>()
                .Property(e => e.GroupGenderClass)
                .IsUnicode(false);

            modelBuilder.Entity<Fight>()
                .Property(e => e.WhiteCompetitorPoints)
                .HasPrecision(5, 1);

            modelBuilder.Entity<Fight>()
                .Property(e => e.RedCompetitorPoints)
                .HasPrecision(5, 1);

            modelBuilder.Entity<Fight>()
                .Property(e => e.Status)
                .IsUnicode(false);

            modelBuilder.Entity<Fight>()
                .HasMany(e => e.FightDetails)
                .WithRequired(e => e.Fight)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<View_Competitors>()
                .Property(e => e.Weight)
                .HasPrecision(4, 1);

            modelBuilder.Entity<View_Competitors>()
                .Property(e => e.Gender)
                .IsUnicode(false);

        }
    }
}
