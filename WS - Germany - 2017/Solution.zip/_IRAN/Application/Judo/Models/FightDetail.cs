namespace Judo.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class FightDetail
    {
        public long Id { get; set; }

        public long FightId { get; set; }

        [Required]
        [StringLength(50)]
        public string Name { get; set; }

        public decimal Point { get; set; }

        public int CompetitorId { get; set; }

        public int TimeInSeconds { get; set; }

        public virtual Competitor Competitor { get; set; }

        public virtual Fight Fight { get; set; }
    }
}
