namespace Judo.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class View_Competitors
    {
        public int Id { get; set; }

        [Column(TypeName = "xml")]
        public string OtherData { get; set; }

        [StringLength(50)]
        public string Name { get; set; }

        [StringLength(50)]
        public string Surname { get; set; }

        public DateTime? Birthdate { get; set; }

        [StringLength(50)]
        public string SportsClub { get; set; }

        [StringLength(500)]
        public string HomeTownWithPostalCode { get; set; }

        public decimal? Weight { get; set; }

        public int? weightClass { get; set; }

        public int? Age { get; set; }

        public int? AgeClass { get; set; }

        [StringLength(6)]
        public string Gender { get; set; }
    }
}
