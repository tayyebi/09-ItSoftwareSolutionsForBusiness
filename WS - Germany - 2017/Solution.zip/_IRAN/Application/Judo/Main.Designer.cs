﻿namespace Judo
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.rexaButton2 = new Judo.Components.RexaButton(this.components);
            this.rexaButton3 = new Judo.Components.RexaButton(this.components);
            this.rexaButton4 = new Judo.Components.RexaButton(this.components);
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.rexaButton5 = new Judo.Components.RexaButton(this.components);
            this.rexaButton6 = new Judo.Components.RexaButton(this.components);
            this.rexaButton7 = new Judo.Components.RexaButton(this.components);
            this.rexaButton8 = new Judo.Components.RexaButton(this.components);
            this.rexaButton9 = new Judo.Components.RexaButton(this.components);
            this.rexaButton10 = new Judo.Components.RexaButton(this.components);
            this.rexaButton11 = new Judo.Components.RexaButton(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(7, 7);
            this.panel1.Size = new System.Drawing.Size(750, 73);
            // 
            // label1
            // 
            this.label1.Size = new System.Drawing.Size(684, 73);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(684, 0);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.numericUpDown1);
            this.panel2.Controls.Add(this.rexaButton7);
            this.panel2.Controls.Add(this.rexaButton3);
            this.panel2.Controls.Add(this.rexaButton8);
            this.panel2.Controls.Add(this.rexaButton5);
            this.panel2.Controls.Add(this.rexaButton6);
            this.panel2.Controls.Add(this.rexaButton4);
            this.panel2.Controls.Add(this.rexaButton2);
            this.panel2.Location = new System.Drawing.Point(7, 80);
            this.panel2.Size = new System.Drawing.Size(750, 362);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.rexaButton11);
            this.panel3.Controls.Add(this.rexaButton10);
            this.panel3.Controls.Add(this.rexaButton9);
            this.panel3.Location = new System.Drawing.Point(7, 442);
            this.panel3.Size = new System.Drawing.Size(750, 38);
            this.panel3.Controls.SetChildIndex(this.rexaButton1, 0);
            this.panel3.Controls.SetChildIndex(this.rexaButton9, 0);
            this.panel3.Controls.SetChildIndex(this.rexaButton10, 0);
            this.panel3.Controls.SetChildIndex(this.rexaButton11, 0);
            // 
            // rexaButton1
            // 
            this.rexaButton1.BackColor = System.Drawing.Color.White;
            this.rexaButton1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton1.Location = new System.Drawing.Point(684, 0);
            this.rexaButton1.Size = new System.Drawing.Size(66, 38);
            // 
            // rexaButton2
            // 
            this.rexaButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton2.ForeColor = System.Drawing.Color.White;
            this.rexaButton2.Location = new System.Drawing.Point(61, 7);
            this.rexaButton2.Name = "rexaButton2";
            this.rexaButton2.Size = new System.Drawing.Size(289, 78);
            this.rexaButton2.TabIndex = 0;
            this.rexaButton2.Text = "Change Password";
            this.rexaButton2.UseVisualStyleBackColor = false;
            this.rexaButton2.Click += new System.EventHandler(this.rexaButton2_Click);
            // 
            // rexaButton3
            // 
            this.rexaButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton3.ForeColor = System.Drawing.Color.White;
            this.rexaButton3.Location = new System.Drawing.Point(417, 7);
            this.rexaButton3.Name = "rexaButton3";
            this.rexaButton3.Size = new System.Drawing.Size(289, 78);
            this.rexaButton3.TabIndex = 0;
            this.rexaButton3.Text = "Register another user";
            this.rexaButton3.UseVisualStyleBackColor = false;
            this.rexaButton3.Click += new System.EventHandler(this.rexaButton3_Click);
            // 
            // rexaButton4
            // 
            this.rexaButton4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton4.ForeColor = System.Drawing.Color.White;
            this.rexaButton4.Location = new System.Drawing.Point(61, 91);
            this.rexaButton4.Name = "rexaButton4";
            this.rexaButton4.Size = new System.Drawing.Size(289, 78);
            this.rexaButton4.TabIndex = 0;
            this.rexaButton4.Text = "Competitors";
            this.rexaButton4.UseVisualStyleBackColor = false;
            this.rexaButton4.Click += new System.EventHandler(this.rexaButton4_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown1.Location = new System.Drawing.Point(609, 110);
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(86, 35);
            this.numericUpDown1.TabIndex = 1;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown1.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 18F);
            this.label2.Location = new System.Drawing.Point(431, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 27);
            this.label2.TabIndex = 2;
            this.label2.Text = "MATS COUNT:";
            // 
            // rexaButton5
            // 
            this.rexaButton5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton5.ForeColor = System.Drawing.Color.White;
            this.rexaButton5.Location = new System.Drawing.Point(417, 175);
            this.rexaButton5.Name = "rexaButton5";
            this.rexaButton5.Size = new System.Drawing.Size(289, 78);
            this.rexaButton5.TabIndex = 0;
            this.rexaButton5.Text = "Generate Fights";
            this.rexaButton5.UseVisualStyleBackColor = false;
            this.rexaButton5.Click += new System.EventHandler(this.rexaButton5_Click);
            // 
            // rexaButton6
            // 
            this.rexaButton6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton6.ForeColor = System.Drawing.Color.White;
            this.rexaButton6.Location = new System.Drawing.Point(61, 259);
            this.rexaButton6.Name = "rexaButton6";
            this.rexaButton6.Size = new System.Drawing.Size(289, 78);
            this.rexaButton6.TabIndex = 0;
            this.rexaButton6.Text = "Fights";
            this.rexaButton6.UseVisualStyleBackColor = false;
            this.rexaButton6.Click += new System.EventHandler(this.rexaButton6_Click);
            // 
            // rexaButton7
            // 
            this.rexaButton7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton7.ForeColor = System.Drawing.Color.White;
            this.rexaButton7.Location = new System.Drawing.Point(417, 259);
            this.rexaButton7.Name = "rexaButton7";
            this.rexaButton7.Size = new System.Drawing.Size(289, 78);
            this.rexaButton7.TabIndex = 0;
            this.rexaButton7.Text = "Mats";
            this.rexaButton7.UseVisualStyleBackColor = false;
            this.rexaButton7.Click += new System.EventHandler(this.rexaButton7_Click);
            // 
            // rexaButton8
            // 
            this.rexaButton8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton8.ForeColor = System.Drawing.Color.White;
            this.rexaButton8.Location = new System.Drawing.Point(61, 175);
            this.rexaButton8.Name = "rexaButton8";
            this.rexaButton8.Size = new System.Drawing.Size(289, 78);
            this.rexaButton8.TabIndex = 0;
            this.rexaButton8.Text = "Import Data";
            this.rexaButton8.UseVisualStyleBackColor = false;
            this.rexaButton8.Click += new System.EventHandler(this.rexaButton8_Click);
            // 
            // rexaButton9
            // 
            this.rexaButton9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton9.Dock = System.Windows.Forms.DockStyle.Right;
            this.rexaButton9.ForeColor = System.Drawing.Color.White;
            this.rexaButton9.Location = new System.Drawing.Point(578, 0);
            this.rexaButton9.Name = "rexaButton9";
            this.rexaButton9.Size = new System.Drawing.Size(106, 38);
            this.rexaButton9.TabIndex = 2;
            this.rexaButton9.Text = "Details";
            this.rexaButton9.UseVisualStyleBackColor = false;
            this.rexaButton9.Click += new System.EventHandler(this.rexaButton9_Click);
            // 
            // rexaButton10
            // 
            this.rexaButton10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton10.Dock = System.Windows.Forms.DockStyle.Right;
            this.rexaButton10.ForeColor = System.Drawing.Color.White;
            this.rexaButton10.Location = new System.Drawing.Point(472, 0);
            this.rexaButton10.Name = "rexaButton10";
            this.rexaButton10.Size = new System.Drawing.Size(106, 38);
            this.rexaButton10.TabIndex = 3;
            this.rexaButton10.Text = "Certificates";
            this.rexaButton10.UseVisualStyleBackColor = false;
            this.rexaButton10.Click += new System.EventHandler(this.rexaButton10_Click);
            // 
            // rexaButton11
            // 
            this.rexaButton11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton11.Dock = System.Windows.Forms.DockStyle.Right;
            this.rexaButton11.ForeColor = System.Drawing.Color.White;
            this.rexaButton11.Location = new System.Drawing.Point(366, 0);
            this.rexaButton11.Name = "rexaButton11";
            this.rexaButton11.Size = new System.Drawing.Size(106, 38);
            this.rexaButton11.TabIndex = 4;
            this.rexaButton11.Text = "Poster";
            this.rexaButton11.UseVisualStyleBackColor = false;
            this.rexaButton11.Click += new System.EventHandler(this.rexaButton11_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(764, 487);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "Main";
            this.Padding = new System.Windows.Forms.Padding(7);
            this.Text = "Control";
            this.Load += new System.EventHandler(this.Main_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Components.RexaButton rexaButton3;
        private Components.RexaButton rexaButton2;
        private Components.RexaButton rexaButton4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private Components.RexaButton rexaButton5;
        private Components.RexaButton rexaButton7;
        private Components.RexaButton rexaButton6;
        private Components.RexaButton rexaButton8;
        private Components.RexaButton rexaButton10;
        private Components.RexaButton rexaButton9;
        private Components.RexaButton rexaButton11;
    }
}