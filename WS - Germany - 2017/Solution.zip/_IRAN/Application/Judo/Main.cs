﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Judo
{
    public partial class Main : Master
    {
        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }

        private void rexaButton3_Click(object sender, EventArgs e)
        {
            Hide();
            new Register().ShowDialog();
            Show();
        }

        private void rexaButton2_Click(object sender, EventArgs e)
        {
            Hide();
            new Register(true).ShowDialog();
            Show();
        }

        private void rexaButton4_Click(object sender, EventArgs e)
        {
            Hide();
            new Competitors().ShowDialog();
            Show();
        }

        private void rexaButton5_Click(object sender, EventArgs e)
        {
            // List<Models.Fight> fights = new List<Models.Fight>();

            if (MessageBox.Show("Your previous fight and mat table will be lost. Are you sure to continue?", "WARNING!", MessageBoxButtons.YesNo) == DialogResult.No)
                return;

            db.FightDetails.RemoveRange(db.FightDetails);
            db.Fights.RemoveRange(db.Fights);

            var groups = (
                from a in db.View_Competitors
                group a by new { a.Gender, a.AgeClass, a.weightClass }
                into g
                select g
                ).ToList();

            //Random rand = new Random();
            int mat_number = 0;
            int group = 0;
            foreach (var competitors in groups.OrderByDescending(x => x.Count()))
            {
                group++;
                if (mat_number == numericUpDown1.Value)
                    mat_number = 0;
                mat_number++;
                var this_group_competitors = competitors.ToList();
                int subgroups_count = (this_group_competitors.Count / 3);
                for (int subgroup = 0; subgroup < subgroups_count; subgroup++)
                {

                    for (int i = 0; i < 3; i++)
                    {
                        int competitor_index = ((subgroup + 1) * 3) - ((3 - i) < 0 ? (i - 3) : (3 - i));


                        var fight = new Models.Fight();
                        fight.GroupGenderClass = competitors.Key.Gender;
                        fight.GroupWeightClass = competitors.Key.weightClass ?? 0;
                        fight.GroupAgeClass = competitors.Key.AgeClass ?? 0;
                        //fight.GroupName = "Group " + fight.GroupGenderClass + " ~" + fight.GroupWeightClass.ToString() + "kg, AGE: " + fight.GroupAgeClass;
                        fight.GroupName = new MyHash().GetBase25(group);
                        fight.SubGroupName = (subgroup + 1).ToString();
                        fight.MatNumber = mat_number;
                        fight.Status = "Scheduled";
                        fight.TimeInSeconds = fight.HoldingTimeInSeconds = 0;

                        int first_competitor = this_group_competitors[competitor_index].Id;
                        int second_competitor;
                        if (i + 1 == 3)
                        {
                            second_competitor = this_group_competitors[0].Id;
                        }
                        else
                        {
                            second_competitor = this_group_competitors[competitor_index + 1].Id;
                        }


                        fight.WhiteCompetitorId = first_competitor;
                        fight.RedCompetitorId = second_competitor;

                        //fight.WhiteCompetitorPoints = rand.Next(1, 100);
                        //fight.RedCompetitorPoints = rand.Next(1, 100);

                        fight.WhiteCompetitorPoints = 0;
                        fight.RedCompetitorPoints = 0;

                        // fights.Add(fight);
                        db.Fights.Add(fight);
                    }


                }
            }
            db.SaveChanges();
            MessageBox.Show("Done!");
        }

        private void rexaButton6_Click(object sender, EventArgs e)
        {
            new Reports.FightsView().ShowDialog();
        }

        private void rexaButton7_Click(object sender, EventArgs e)
        {
            new Reports.MatsView().ShowDialog();
        }

        private void rexaButton8_Click(object sender, EventArgs e)
        {
            if (
                MessageBox.Show("You can use SQL Server import wizard to transfer data between different sources. Please press \"Cancel\" if you aren't experienced in database administration.", "WARNING", MessageBoxButtons.OKCancel) == DialogResult.OK
                )
            {
                Process.Start(@"C:\Program Files (x86)\Microsoft SQL Server\130\DTS\Binn\DTSWizard.exe");
            }
        }

        private void rexaButton10_Click(object sender, EventArgs e)
        {
            Hide();
            new Reports.CertificateView()
                .ShowDialog();
            Show();
        }

        private void rexaButton9_Click(object sender, EventArgs e)
        {
            Hide();
            var frm = new FightDetails();
            // TODO

            frm.Fights = db.Fights
                .Where(x => x.Status == "Scheduled" || x.Status == "Battle")
                .OrderBy(x => x.Status).ToList();
            frm.CurrentIndex = 0;

            frm.ShowDialog();
            Show();
        }

        private void rexaButton11_Click(object sender, EventArgs e)
        {
            Hide();
            new PosterGenerator()
                .ShowDialog();
            Show();
        }
    }
}
