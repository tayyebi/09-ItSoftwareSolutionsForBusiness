﻿namespace Judo
{
    partial class FightDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rexaButton2 = new Judo.Components.RexaButton(this.components);
            this.rexaButton3 = new Judo.Components.RexaButton(this.components);
            this.rexaButton4 = new Judo.Components.RexaButton(this.components);
            this.rexaButton5 = new Judo.Components.RexaButton(this.components);
            this.rexaButton6 = new Judo.Components.RexaButton(this.components);
            this.rexaButton7 = new Judo.Components.RexaButton(this.components);
            this.rexaButton8 = new Judo.Components.RexaButton(this.components);
            this.rexaButton9 = new Judo.Components.RexaButton(this.components);
            this.timer_small = new System.Windows.Forms.Timer(this.components);
            this.timer_large = new System.Windows.Forms.Timer(this.components);
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.rexaButton10 = new Judo.Components.RexaButton(this.components);
            this.rexaButton11 = new Judo.Components.RexaButton(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(7, 7);
            this.panel1.Size = new System.Drawing.Size(1141, 73);
            // 
            // label1
            // 
            this.label1.Size = new System.Drawing.Size(1075, 73);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(1075, 0);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.rexaButton11);
            this.panel2.Controls.Add(this.rexaButton10);
            this.panel2.Controls.Add(this.rexaButton9);
            this.panel2.Controls.Add(this.rexaButton8);
            this.panel2.Controls.Add(this.rexaButton6);
            this.panel2.Controls.Add(this.rexaButton4);
            this.panel2.Controls.Add(this.rexaButton7);
            this.panel2.Controls.Add(this.rexaButton5);
            this.panel2.Controls.Add(this.rexaButton3);
            this.panel2.Controls.Add(this.rexaButton2);
            this.panel2.Controls.Add(this.label34);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label33);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(7, 80);
            this.panel2.Size = new System.Drawing.Size(1141, 478);
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(7, 558);
            this.panel3.Size = new System.Drawing.Size(1141, 38);
            // 
            // rexaButton1
            // 
            this.rexaButton1.Location = new System.Drawing.Point(1046, 0);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 18F);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(938, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 27);
            this.label3.TabIndex = 4;
            this.label3.Text = "MAT NUM:";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 18F);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(1069, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 27);
            this.label2.TabIndex = 4;
            this.label2.Text = "00";
            // 
            // rexaButton2
            // 
            this.rexaButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton2.Font = new System.Drawing.Font("Arial", 18F);
            this.rexaButton2.ForeColor = System.Drawing.Color.White;
            this.rexaButton2.Location = new System.Drawing.Point(43, 62);
            this.rexaButton2.Name = "rexaButton2";
            this.rexaButton2.Size = new System.Drawing.Size(226, 109);
            this.rexaButton2.TabIndex = 5;
            this.rexaButton2.Text = "END / NEXT";
            this.rexaButton2.UseVisualStyleBackColor = false;
            this.rexaButton2.Click += new System.EventHandler(this.rexaButton2_Click);
            // 
            // rexaButton3
            // 
            this.rexaButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(13)))), ((int)(((byte)(62)))));
            this.rexaButton3.Font = new System.Drawing.Font("Arial", 10F);
            this.rexaButton3.ForeColor = System.Drawing.Color.White;
            this.rexaButton3.Location = new System.Drawing.Point(43, 177);
            this.rexaButton3.Name = "rexaButton3";
            this.rexaButton3.Size = new System.Drawing.Size(110, 28);
            this.rexaButton3.TabIndex = 5;
            this.rexaButton3.Text = "Waza-ari";
            this.rexaButton3.UseVisualStyleBackColor = false;
            this.rexaButton3.Click += new System.EventHandler(this.rexaButton8_Click);
            // 
            // rexaButton4
            // 
            this.rexaButton4.BackColor = System.Drawing.Color.White;
            this.rexaButton4.Font = new System.Drawing.Font("Arial", 10F);
            this.rexaButton4.ForeColor = System.Drawing.Color.Black;
            this.rexaButton4.Location = new System.Drawing.Point(159, 177);
            this.rexaButton4.Name = "rexaButton4";
            this.rexaButton4.Size = new System.Drawing.Size(110, 28);
            this.rexaButton4.TabIndex = 5;
            this.rexaButton4.Text = "Waza-ari";
            this.rexaButton4.UseVisualStyleBackColor = false;
            this.rexaButton4.Click += new System.EventHandler(this.rexaButton8_Click);
            // 
            // rexaButton5
            // 
            this.rexaButton5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(13)))), ((int)(((byte)(62)))));
            this.rexaButton5.Font = new System.Drawing.Font("Arial", 10F);
            this.rexaButton5.ForeColor = System.Drawing.Color.White;
            this.rexaButton5.Location = new System.Drawing.Point(43, 211);
            this.rexaButton5.Name = "rexaButton5";
            this.rexaButton5.Size = new System.Drawing.Size(110, 28);
            this.rexaButton5.TabIndex = 5;
            this.rexaButton5.Text = "Ippon";
            this.rexaButton5.UseVisualStyleBackColor = false;
            this.rexaButton5.Click += new System.EventHandler(this.rexaButton8_Click);
            // 
            // rexaButton6
            // 
            this.rexaButton6.BackColor = System.Drawing.Color.White;
            this.rexaButton6.Font = new System.Drawing.Font("Arial", 10F);
            this.rexaButton6.ForeColor = System.Drawing.Color.Black;
            this.rexaButton6.Location = new System.Drawing.Point(159, 211);
            this.rexaButton6.Name = "rexaButton6";
            this.rexaButton6.Size = new System.Drawing.Size(110, 28);
            this.rexaButton6.TabIndex = 5;
            this.rexaButton6.Text = "Ippon";
            this.rexaButton6.UseVisualStyleBackColor = false;
            this.rexaButton6.Click += new System.EventHandler(this.rexaButton8_Click);
            // 
            // rexaButton7
            // 
            this.rexaButton7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(13)))), ((int)(((byte)(62)))));
            this.rexaButton7.Font = new System.Drawing.Font("Arial", 10F);
            this.rexaButton7.ForeColor = System.Drawing.Color.White;
            this.rexaButton7.Location = new System.Drawing.Point(43, 245);
            this.rexaButton7.Name = "rexaButton7";
            this.rexaButton7.Size = new System.Drawing.Size(110, 28);
            this.rexaButton7.TabIndex = 5;
            this.rexaButton7.Text = "Warning";
            this.rexaButton7.UseVisualStyleBackColor = false;
            this.rexaButton7.Click += new System.EventHandler(this.rexaButton8_Click);
            // 
            // rexaButton8
            // 
            this.rexaButton8.BackColor = System.Drawing.Color.White;
            this.rexaButton8.Font = new System.Drawing.Font("Arial", 10F);
            this.rexaButton8.ForeColor = System.Drawing.Color.Black;
            this.rexaButton8.Location = new System.Drawing.Point(159, 245);
            this.rexaButton8.Name = "rexaButton8";
            this.rexaButton8.Size = new System.Drawing.Size(110, 28);
            this.rexaButton8.TabIndex = 5;
            this.rexaButton8.Text = "Warning";
            this.rexaButton8.UseVisualStyleBackColor = false;
            this.rexaButton8.Click += new System.EventHandler(this.rexaButton8_Click);
            // 
            // rexaButton9
            // 
            this.rexaButton9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton9.Font = new System.Drawing.Font("Arial", 10F);
            this.rexaButton9.ForeColor = System.Drawing.Color.White;
            this.rexaButton9.Location = new System.Drawing.Point(43, 279);
            this.rexaButton9.Name = "rexaButton9";
            this.rexaButton9.Size = new System.Drawing.Size(226, 28);
            this.rexaButton9.TabIndex = 5;
            this.rexaButton9.Text = "Discard last input";
            this.rexaButton9.UseVisualStyleBackColor = false;
            this.rexaButton9.Click += new System.EventHandler(this.rexaButton9_Click);
            // 
            // timer_small
            // 
            this.timer_small.Interval = 1000;
            this.timer_small.Tick += new System.EventHandler(this.timer_small_Tick);
            // 
            // timer_large
            // 
            this.timer_large.Interval = 1000;
            this.timer_large.Tick += new System.EventHandler(this.timer_large_Tick);
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(912, 167);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 18);
            this.label4.TabIndex = 4;
            this.label4.Text = "Holding:";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(993, 167);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 18);
            this.label5.TabIndex = 4;
            this.label5.Text = "00";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(907, 219);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 29);
            this.label6.TabIndex = 4;
            this.label6.Text = "Time:";
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(991, 219);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 29);
            this.label7.TabIndex = 4;
            this.label7.Text = "00";
            // 
            // rexaButton10
            // 
            this.rexaButton10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.rexaButton10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton10.Font = new System.Drawing.Font("Arial", 10F);
            this.rexaButton10.ForeColor = System.Drawing.Color.White;
            this.rexaButton10.Location = new System.Drawing.Point(911, 188);
            this.rexaButton10.Name = "rexaButton10";
            this.rexaButton10.Size = new System.Drawing.Size(226, 28);
            this.rexaButton10.TabIndex = 5;
            this.rexaButton10.Text = "Start/Stop";
            this.rexaButton10.UseVisualStyleBackColor = false;
            this.rexaButton10.Click += new System.EventHandler(this.rexaButton10_Click);
            // 
            // rexaButton11
            // 
            this.rexaButton11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.rexaButton11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.rexaButton11.Font = new System.Drawing.Font("Arial", 10F);
            this.rexaButton11.ForeColor = System.Drawing.Color.White;
            this.rexaButton11.Location = new System.Drawing.Point(912, 249);
            this.rexaButton11.Name = "rexaButton11";
            this.rexaButton11.Size = new System.Drawing.Size(226, 28);
            this.rexaButton11.TabIndex = 5;
            this.rexaButton11.Text = "Start/Stop";
            this.rexaButton11.UseVisualStyleBackColor = false;
            this.rexaButton11.Click += new System.EventHandler(this.rexaButton11_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.panel4);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Location = new System.Drawing.Point(275, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(626, 464);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "DISPLAY";
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label16.BackColor = System.Drawing.Color.White;
            this.label16.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(338, 227);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(260, 22);
            this.label16.TabIndex = 1;
            this.label16.Text = "ACTUAL BATTLE";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(338, 166);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(260, 58);
            this.label14.TabIndex = 1;
            this.label14.Text = "ACTUAL BATTLE";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(3, 18);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(620, 110);
            this.panel4.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(393, 67);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(201, 20);
            this.label10.TabIndex = 1;
            this.label10.Text = "next battle";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(31, 37);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(563, 20);
            this.label11.TabIndex = 1;
            this.label11.Text = "next battle";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(13)))), ((int)(((byte)(62)))));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(31, 67);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(201, 20);
            this.label9.TabIndex = 1;
            this.label9.Text = "next battle";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.label8.Dock = System.Windows.Forms.DockStyle.Top;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(0, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(618, 20);
            this.label8.TabIndex = 0;
            this.label8.Text = "next battle";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(137)))));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(35, 144);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(563, 20);
            this.label13.TabIndex = 1;
            this.label13.Text = "ACTUAL BATTLE";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label22.BackColor = System.Drawing.Color.White;
            this.label22.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(513, 288);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(77, 76);
            this.label22.TabIndex = 1;
            this.label22.Text = "0";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(13)))), ((int)(((byte)(62)))));
            this.label19.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(211, 289);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(77, 76);
            this.label19.TabIndex = 1;
            this.label19.Text = "0";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label21.BackColor = System.Drawing.Color.White;
            this.label21.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(430, 288);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(77, 76);
            this.label21.TabIndex = 1;
            this.label21.Text = "0";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(13)))), ((int)(((byte)(62)))));
            this.label18.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(128, 289);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(77, 76);
            this.label18.TabIndex = 1;
            this.label18.Text = "0";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.BackColor = System.Drawing.Color.White;
            this.label20.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(347, 289);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(77, 76);
            this.label20.TabIndex = 1;
            this.label20.Text = "0";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(13)))), ((int)(((byte)(62)))));
            this.label17.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(45, 290);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(77, 76);
            this.label17.TabIndex = 1;
            this.label17.Text = "0";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(13)))), ((int)(((byte)(62)))));
            this.label15.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(35, 227);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(260, 22);
            this.label15.TabIndex = 1;
            this.label15.Text = "ACTUAL BATTLE";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(13)))), ((int)(((byte)(62)))));
            this.label12.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(35, 166);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(260, 58);
            this.label12.TabIndex = 1;
            this.label12.Text = "ACTUAL BATTLE";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(319, 392);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(39, 29);
            this.label26.TabIndex = 4;
            this.label26.Text = "00";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial", 12F);
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(252, 421);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(65, 18);
            this.label23.TabIndex = 4;
            this.label23.Text = "Holding:";
            // 
            // label32
            // 
            this.label32.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Arial", 10F);
            this.label32.ForeColor = System.Drawing.Color.White;
            this.label32.Location = new System.Drawing.Point(515, 272);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(60, 16);
            this.label32.TabIndex = 4;
            this.label32.Text = "Warning";
            // 
            // label31
            // 
            this.label31.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Arial", 10F);
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Location = new System.Drawing.Point(434, 272);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(63, 16);
            this.label31.TabIndex = 4;
            this.label31.Text = "Waza-ari";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Arial", 10F);
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(211, 272);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(60, 16);
            this.label29.TabIndex = 4;
            this.label29.Text = "Warning";
            // 
            // label30
            // 
            this.label30.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Arial", 10F);
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(349, 272);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(43, 16);
            this.label30.TabIndex = 4;
            this.label30.Text = "Ippon";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Arial", 10F);
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(130, 272);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(63, 16);
            this.label28.TabIndex = 4;
            this.label28.Text = "Waza-ari";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Arial", 10F);
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(45, 272);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(43, 16);
            this.label27.TabIndex = 4;
            this.label27.Text = "Ippon";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial", 12F);
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(323, 421);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(26, 18);
            this.label25.TabIndex = 4;
            this.label25.Text = "00";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(245, 392);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(76, 29);
            this.label24.TabIndex = 4;
            this.label24.Text = "Time:";
            // 
            // label33
            // 
            this.label33.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Arial", 10F);
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(993, 89);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(66, 16);
            this.label33.TabIndex = 4;
            this.label33.Text = "Next Mat:";
            // 
            // label34
            // 
            this.label34.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Arial", 10F);
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(1065, 89);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(24, 16);
            this.label34.TabIndex = 4;
            this.label34.Text = "00";
            // 
            // FightDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1155, 603);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "FightDetails";
            this.Padding = new System.Windows.Forms.Padding(7);
            this.Text = "FightDetails";
            this.Load += new System.EventHandler(this.FightDetails_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private Components.RexaButton rexaButton2;
        private Components.RexaButton rexaButton9;
        private Components.RexaButton rexaButton8;
        private Components.RexaButton rexaButton6;
        private Components.RexaButton rexaButton4;
        private Components.RexaButton rexaButton7;
        private Components.RexaButton rexaButton5;
        private Components.RexaButton rexaButton3;
        private System.Windows.Forms.Timer timer_small;
        private System.Windows.Forms.Timer timer_large;
        private Components.RexaButton rexaButton11;
        private Components.RexaButton rexaButton10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
    }
}