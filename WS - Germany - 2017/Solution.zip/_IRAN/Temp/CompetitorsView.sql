SELECT Id, OtherData, [Name], Surname, Birthdate, SportsClub, HomeTownWithPostalCode, [Weight]
,cast ((([Weight] + 2) / 3) as int) *  3 as weightClass
,cast ((cast (getdate() as int) - cast (Birthdate as int)) / 365.4 as int) as Age
,((
cast ((cast (getdate() as int) - cast (Birthdate as int)) / 365.4 as int) -- age
+ 1)
/ 2) * 2 as AgeClass
FROM
dbo.Competitors