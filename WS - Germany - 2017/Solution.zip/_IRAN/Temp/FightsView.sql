
SELECT        Id, GroupName, SubGroupName, GroupAgeClass, GroupGenderClass, GroupWeightClass, WhiteCompetitorId, RedCompetitorId, WhiteCompetitorPoints, RedCompetitorPoints, Comments
,

case

when RedCompetitorPoints > WhiteCompetitorPoints
then RedCompetitorId

when RedCompetitorPoints < WhiteCompetitorPoints
then WhiteCompetitorId

end

as WinnerCombat

,

abs (RedCompetitorPoints - WhiteCompetitorPoints)

as Score


FROM
dbo.Fights