﻿namespace Ms2015.Forms.Public
{
    partial class Form13_ListOfCharities
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Size = new System.Drawing.Size(956, 32);
            // 
            // label3
            // 
            this.label3.Size = new System.Drawing.Size(762, 32);
            // 
            // label2
            // 
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Size = new System.Drawing.Size(956, 49);
            this.label2.Text = "List of charities";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(0, 81);
            this.label4.Size = new System.Drawing.Size(956, 32);
            this.label4.Text = "This is a list of all the charities that are being supported through Marathon Ski" +
    "lls 2015. Thank you for helping to support them by sponsoring runners!";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(823, 0);
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(0, 440);
            this.panel2.Size = new System.Drawing.Size(956, 36);
            // 
            // label1
            // 
            this.label1.Size = new System.Drawing.Size(956, 36);
            this.label1.Text = "72 days 19 hours and 57 minutes until the race starts";
            // 
            // panel3
            // 
            this.panel3.AutoScroll = true;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 113);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(956, 327);
            this.panel3.TabIndex = 4;
            // 
            // Form13_ListOfCharities
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(956, 476);
            this.Controls.Add(this.panel3);
            this.Margin = new System.Windows.Forms.Padding(7, 12, 7, 12);
            this.Name = "Form13_ListOfCharities";
            this.Text = "List of charities";
            this.Load += new System.EventHandler(this.Form13_ListOfCharities_Load);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.panel2, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.panel3, 0);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
    }
}