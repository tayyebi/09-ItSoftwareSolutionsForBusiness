﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Public
{
    public partial class Form34_BmrCalc : Masters.Father
    {
        public Form34_BmrCalc()
        {
            InitializeComponent();
        }

        private void Form34_BmrCalc_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        bool IsMale = true;
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            pictureBox3.BorderStyle = BorderStyle.Fixed3D;
            pictureBox2.BorderStyle = BorderStyle.FixedSingle;
            IsMale = false;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox2.BorderStyle = BorderStyle.Fixed3D;
            pictureBox3.BorderStyle = BorderStyle.FixedSingle;
            IsMale = true;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            new BmrPopUp().ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double height = Convert.ToDouble(textBox1.Text);
            double weight = Convert.ToDouble(textBox2.Text);
            double age = Convert.ToDouble(textBox3.Text);

            var bmr =
                IsMale
                ?
                66 + (13.7 * weight) + (5 * height) - (6.8 * age)
                :
                655 + (9.6 * weight) + (1.8 * height) - (4.7 * age)
            ;

            label14.Text = bmr.ToString("0");

            label21.Text = (bmr * 1.2).ToString("0");
            label22.Text = (bmr * 1.55).ToString("0");
            label23.Text = (bmr * 1.375).ToString("0");
            label24.Text = (bmr * 1.725).ToString("0");
            label25.Text = (bmr * 1.9).ToString("0");

        }
    }
}
