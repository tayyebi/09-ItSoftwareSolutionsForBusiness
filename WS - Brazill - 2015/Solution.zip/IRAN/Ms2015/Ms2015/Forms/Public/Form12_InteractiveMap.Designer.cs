﻿namespace Ms2015.Forms.Public
{
    partial class Form12_InteractiveMap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Checkpoint1 = new System.Windows.Forms.PictureBox();
            this.Checkpoint2 = new System.Windows.Forms.PictureBox();
            this.Checkpoint3 = new System.Windows.Forms.PictureBox();
            this.Checkpoint4 = new System.Windows.Forms.PictureBox();
            this.Checkpoint5 = new System.Windows.Forms.PictureBox();
            this.Checkpoint6 = new System.Windows.Forms.PictureBox();
            this.Checkpoint7 = new System.Windows.Forms.PictureBox();
            this.Checkpoint8 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox_information = new System.Windows.Forms.PictureBox();
            this.pictureBox_drinks = new System.Windows.Forms.PictureBox();
            this.pictureBox_medical = new System.Windows.Forms.PictureBox();
            this.pictureBox_energybars = new System.Windows.Forms.PictureBox();
            this.pictureBox_toilets = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Checkpoint1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Checkpoint2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Checkpoint3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Checkpoint4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Checkpoint5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Checkpoint6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Checkpoint7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Checkpoint8)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_information)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_drinks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_medical)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_energybars)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_toilets)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Size = new System.Drawing.Size(656, 32);
            // 
            // button1
            // 
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.Size = new System.Drawing.Size(462, 32);
            // 
            // label2
            // 
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Size = new System.Drawing.Size(656, 49);
            this.label2.Text = "Interactive Map";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(0, 81);
            this.label4.Size = new System.Drawing.Size(656, 32);
            this.label4.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(523, 0);
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(0, 460);
            this.panel2.Size = new System.Drawing.Size(656, 36);
            // 
            // label1
            // 
            this.label1.Size = new System.Drawing.Size(656, 36);
            this.label1.Text = "67 days 21 hours and 29 minutes until the race starts";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::Ms2015.Properties.Resources.marathon_skills_2015_marathon_map;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(12, 116);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(342, 338);
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // Checkpoint1
            // 
            this.Checkpoint1.BackColor = System.Drawing.Color.Transparent;
            this.Checkpoint1.BackgroundImage = global::Ms2015.Properties.Resources.Picture1;
            this.Checkpoint1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Checkpoint1.Location = new System.Drawing.Point(251, 164);
            this.Checkpoint1.Name = "Checkpoint1";
            this.Checkpoint1.Size = new System.Drawing.Size(29, 28);
            this.Checkpoint1.TabIndex = 5;
            this.Checkpoint1.TabStop = false;
            this.Checkpoint1.Click += new System.EventHandler(this.Checkpoint8_Click);
            // 
            // Checkpoint2
            // 
            this.Checkpoint2.BackColor = System.Drawing.Color.Transparent;
            this.Checkpoint2.BackgroundImage = global::Ms2015.Properties.Resources.Picture2;
            this.Checkpoint2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Checkpoint2.Location = new System.Drawing.Point(313, 268);
            this.Checkpoint2.Name = "Checkpoint2";
            this.Checkpoint2.Size = new System.Drawing.Size(29, 28);
            this.Checkpoint2.TabIndex = 5;
            this.Checkpoint2.TabStop = false;
            this.Checkpoint2.Click += new System.EventHandler(this.Checkpoint8_Click);
            // 
            // Checkpoint3
            // 
            this.Checkpoint3.BackColor = System.Drawing.Color.Transparent;
            this.Checkpoint3.BackgroundImage = global::Ms2015.Properties.Resources.Picture3;
            this.Checkpoint3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Checkpoint3.Location = new System.Drawing.Point(251, 319);
            this.Checkpoint3.Name = "Checkpoint3";
            this.Checkpoint3.Size = new System.Drawing.Size(29, 28);
            this.Checkpoint3.TabIndex = 5;
            this.Checkpoint3.TabStop = false;
            this.Checkpoint3.Click += new System.EventHandler(this.Checkpoint8_Click);
            // 
            // Checkpoint4
            // 
            this.Checkpoint4.BackColor = System.Drawing.Color.Transparent;
            this.Checkpoint4.BackgroundImage = global::Ms2015.Properties.Resources.Picture4;
            this.Checkpoint4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Checkpoint4.Location = new System.Drawing.Point(211, 388);
            this.Checkpoint4.Name = "Checkpoint4";
            this.Checkpoint4.Size = new System.Drawing.Size(29, 28);
            this.Checkpoint4.TabIndex = 5;
            this.Checkpoint4.TabStop = false;
            this.Checkpoint4.Click += new System.EventHandler(this.Checkpoint8_Click);
            // 
            // Checkpoint5
            // 
            this.Checkpoint5.BackColor = System.Drawing.Color.Transparent;
            this.Checkpoint5.BackgroundImage = global::Ms2015.Properties.Resources.Picture5;
            this.Checkpoint5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Checkpoint5.Location = new System.Drawing.Point(134, 358);
            this.Checkpoint5.Name = "Checkpoint5";
            this.Checkpoint5.Size = new System.Drawing.Size(29, 28);
            this.Checkpoint5.TabIndex = 5;
            this.Checkpoint5.TabStop = false;
            this.Checkpoint5.Click += new System.EventHandler(this.Checkpoint8_Click);
            // 
            // Checkpoint6
            // 
            this.Checkpoint6.BackColor = System.Drawing.Color.Transparent;
            this.Checkpoint6.BackgroundImage = global::Ms2015.Properties.Resources.Picture6;
            this.Checkpoint6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Checkpoint6.Location = new System.Drawing.Point(75, 319);
            this.Checkpoint6.Name = "Checkpoint6";
            this.Checkpoint6.Size = new System.Drawing.Size(29, 28);
            this.Checkpoint6.TabIndex = 5;
            this.Checkpoint6.TabStop = false;
            this.Checkpoint6.Click += new System.EventHandler(this.Checkpoint8_Click);
            // 
            // Checkpoint7
            // 
            this.Checkpoint7.BackColor = System.Drawing.Color.Transparent;
            this.Checkpoint7.BackgroundImage = global::Ms2015.Properties.Resources.Picture7;
            this.Checkpoint7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Checkpoint7.Location = new System.Drawing.Point(32, 221);
            this.Checkpoint7.Name = "Checkpoint7";
            this.Checkpoint7.Size = new System.Drawing.Size(29, 28);
            this.Checkpoint7.TabIndex = 5;
            this.Checkpoint7.TabStop = false;
            this.Checkpoint7.Click += new System.EventHandler(this.Checkpoint8_Click);
            // 
            // Checkpoint8
            // 
            this.Checkpoint8.BackColor = System.Drawing.Color.Transparent;
            this.Checkpoint8.BackgroundImage = global::Ms2015.Properties.Resources.Picture8;
            this.Checkpoint8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Checkpoint8.Location = new System.Drawing.Point(91, 164);
            this.Checkpoint8.Name = "Checkpoint8";
            this.Checkpoint8.Size = new System.Drawing.Size(29, 28);
            this.Checkpoint8.TabIndex = 5;
            this.Checkpoint8.TabStop = false;
            this.Checkpoint8.Click += new System.EventHandler(this.Checkpoint8_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.pictureBox_information);
            this.panel3.Controls.Add(this.pictureBox_drinks);
            this.panel3.Controls.Add(this.pictureBox_medical);
            this.panel3.Controls.Add(this.pictureBox_energybars);
            this.panel3.Controls.Add(this.pictureBox_toilets);
            this.panel3.Controls.Add(this.pictureBox11);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Location = new System.Drawing.Point(360, 116);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(281, 338);
            this.panel3.TabIndex = 6;
            this.panel3.Visible = false;
            // 
            // pictureBox_information
            // 
            this.pictureBox_information.BackgroundImage = global::Ms2015.Properties.Resources.map_icon_information;
            this.pictureBox_information.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox_information.Location = new System.Drawing.Point(188, 39);
            this.pictureBox_information.Name = "pictureBox_information";
            this.pictureBox_information.Size = new System.Drawing.Size(86, 76);
            this.pictureBox_information.TabIndex = 2;
            this.pictureBox_information.TabStop = false;
            // 
            // pictureBox_drinks
            // 
            this.pictureBox_drinks.BackgroundImage = global::Ms2015.Properties.Resources.map_icon_drinks;
            this.pictureBox_drinks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox_drinks.Location = new System.Drawing.Point(96, 121);
            this.pictureBox_drinks.Name = "pictureBox_drinks";
            this.pictureBox_drinks.Size = new System.Drawing.Size(86, 76);
            this.pictureBox_drinks.TabIndex = 2;
            this.pictureBox_drinks.TabStop = false;
            // 
            // pictureBox_medical
            // 
            this.pictureBox_medical.BackgroundImage = global::Ms2015.Properties.Resources.map_icon_medical;
            this.pictureBox_medical.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox_medical.Location = new System.Drawing.Point(96, 39);
            this.pictureBox_medical.Name = "pictureBox_medical";
            this.pictureBox_medical.Size = new System.Drawing.Size(86, 76);
            this.pictureBox_medical.TabIndex = 2;
            this.pictureBox_medical.TabStop = false;
            // 
            // pictureBox_energybars
            // 
            this.pictureBox_energybars.BackgroundImage = global::Ms2015.Properties.Resources.map_icon_energy_bars;
            this.pictureBox_energybars.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox_energybars.Location = new System.Drawing.Point(4, 121);
            this.pictureBox_energybars.Name = "pictureBox_energybars";
            this.pictureBox_energybars.Size = new System.Drawing.Size(86, 76);
            this.pictureBox_energybars.TabIndex = 2;
            this.pictureBox_energybars.TabStop = false;
            // 
            // pictureBox_toilets
            // 
            this.pictureBox_toilets.BackgroundImage = global::Ms2015.Properties.Resources.map_icon_toilets;
            this.pictureBox_toilets.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox_toilets.Location = new System.Drawing.Point(4, 39);
            this.pictureBox_toilets.Name = "pictureBox_toilets";
            this.pictureBox_toilets.Size = new System.Drawing.Size(86, 76);
            this.pictureBox_toilets.TabIndex = 2;
            this.pictureBox_toilets.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackgroundImage = global::Ms2015.Properties.Resources.Close;
            this.pictureBox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox11.Location = new System.Drawing.Point(257, 3);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(21, 22);
            this.pictureBox11.TabIndex = 0;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Top;
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(281, 36);
            this.label5.TabIndex = 1;
            this.label5.Text = "label5";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox16.BackgroundImage = global::Ms2015.Properties.Resources.map_icon_start;
            this.pictureBox16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox16.Location = new System.Drawing.Point(192, 124);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(29, 28);
            this.pictureBox16.TabIndex = 5;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox17.BackgroundImage = global::Ms2015.Properties.Resources.map_icon_start;
            this.pictureBox17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox17.Location = new System.Drawing.Point(134, 413);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(29, 28);
            this.pictureBox17.TabIndex = 5;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox18.BackgroundImage = global::Ms2015.Properties.Resources.map_icon_start;
            this.pictureBox18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox18.Location = new System.Drawing.Point(73, 226);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(29, 28);
            this.pictureBox18.TabIndex = 5;
            this.pictureBox18.TabStop = false;
            // 
            // Form12_InteractiveMap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(656, 496);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.Checkpoint8);
            this.Controls.Add(this.Checkpoint7);
            this.Controls.Add(this.Checkpoint6);
            this.Controls.Add(this.Checkpoint5);
            this.Controls.Add(this.Checkpoint4);
            this.Controls.Add(this.Checkpoint3);
            this.Controls.Add(this.pictureBox18);
            this.Controls.Add(this.pictureBox17);
            this.Controls.Add(this.pictureBox16);
            this.Controls.Add(this.Checkpoint2);
            this.Controls.Add(this.Checkpoint1);
            this.Controls.Add(this.pictureBox2);
            this.Margin = new System.Windows.Forms.Padding(7, 12, 7, 12);
            this.Name = "Form12_InteractiveMap";
            this.Text = "Interactive Map";
            this.Load += new System.EventHandler(this.Form12_InteractiveMap_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form12_InteractiveMap_KeyDown);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Form12_InteractiveMap_MouseClick);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.panel2, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.pictureBox2, 0);
            this.Controls.SetChildIndex(this.Checkpoint1, 0);
            this.Controls.SetChildIndex(this.Checkpoint2, 0);
            this.Controls.SetChildIndex(this.pictureBox16, 0);
            this.Controls.SetChildIndex(this.pictureBox17, 0);
            this.Controls.SetChildIndex(this.pictureBox18, 0);
            this.Controls.SetChildIndex(this.Checkpoint3, 0);
            this.Controls.SetChildIndex(this.Checkpoint4, 0);
            this.Controls.SetChildIndex(this.Checkpoint5, 0);
            this.Controls.SetChildIndex(this.Checkpoint6, 0);
            this.Controls.SetChildIndex(this.Checkpoint7, 0);
            this.Controls.SetChildIndex(this.Checkpoint8, 0);
            this.Controls.SetChildIndex(this.panel3, 0);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Checkpoint1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Checkpoint2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Checkpoint3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Checkpoint4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Checkpoint5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Checkpoint6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Checkpoint7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Checkpoint8)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_information)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_drinks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_medical)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_energybars)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_toilets)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox Checkpoint1;
        private System.Windows.Forms.PictureBox Checkpoint2;
        private System.Windows.Forms.PictureBox Checkpoint3;
        private System.Windows.Forms.PictureBox Checkpoint4;
        private System.Windows.Forms.PictureBox Checkpoint5;
        private System.Windows.Forms.PictureBox Checkpoint6;
        private System.Windows.Forms.PictureBox Checkpoint7;
        private System.Windows.Forms.PictureBox Checkpoint8;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox_toilets;
        private System.Windows.Forms.PictureBox pictureBox_information;
        private System.Windows.Forms.PictureBox pictureBox_drinks;
        private System.Windows.Forms.PictureBox pictureBox_medical;
        private System.Windows.Forms.PictureBox pictureBox_energybars;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
    }
}