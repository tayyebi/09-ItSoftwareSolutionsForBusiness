﻿using Ms2015.Masters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Public
{
    public partial class Form12_InteractiveMap : Father
    {
        class MyClass
        {
            public string Checkpoint { get; set; }
            public string Landmark { get; set; }
            public bool Drinks { get; set; }
            public bool EnergyBars { get; set; }
            public bool Toilets { get; set; }
            public bool Information { get; set; }
            public bool Medical { get; set; }
        }

        List<MyClass> MyItems = new List<MyClass>();

        public Form12_InteractiveMap()
        {
            InitializeComponent();

            MyItems.Add(new MyClass { Checkpoint = "Checkpoint1", Landmark = "Avenida Rudge          ", Drinks = true, EnergyBars = true, Toilets = false, Information = false, Medical = false });
            MyItems.Add(new MyClass { Checkpoint = "Checkpoint2", Landmark = "Theatro Municipal      ", Drinks = true, EnergyBars = true, Toilets = true, Information = true, Medical = true });
            MyItems.Add(new MyClass { Checkpoint = "Checkpoint3", Landmark = "Parque do Ibirapuera   ", Drinks = true, EnergyBars = true, Toilets = true, Information = false, Medical = false });
            MyItems.Add(new MyClass { Checkpoint = "Checkpoint4", Landmark = "Jardim Luzitania       ", Drinks = true, EnergyBars = true, Toilets = true, Information = false, Medical = true });
            MyItems.Add(new MyClass { Checkpoint = "Checkpoint5", Landmark = "Iguatemi               ", Drinks = true, EnergyBars = true, Toilets = true, Information = true, Medical = false });
            MyItems.Add(new MyClass { Checkpoint = "Checkpoint6", Landmark = "Rua Lisboa             ", Drinks = true, EnergyBars = true, Toilets = true, Information = false, Medical = false });
            MyItems.Add(new MyClass { Checkpoint = "Checkpoint7", Landmark = "Cemitério da Consolação", Drinks = true, EnergyBars = true, Toilets = true, Information = true, Medical = true });
            MyItems.Add(new MyClass { Checkpoint = "Checkpoint8", Landmark = "Cemitério da Consolação", Drinks = true, EnergyBars = true, Toilets = true, Information = true, Medical = true });
        }

        private void Form12_InteractiveMap_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Form12_InteractiveMap_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void Form12_InteractiveMap_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void Checkpoint8_Click(object sender, EventArgs e)
        {
            var this_item =
                MyItems.Where(x => x.Checkpoint == (sender as PictureBox).Name).FirstOrDefault();
            label5.Text = this_item.Landmark;
            pictureBox_drinks.Visible = this_item.Drinks;
            pictureBox_energybars.Visible = this_item.EnergyBars;
            pictureBox_information.Visible = this_item.Information;
            pictureBox_medical.Visible = this_item.Medical;
            pictureBox_toilets.Visible = this_item.Toilets;
            panel3.Visible = true;
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
        }
    }
}
