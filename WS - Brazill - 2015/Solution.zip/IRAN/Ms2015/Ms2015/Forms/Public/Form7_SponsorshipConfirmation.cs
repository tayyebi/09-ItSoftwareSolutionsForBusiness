﻿using Ms2015.Masters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Public
{
    public partial class Form7_SponsorshipConfirmation : Father
    {
        public Form7_SponsorshipConfirmation()
        {
            InitializeComponent();
        }

        private void Form7_SponsorshipConfirmation_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
