﻿using Ms2015.Masters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Public
{
    public partial class Form10_FindOurMoreInfo : Father
    {
        public Form10_FindOurMoreInfo()
        {
            InitializeComponent();
        }

        private void Form10_FindOurMoreInfo_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Hide();
            new Form13_ListOfCharities().ShowDialog();
            Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Hide();
            new Form15_HowLongIsAMarathon().ShowDialog();
            Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Hide();
            new Form11_AboutMarathonSkills2015().ShowDialog();
            Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Hide();
            new Form33_BmiCalc().ShowDialog();
            Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Hide();
            new Form34_BmrCalc().ShowDialog();
            Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            new Form14_PreviousRaceResults().ShowDialog();
            Show();
        }
    }
}
