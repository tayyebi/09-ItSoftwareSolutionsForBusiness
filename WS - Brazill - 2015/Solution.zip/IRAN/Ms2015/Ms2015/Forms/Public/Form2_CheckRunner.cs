﻿using Ms2015.Masters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015
{
    public partial class Form2_CheckRunner : Father
    {
        public Form2_CheckRunner()
        {
            InitializeComponent();
        }

        private void Form2_CheckRunner_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Hide();

            if (new Form4_RunnerRegistration().ShowDialog() == DialogResult.OK)
            { 
                new Form3_Login().ShowDialog();
                Close();
            }
            else
            {

                Show();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Hide();
            new Form3_Login().ShowDialog();
            Close();
        }
    }
}
