﻿using Ms2015.Masters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Public
{
    public partial class Form14_PreviousRaceResults : Father
    {
        public Form14_PreviousRaceResults()
        {
            InitializeComponent();
            comboBox4.SelectedIndex = 0;
        }

        private void Form14_PreviousRaceResults_Load(object sender, EventArgs e)
        {



            var query = (


                from a in db.View_PrevRaceResults

                select new
                {
                    a.MarathonId,
                    a.MarathonName,
                    a.Gender
                }


                );




            comboBox1.DisplayMember = "MarathonName";
            comboBox1.ValueMember = "MarathonId";

            comboBox1.DataSource = (
                from a in query
                group a by new { a.MarathonId, a.MarathonName }
                into g
                select new { g.Key.MarathonId, g.Key.MarathonName }
                ).ToList();






            comboBox3.DisplayMember = "Gender";
            comboBox3.ValueMember = "Gender";

            comboBox3.DataSource = (
                from a in query
                group a by new { a.Gender }
                into g
                select g.Key.Gender
                ).ToList();



            //var query = (

            //    from RaceResult in db.View_MyRaceResults


            //    join Overall in db.View_MyRaceResults
            //    on RaceResult.EventId equals Overall.EventId

            //    group new { RaceResult, Overall } by new

            //    {
            //        Runner = RaceResult.RunnerId,
            //        Marathon = RaceResult.MarathonName,
            //        Event = RaceResult.EventName,
            //        RaceTime = RaceResult.RaceTime,
            //        Gender = RaceResult.Gender,
            //        Age = RaceResult.Age,
            //        AgeCategory = RaceResult.Category
            //    }
            //    into race_result

            //    where race_result.Key.Runner == Program.RunnerId

            //    select new
            //    {
            //        race_result.Key.Marathon,
            //        race_result.Key.Event,
            //        RaceTime =
            //        (int)(race_result.Key.RaceTime / 3600)
            //         + " hours and "

            //         + (int)((race_result.Key.RaceTime - (((int)(race_result.Key.RaceTime / 3600)) * 3600)) / 60)
            //         + " minutes and "

            //         + (race_result.Key.RaceTime - (((int)(race_result.Key.RaceTime / 3600)) * 3600) - (((int)((race_result.Key.RaceTime - (((int)(race_result.Key.RaceTime / 3600)) * 3600)) / 60)) * 60))
            //         + " seconds"

            //        ,
            //        Overall = race_result.Count(x => x.Overall.RaceTime <= race_result.Key.RaceTime),
            //        Category = race_result.Count(x => x.Overall.RaceTime <= race_result.Key.RaceTime &&
            //        x.Overall.Gender == race_result.Key.Gender
            //        && x.Overall.Category == race_result.Key.AgeCategory
            //        )
            //    }


            //    )

            //    .ToList();

            //dataGridView1.DataSource = query;

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            int marathonId = Convert.ToInt32(comboBox1.SelectedValue.ToString());

            comboBox2.DisplayMember = "EventName";
            comboBox2.ValueMember = "EventId";

            comboBox2.DataSource = (
                from a in db.View_PrevRaceResults
                group a by new { a.MarathonId, a.EventId, a.EventName }
                into g
                select g.Key
                )
                .Where(
                x => x.MarathonId == marathonId
                )
                .ToList();

        }

        private void button2_Click(object sender, EventArgs e)
        {

            int marathon = Convert.ToInt32(comboBox1.SelectedValue.ToString());
            string marathon_event = comboBox2.SelectedValue.ToString();

            var the_query = (

                from a in db.View_PrevRaceResults

                where
                a.Gender == comboBox3.Text &&
                a.Category == comboBox4.Text &&
                a.EventId == marathon_event

                // && a.RaceTime != null

                select a

                );
            label10.Text = the_query.Count().ToString();
            var the_query_level2 =
                the_query
                .Where(x => x.RaceTime != null)
                .AsEnumerable()
                .OrderBy(x => x.RaceTime)
                .Distinct()
                .Select((x, i) => new
                {
                    Rank = i + 1 ,
                    Name = x.FirstName + " " + x.LastName,
                    RaceTime =
                             (x.RaceTime ?? 0 / 3600)
                             + " hours and "

                             + (((x.RaceTime ?? 0) - (((int)(x.RaceTime / 3600)) * 3600)) / 60)
                             + " minutes and "

                             + ((x.RaceTime ?? 0) - (((int)(x.RaceTime / 3600)) * 3600) - (((int)((x.RaceTime - (((int)(x.RaceTime / 3600)) * 3600)) / 60)) * 60))
                             + " seconds",
                    Country =
                        x.CountryCode
                })
                .ToList();

            label9.Visible =
                label10.Visible =
                label11.Visible =
                label12.Visible =
                label13.Visible =
                label14.Visible =
                true;
            label12.Text = the_query_level2.Count().ToString();

            var RaceTime =
                the_query
                .Where(x => x.RaceTime != null && x.RaceTime != 0)
                .Average(x => x.RaceTime ?? 0);

            label14.Text = (int)(RaceTime / 3600)
                             + " hours and "

                             + (int)(((RaceTime) - (((int)(RaceTime / 3600)) * 3600)) / 60)
                             + " minutes and "

                             + (int)((RaceTime) - (((int)(RaceTime / 3600)) * 3600) - (((int)((RaceTime - (((int)(RaceTime / 3600)) * 3600)) / 60)) * 60))
                             + " seconds";
            dataGridView1.DataSource = the_query_level2;

        }
    }
}
