﻿using Ms2015.Masters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Public
{
    public partial class Form15_HowLongIsAMarathon : Father
    {
        public Form15_HowLongIsAMarathon()
        {
            InitializeComponent();
        }

        private void Form15_HowLongIsAMarathon_Load(object sender, EventArgs e)
        {
            List<Models.HowLong> hls = db.HowLongs.ToList();
            foreach (var item in hls.Where(x => x.Speed))
            {
                var uc = new UserControls.Uc_HowLong(item);
                uc.Dock = DockStyle.Top;
                uc.MyParent = this;
                tabPage1.Controls.Add(uc);
            }
            foreach (var item in hls.Where(x => x.Lenght))
            {
                var uc = new UserControls.Uc_HowLong(item);
                uc.Dock = DockStyle.Top;
                uc.MyParent = this;
                tabPage2.Controls.Add(uc);
            }
        }
    }
}
