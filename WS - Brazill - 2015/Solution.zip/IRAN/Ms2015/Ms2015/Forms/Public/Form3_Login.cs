﻿using Ms2015.Forms.Runner;
using Ms2015.Masters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015
{
    public partial class Form3_Login : Father
    {
        public Form3_Login()
        {
            InitializeComponent();
        }

        private void Form3_Login_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Program.logged_in_user = db.Users.Where(x => x.Email == textBox_name.Text && x.Password == textBox1.Text).FirstOrDefault();
            if (Program.logged_in_user == null)
            {
                MessageBox.Show("Username or password is invalid");
                return;
            }
            else
            {
                Hide();
                switch (Program.logged_in_user.RoleId)
                {
                    case "A": // administrator
                        new Forms.Administrator.Form20_AdministratorMenu().ShowDialog();
                        break;
                    case "C": // coordinator
                        new Forms.Coordinator.Form19_CoordinatorMenu().ShowDialog();
                        break;
                    case "R": // runner
                        Program.RunnerId = db.Runners.Where(x => x.Email == Program.logged_in_user.Email).FirstOrDefault().RunnerId;
                        new Form9_RunnerMenu().ShowDialog();
                        break;
                }
                Close();
            }
        }
    }
}
