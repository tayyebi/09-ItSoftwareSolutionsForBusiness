﻿using Ms2015.Masters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Public
{
    public partial class Form6_SponsorARunner : Father
    {
        public Form6_SponsorARunner()
        {
            InitializeComponent();
        }

        private void Form6_SponsorARunner_Load(object sender, EventArgs e)
        {
            var query = db.SposnorARunners.Where(x => x.Marathon == 5).ToList();
            comboBox1.ValueMember = "RegistrationId";
            comboBox1.DisplayMember = "MyDisplay";
            comboBox1.DataSource = query;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Close();
        }

        private int amount = 50;

        private void button4_Click_1(object sender, EventArgs e)
        {


            switch ((sender as Button).Text)
            {
                case "+":
                    amount += 10;
                    break;
                case "-":
                    amount -= 10;
                    break;
            }
            if (amount < 0)
                amount = 0;

            maskedTextBox5.Text = amount.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {

            if (textBox_name.Text == string.Empty ||
                maskedTextBox5.Text == string.Empty ||
                  maskedTextBox_creditnum.Text == string.Empty ||
                    maskedTextBox_cvc.Text == string.Empty ||
                      maskedTextBox_month.Text == string.Empty ||
                        maskedTextBox_year.Text == string.Empty
                )
            {
                MessageBox.Show("All fields are required");

                return;
            }

            var date = DateTime.ParseExact(maskedTextBox_year.Text + "/" + maskedTextBox_month.Text, "yyyy/MM", CultureInfo.CurrentCulture);
            if (date <= DateTime.Now)
            {
                MessageBox.Show("The card is expired");

                return;
            }

            db.Sponsorships.Add(new Models.Sponsorship { Amount = amount, RegistrationId = int.Parse(comboBox1.SelectedValue.ToString()), SponsorName = textBox_name.Text });
            db.SaveChanges();
            Hide();
            var spo = new Form7_SponsorshipConfirmation();
            spo.label7.Text = label15.Text;
            spo.label5.Text = comboBox1.Text;
            spo.label6.Text = uc_Charity1.label14.Text;
            spo.ShowDialog();
            Close();

        }

        private void maskedTextBox5_TextChanged(object sender, EventArgs e)
        {
            if (maskedTextBox5.Text == string.Empty)
                maskedTextBox5.Text = "0";

            amount = int.Parse(maskedTextBox5.Text);

            label15.Text = "$" + amount.ToString();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            uc_Charity1.ChangeCharity(((Models.SposnorARunner)comboBox1.SelectedItem).Charity);
        }
    }
}
