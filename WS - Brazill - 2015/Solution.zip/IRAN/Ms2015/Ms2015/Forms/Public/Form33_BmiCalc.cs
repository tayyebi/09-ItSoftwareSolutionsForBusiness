﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Public
{
    public partial class Form33_BmiCalc : Masters.Father
    {
        public Form33_BmiCalc()
        {
            InitializeComponent();
        }

        private void Form33_BmiCalc_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox2.BorderStyle = BorderStyle.Fixed3D;
            pictureBox3.BorderStyle = BorderStyle.FixedSingle;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            pictureBox3.BorderStyle = BorderStyle.Fixed3D;
            pictureBox2.BorderStyle = BorderStyle.FixedSingle;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double weight =Convert.ToDouble( textBox2.Text);
            double height = Convert.ToDouble(textBox1.Text) / 100;

            var bmi = weight / (height * height);

            if (bmi < 18.5)
            {
                label10.Text = label11.Text = "Underweight";
                this.pictureBox4.BackgroundImage = global::Ms2015.Properties.Resources.bmi_underweight_icon;
            }
            else if (bmi < 25)
            {
                label10.Text = label11.Text = "Healthy";
                this.pictureBox4.BackgroundImage = global::Ms2015.Properties.Resources.bmi_healthy_icon;
            }
            else if (bmi < 30)
            {
                label10.Text = label11.Text = "Overweight";
                this.pictureBox4.BackgroundImage = global::Ms2015.Properties.Resources.bmi_overweight_icon;
            }
            else if (bmi > 30)
            {
                label10.Text = label11.Text = "Obese";
                this.pictureBox4.BackgroundImage = global::Ms2015.Properties.Resources.bmi_obese_icon;
            }

            int x = (int)((bmi - 17) * 281 / 15) + 266;
            if (x <= 266)
                x = 266;
            else if (x >= 547)
                x = 547;
            
            panel3.Location =new Point(x, panel3.Location.Y);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
