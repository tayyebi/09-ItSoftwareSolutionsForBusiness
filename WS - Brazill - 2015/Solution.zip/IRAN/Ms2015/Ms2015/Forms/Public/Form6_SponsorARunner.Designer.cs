﻿namespace Ms2015.Forms.Public
{
    partial class Form6_SponsorARunner
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox_name = new System.Windows.Forms.TextBox();
            this.textBox_nameoncard = new System.Windows.Forms.TextBox();
            this.maskedTextBox_cvc = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox_month = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox_year = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox_creditnum = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox5 = new System.Windows.Forms.MaskedTextBox();
            this.uc_Charity1 = new Ms2015.UserControls.Uc_Charity();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Size = new System.Drawing.Size(804, 32);
            // 
            // label3
            // 
            this.label3.Size = new System.Drawing.Size(610, 32);
            // 
            // label2
            // 
            this.label2.Size = new System.Drawing.Size(804, 32);
            this.label2.Text = "Sponsor a runner";
            // 
            // label4
            // 
            this.label4.Size = new System.Drawing.Size(804, 32);
            this.label4.Text = "Please choose the runner you would like to sponsor and the amount you would like " +
    "to sponsor them for. Thank you for your support of the runners and their chariti" +
    "es!";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(671, 0);
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(0, 453);
            this.panel2.Size = new System.Drawing.Size(804, 36);
            // 
            // label1
            // 
            this.label1.Size = new System.Drawing.Size(804, 36);
            this.label1.Text = "56 days 21 hours and 55 minutes until the race starts";
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(29)))), ((int)(((byte)(112)))));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(12, 96);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(365, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "Sponsorship details";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(29)))), ((int)(((byte)(112)))));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(489, 96);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(241, 25);
            this.label6.TabIndex = 4;
            this.label6.Text = "Charity";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(29)))), ((int)(((byte)(112)))));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(489, 207);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(241, 25);
            this.label7.TabIndex = 4;
            this.label7.Text = "Amount to donate";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(29)))), ((int)(((byte)(112)))));
            this.label8.Location = new System.Drawing.Point(12, 140);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(161, 25);
            this.label8.TabIndex = 4;
            this.label8.Text = "Your Name:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(29)))), ((int)(((byte)(112)))));
            this.label9.Location = new System.Drawing.Point(12, 193);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(161, 25);
            this.label9.TabIndex = 4;
            this.label9.Text = "Runner:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(29)))), ((int)(((byte)(112)))));
            this.label10.Location = new System.Drawing.Point(12, 246);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(161, 25);
            this.label10.TabIndex = 4;
            this.label10.Text = "Name on Card:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(29)))), ((int)(((byte)(112)))));
            this.label11.Location = new System.Drawing.Point(12, 299);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(161, 25);
            this.label11.TabIndex = 4;
            this.label11.Text = "Credit Card #:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(29)))), ((int)(((byte)(112)))));
            this.label12.Location = new System.Drawing.Point(12, 352);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(161, 25);
            this.label12.TabIndex = 4;
            this.label12.Text = "Expiry Date:";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(29)))), ((int)(((byte)(112)))));
            this.label13.Location = new System.Drawing.Point(12, 405);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(161, 25);
            this.label13.TabIndex = 4;
            this.label13.Text = "CVC:";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.White;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Font = new System.Drawing.Font("Arial Narrow", 50F);
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(29)))), ((int)(((byte)(112)))));
            this.label15.Location = new System.Drawing.Point(489, 246);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(241, 78);
            this.label15.TabIndex = 4;
            this.label15.Text = "$50";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Arial Narrow", 8F);
            this.button3.Location = new System.Drawing.Point(677, 329);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(53, 23);
            this.button3.TabIndex = 7;
            this.button3.Text = "+";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Arial Narrow", 8F);
            this.button4.Location = new System.Drawing.Point(489, 329);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(53, 23);
            this.button4.TabIndex = 8;
            this.button4.Text = "-";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(474, 379);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(131, 31);
            this.button5.TabIndex = 9;
            this.button5.Text = "Pay now";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(611, 379);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(131, 31);
            this.button6.TabIndex = 9;
            this.button6.Text = "Cancel";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(179, 192);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(198, 28);
            this.comboBox1.TabIndex = 10;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // textBox_name
            // 
            this.textBox_name.Location = new System.Drawing.Point(179, 139);
            this.textBox_name.Name = "textBox_name";
            this.textBox_name.Size = new System.Drawing.Size(198, 26);
            this.textBox_name.TabIndex = 11;
            // 
            // textBox_nameoncard
            // 
            this.textBox_nameoncard.Location = new System.Drawing.Point(179, 245);
            this.textBox_nameoncard.Name = "textBox_nameoncard";
            this.textBox_nameoncard.Size = new System.Drawing.Size(198, 26);
            this.textBox_nameoncard.TabIndex = 11;
            // 
            // maskedTextBox_cvc
            // 
            this.maskedTextBox_cvc.Location = new System.Drawing.Point(179, 404);
            this.maskedTextBox_cvc.Mask = "000";
            this.maskedTextBox_cvc.Name = "maskedTextBox_cvc";
            this.maskedTextBox_cvc.Size = new System.Drawing.Size(100, 26);
            this.maskedTextBox_cvc.TabIndex = 12;
            // 
            // maskedTextBox_month
            // 
            this.maskedTextBox_month.Location = new System.Drawing.Point(179, 351);
            this.maskedTextBox_month.Mask = "00";
            this.maskedTextBox_month.Name = "maskedTextBox_month";
            this.maskedTextBox_month.Size = new System.Drawing.Size(54, 26);
            this.maskedTextBox_month.TabIndex = 12;
            // 
            // maskedTextBox_year
            // 
            this.maskedTextBox_year.Location = new System.Drawing.Point(239, 351);
            this.maskedTextBox_year.Mask = "0000";
            this.maskedTextBox_year.Name = "maskedTextBox_year";
            this.maskedTextBox_year.Size = new System.Drawing.Size(106, 26);
            this.maskedTextBox_year.TabIndex = 12;
            // 
            // maskedTextBox_creditnum
            // 
            this.maskedTextBox_creditnum.Location = new System.Drawing.Point(179, 298);
            this.maskedTextBox_creditnum.Mask = "0000 0000 0000 0000";
            this.maskedTextBox_creditnum.Name = "maskedTextBox_creditnum";
            this.maskedTextBox_creditnum.Size = new System.Drawing.Size(198, 26);
            this.maskedTextBox_creditnum.TabIndex = 12;
            // 
            // maskedTextBox5
            // 
            this.maskedTextBox5.Location = new System.Drawing.Point(560, 329);
            this.maskedTextBox5.Mask = "0000000";
            this.maskedTextBox5.Name = "maskedTextBox5";
            this.maskedTextBox5.PromptChar = ' ';
            this.maskedTextBox5.Size = new System.Drawing.Size(100, 26);
            this.maskedTextBox5.TabIndex = 12;
            this.maskedTextBox5.Text = "50";
            this.maskedTextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.maskedTextBox5.TextChanged += new System.EventHandler(this.maskedTextBox5_TextChanged);
            // 
            // uc_Charity1
            // 
            this.uc_Charity1.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.uc_Charity1.Location = new System.Drawing.Point(487, 126);
            this.uc_Charity1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uc_Charity1.Name = "uc_Charity1";
            this.uc_Charity1.Size = new System.Drawing.Size(243, 39);
            this.uc_Charity1.TabIndex = 13;
            // 
            // Form6_SponsorARunner
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(804, 489);
            this.Controls.Add(this.uc_Charity1);
            this.Controls.Add(this.maskedTextBox_creditnum);
            this.Controls.Add(this.maskedTextBox_year);
            this.Controls.Add(this.maskedTextBox_month);
            this.Controls.Add(this.maskedTextBox5);
            this.Controls.Add(this.maskedTextBox_cvc);
            this.Controls.Add(this.textBox_nameoncard);
            this.Controls.Add(this.textBox_name);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Margin = new System.Windows.Forms.Padding(7, 12, 7, 12);
            this.Name = "Form6_SponsorARunner";
            this.Text = "Sponsor a runner";
            this.Load += new System.EventHandler(this.Form6_SponsorARunner_Load);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.panel2, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.label5, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.label15, 0);
            this.Controls.SetChildIndex(this.label9, 0);
            this.Controls.SetChildIndex(this.label10, 0);
            this.Controls.SetChildIndex(this.label11, 0);
            this.Controls.SetChildIndex(this.label12, 0);
            this.Controls.SetChildIndex(this.label13, 0);
            this.Controls.SetChildIndex(this.label6, 0);
            this.Controls.SetChildIndex(this.label7, 0);
            this.Controls.SetChildIndex(this.button3, 0);
            this.Controls.SetChildIndex(this.button4, 0);
            this.Controls.SetChildIndex(this.button5, 0);
            this.Controls.SetChildIndex(this.button6, 0);
            this.Controls.SetChildIndex(this.comboBox1, 0);
            this.Controls.SetChildIndex(this.textBox_name, 0);
            this.Controls.SetChildIndex(this.textBox_nameoncard, 0);
            this.Controls.SetChildIndex(this.maskedTextBox_cvc, 0);
            this.Controls.SetChildIndex(this.maskedTextBox5, 0);
            this.Controls.SetChildIndex(this.maskedTextBox_month, 0);
            this.Controls.SetChildIndex(this.maskedTextBox_year, 0);
            this.Controls.SetChildIndex(this.maskedTextBox_creditnum, 0);
            this.Controls.SetChildIndex(this.uc_Charity1, 0);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox_name;
        private System.Windows.Forms.TextBox textBox_nameoncard;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_cvc;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_month;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_year;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_creditnum;
        private System.Windows.Forms.MaskedTextBox maskedTextBox5;
        private UserControls.Uc_Charity uc_Charity1;
    }
}