﻿using Ms2015.Masters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Public
{
    public partial class Form13_ListOfCharities : Father
    {
        public Form13_ListOfCharities()
        {
            InitializeComponent();
        }

        private void Form13_ListOfCharities_Load(object sender, EventArgs e)
        {
            foreach (var item in db.Charities.ToList())
            {

                var cha = new UserControls.Uc_CharityItem();
                cha.label1.Text = item.CharityDescription;
                cha.label2.Text = item.CharityName;
                cha.label2.BackColor = Color.FromArgb(253, 193, 0);
                cha.pictureBox1.BackgroundImage = Image.FromFile("CharityLogo/" + item.CharityLogo);
                cha.pictureBox1.BackgroundImageLayout = ImageLayout.Zoom;
                cha.Dock = DockStyle.Top;
                panel3
                    .Controls.Add(cha);
            }
        }
    }
}
