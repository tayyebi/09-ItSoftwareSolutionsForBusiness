﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Public
{
    public partial class BmrPopUp : Masters.Diaglog
    {
        public BmrPopUp()
        {
            InitializeComponent();
        }

        private void BmrPopUp_Load(object sender, EventArgs e)
        {
            // richTextBox1.Text.Select()
        }
    }
}
