﻿using Ms2015.Masters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Public
{
    public partial class Form11_AboutMarathonSkills2015 : Father
    {
        public Form11_AboutMarathonSkills2015()
        {
            InitializeComponent();
        }

        private void Form11_AboutMarathonSkills2015_Load(object sender, EventArgs e)
        {
            textBox1.Text = File.ReadAllText("marathon-skills-2015-marathon-info.txt");
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Hide();
            new Form12_InteractiveMap().ShowDialog();
            Show();
        }
    }
}
