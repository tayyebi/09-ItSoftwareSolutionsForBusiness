﻿using Ms2015.Masters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015
{
    public partial class Form4_RunnerRegistration : Father
    {
        public Form4_RunnerRegistration()
        {
            InitializeComponent();
        }

        private void Form4_RunnerRegistration_Load(object sender, EventArgs e)
        {
            comboBox1.DisplayMember = "Gender1";
            comboBox1.ValueMember = "Gender1";
            comboBox1.DataSource = db.Genders.ToList();

            comboBox2.DisplayMember = "CountryName";
            comboBox2.ValueMember = "CountryCode";
            comboBox2.DataSource = db.Countries.ToList();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            if (
                textBox_name.Text == string.Empty ||
                textBox1.Text == string.Empty ||
                textBox2.Text == string.Empty ||
                textBox3.Text == string.Empty ||
                textBox4.Text == string.Empty ||
                dateTimePicker1.Text == string.Empty ||
                comboBox1.Text == string.Empty ||
                comboBox2.Text == string.Empty
                )
            {
                MessageBox.Show("All fields are required");
                return;
            }




            string password = textBox1.Text;

            string err = string.Empty;

            if (password.Length < 6)
                err += "\r\n - " + "Password must be at least 6 characters";








            char[] uppercaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
            bool upper = false;

            foreach (var a in uppercaseLetters)
            {
                foreach (var b in password.ToCharArray())
                {
                    if (a == b)
                        upper = true;
                }
            }
            if (!upper)
                err += "\r\n - " + "Password must contain at least one upperacase letter";



            char[] numericLetters = "123456789".ToCharArray();
            bool number = false;

            foreach (var a in numericLetters)
            {
                foreach (var b in password.ToCharArray())
                {
                    if (a == b)
                        number = true;
                }
            }
            if (!number)
                err += "\r\n - " + "Password must contain at least one numeric letter";





            char[] sybmolicLetter = "!@#$%^&".ToCharArray();
            bool symbol = false;

            foreach (var a in sybmolicLetter)
            {
                foreach (var b in password.ToCharArray())
                {
                    if (a == b)
                        symbol = true;
                }
            }
            if (!symbol)
                err += "\r\n - " + "Password must contain at least one symbolic letter";







            if (password != textBox2.Text)
            {
                MessageBox.Show("Password and its confirm didn't match");
                return;

            }


            if (err != string.Empty)
            {
                MessageBox.Show(err);
                return;
            }

            var age = DateTime.Now - dateTimePicker1.Value;
            if(age.TotalDays / 365.4 < 10)
            {
                MessageBox.Show("You must have at least 10 years old");
                return;

            }


            var user = new Models.User
            {
              Email = textBox_name.Text,
              FirstName =   textBox3.Text,
              LastName = textBox4.Text,
              RoleId = "R",
              Password = password
            };

            db.Users.Add(user);

            var runner = new Models.Runner
            {
                CountryCode = comboBox2.SelectedValue.ToString(),
                DateOfBirth = dateTimePicker1.Value,
                Email = textBox_name.Text,
                Gender = comboBox1.SelectedValue.ToString(),
                
            };

            db.Runners.Add(runner);


            db.SaveChanges();

            DialogResult = DialogResult.OK;

        }
    }
}
