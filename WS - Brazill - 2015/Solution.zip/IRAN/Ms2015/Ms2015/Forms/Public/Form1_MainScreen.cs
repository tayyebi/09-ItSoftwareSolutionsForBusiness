﻿using Ms2015.Masters;
using System;

namespace Ms2015
{
    public partial class Form1_MainScreen : Adam
    {
        public Form1_MainScreen()
        {
            InitializeComponent();
        }

        private void Form1_MainScreen_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            new Forms.Public.Form6_SponsorARunner().ShowDialog();
            Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            Hide();
            new Forms.Public.Form10_FindOurMoreInfo().ShowDialog();
            Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hide();
            new Form2_CheckRunner().ShowDialog();
            Show();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Hide();
            new Form3_Login().ShowDialog();
            Show();
        }
    }
}
