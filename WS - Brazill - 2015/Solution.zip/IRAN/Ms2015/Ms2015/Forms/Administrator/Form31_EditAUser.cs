﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Administrator
{
    public partial class Form31_EditAUser : Masters.Authorizd
    {

        private string email;
        public Form31_EditAUser(string EMail)
        {
            InitializeComponent();
            email = EMail;
        }

        private void Form30_EditARunner_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            var this_user = db.Users.Where(x => x.Email == email).FirstOrDefault();
            db.Users.Attach(this_user);

            if (
             textBox3.Text == string.Empty ||
             textBox4.Text == string.Empty ||
             comboBox2.Text == string.Empty
             )
            {
                MessageBox.Show("All fields are required");
                return;
            }



            if (textBox1.Text != string.Empty)
            {
                string password = textBox1.Text;

                string err = string.Empty;

                if (password.Length < 6)
                    err += "\r\n - " + "Password must be at least 6 characters";

                char[] uppercaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
                bool upper = false;

                foreach (var a in uppercaseLetters)
                {
                    foreach (var b in password.ToCharArray())
                    {
                        if (a == b)
                            upper = true;
                    }
                }
                if (!upper)
                    err += "\r\n - " + "Password must contain at least one upperacase letter";

                char[] numericLetters = "123456789".ToCharArray();
                bool number = false;

                foreach (var a in numericLetters)
                {
                    foreach (var b in password.ToCharArray())
                    {
                        if (a == b)
                            number = true;
                    }
                }
                if (!number)
                    err += "\r\n - " + "Password must contain at least one numeric letter";


                char[] sybmolicLetter = "!@#$%^&".ToCharArray();
                bool symbol = false;

                foreach (var a in sybmolicLetter)
                {
                    foreach (var b in password.ToCharArray())
                    {
                        if (a == b)
                            symbol = true;
                    }
                }
                if (!symbol)
                    err += "\r\n - " + "Password must contain at least one symbolic letter";

                if (password != textBox2.Text)
                {
                    MessageBox.Show("Password and its confirm didn't match");
                    return;

                }


                if (err != string.Empty)
                {
                    MessageBox.Show(err);
                    return;
                }

                this_user.Password
                     = password;
            }

            this_user.FirstName = textBox3.Text;
            this_user.LastName = textBox4.Text;
            this_user.RoleId = comboBox2.SelectedValue.ToString();


            db.SaveChanges();

            Close();
        }
    }
}
