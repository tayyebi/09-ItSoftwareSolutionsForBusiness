﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Administrator
{
    public partial class Form20_AdministratorMenu : Masters.Authorizd
    {
        public Form20_AdministratorMenu()
        {
            InitializeComponent();
        }

        private void Form20_AdministratorMenu_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The inventory system would be a future add-on to the current system.");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            new Form30_UserManagement().ShowDialog();
            Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Hide();
            new Form28_VolunteerManagement().ShowDialog();
            Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Hide();
            new ManageCharities().ShowDialog();
            Show();
        }
    }
}
