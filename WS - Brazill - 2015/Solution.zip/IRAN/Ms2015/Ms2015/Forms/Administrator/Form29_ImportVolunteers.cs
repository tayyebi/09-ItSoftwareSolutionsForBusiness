﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Administrator
{
    public partial class Form29_ImportVolunteers : Masters.Authorizd
    {
        public Form29_ImportVolunteers()
        {
            InitializeComponent();
        }

        private void Form29_ImportVolunteers_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == String.Empty)
            {
                MessageBox.Show("Please select a file");
                return;
            }

            string[] lines = File.ReadAllLines(textBox2.Text);

            progressBar1.Maximum = lines.Count() - 1 ;
            progressBar1.Value = 0;
            progressBar1.Visible = true;

            int failed = -1;

            foreach (var line in lines)
            {

                try
                {
                    string[] field = line.Split(',');

                    int VolunteerId = Convert.ToInt32(field[0]);
                    string FirstName = field[1];
                    string LastName = field[2];
                    string Country = field[3];
                    string Gender = field[4].ToUpper().StartsWith("M") ? "Male" : "Female";



                    var exist = db.Volunteers.Where(x => x.VolunteerId == VolunteerId).FirstOrDefault();
                    if (exist != null)
                    {
                        db.Volunteers.Attach(exist);

                        exist.CountryCode = Country;
                        exist.FirstName = FirstName;
                        exist.LastName = LastName;
                        exist.Gender = Gender.ToUpper().StartsWith("M") ? "Male" : "Female";
                    }
                    else
                    {
                        db.Volunteers.Add(new Models.Volunteer
                        {

                            CountryCode = Country,
                            FirstName = FirstName,
                            LastName = LastName,
                            Gender = Gender,
                            VolunteerId = VolunteerId
                            


                        });
                    }
                    progressBar1.Value = progressBar1.Value + 1;
                    db.SaveChanges();
                        }
                catch (Exception exp )
                {
                    failed++;
                }
            }
            MessageBox.Show("Done!\r\nFailed Items: " + failed.ToString());


        }
        private void button2_Click(object sender, EventArgs e)
        {
            var ofd = new OpenFileDialog();
            ofd.Filter = "Comma Seperated Values File|*.csv";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                textBox2.Text = ofd.FileName;
            }
        }
    }
}
