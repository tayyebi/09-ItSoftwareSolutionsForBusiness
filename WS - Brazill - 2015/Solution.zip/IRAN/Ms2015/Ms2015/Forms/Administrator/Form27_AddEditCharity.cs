﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Administrator
{
    public partial class Form27_AddEditCharity : Masters.Authorizd
    {
        private OpenFileDialog ofd;
        public Models.Charity this_charity { get; set; }
        public Form27_AddEditCharity()
        {
            InitializeComponent();
        }

        private void Form27_AddEditCharity_Load(object sender, EventArgs e)
        {
            if (this_charity != null)
            {
                textBox1.Text = this_charity.CharityName;
                textBox2.Text = this_charity.CharityDescription;
                pictureBox2.BackgroundImage = Image.FromFile("CharityLogo/" + this_charity.CharityLogo);
                Text = "Edit Charity";
                button2.Text = "Edit";
            }
            else
            {
                Text = "Add Charity";
                button2.Text = "Add";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == string.Empty ||
                textBox2.Text == string.Empty
                )
            {
                MessageBox.Show("Please fill out all boxes");
                return;
            }
            switch (button2.Text)
            {
                case "Edit":
                    var edit_charity = db.Charities.Where(x => x.CharityId == this_charity.CharityId).FirstOrDefault();
                    db.Charities.Attach(edit_charity);
                    if (ofd.SafeFileName.ToString() != string.Empty)
                    {
                        File.Copy(ofd.FileName, "CharityLogo\\" + ofd.SafeFileName, true);
                        edit_charity.CharityLogo = ofd.SafeFileName;
                    }
                    edit_charity.CharityName = textBox1.Text;
                    edit_charity.CharityDescription = textBox2.Text;
                    db.SaveChanges();
                    break;
                case "Add":
                    if (ofd.SafeFileName.ToString() == string.Empty)
                    {
                        MessageBox.Show("Plase select an image");
                        return;
                    }
                    var add_charity = new Models.Charity();
                    add_charity.CharityName = textBox1.Text;
                    add_charity.CharityDescription = textBox2.Text;
                    File.Copy(ofd.FileName, "CharityLogo\\" + ofd.SafeFileName, true);
                    add_charity.CharityLogo = ofd.SafeFileName;
                    db.Charities.Add(add_charity);
                    db.SaveChanges();
                    break;
            }
            Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ofd = new OpenFileDialog();
            ofd.Filter = "JPG|*.jpg|JPEG|*.jpeg|PNG|*.png|GIF|*.gif|BMP|*.bmp";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    pictureBox2.BackgroundImage = Image.FromFile(ofd.FileName);
                    textBox3.Text = ofd.SafeFileName;
                }
                catch
                {
                    MessageBox.Show("Invalid image chosen");
                }
            }
        }
    }
}
