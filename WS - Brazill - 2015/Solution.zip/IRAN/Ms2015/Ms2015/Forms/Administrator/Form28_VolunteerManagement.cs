﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Administrator
{
    public partial class Form28_VolunteerManagement : Masters.Authorizd
    {
        public Form28_VolunteerManagement()
        {
            InitializeComponent();

            comboBox1.SelectedIndex = 0;
        }

        private void Form28_VolunteerManagement_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MyRefresh();
        }

        private void MyRefresh()
        {
            var query_level1 = db.Volunteers.Include("Country").Select(
                x => new
                {
                    x.FirstName,
                    x.LastName,
                    x.Country.CountryName,
                    x.Gender


                }
                ).ToList();


            switch (comboBox1.Text)
            {
                case "First Name":
                    query_level1 = query_level1.OrderBy(x => x.FirstName).ToList();
                    break;
                case "Last Name":
                    query_level1 = query_level1.OrderBy(x => x.LastName).ToList();
                    break;
                case "Country":
                    query_level1 = query_level1.OrderBy(x => x.CountryName).ToList();
                    break;
                case "Gender":
                    query_level1 = query_level1.OrderBy(x => x.Gender).ToList();
                    break;

            }

            dataGridView1.DataSource = query_level1;
            label8.Text = query_level1.Count.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new Form29_ImportVolunteers().ShowDialog();
            MyRefresh();
        }
    }
}
