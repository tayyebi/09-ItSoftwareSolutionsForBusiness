﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Administrator
{
    public partial class Form30_UserManagement : Masters.Authorizd
    {
        public Form30_UserManagement()
        {
            InitializeComponent();
        }

        private void Form30_UserManagement_Load(object sender, EventArgs e)
        {

            comboBox1.DisplayMember = "RoleName";
            comboBox1.ValueMember = "RoleId";
            comboBox1.DataSource = db.Roles.ToList();

            comboBox2.SelectedIndex = 0;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            var query = (

                 from a in db.Users

                 join r in db.Roles
                 on a.RoleId equals r.RoleId

                 where r.RoleId == comboBox1.SelectedValue.ToString()

                 select new { a.FirstName, a.LastName, a.Email, Role = r.RoleName }

                 ).ToList();


            query = query.Where(x => (x.FirstName + " " + x.LastName + " " + x.Email + " " + x.Role).ToUpper().Contains(textBox1.Text.ToUpper())).ToList();


            switch (comboBox2.Text)
            {
                case "First Name":
                    query = query.OrderBy(x => x.FirstName).ToList();
                    break;
                case "Last Name":
                    query = query.OrderBy(x => x.LastName).ToList();
                    break;
                case "E-Mail":
                    query = query.OrderBy(x => x.Email).ToList();
                    break;
                case "Role":
                    query = query.OrderBy(x => x.Role).ToList();
                    break;
            }

            dataGridView1.DataSource = query;
            dataGridView1.Columns[0].DisplayIndex = 4;

            label9.Text = query.Count.ToString();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                var frm = new Form31_EditAUser(dataGridView1.Rows[e.RowIndex].Cells["Email"].Value.ToString());
                frm.label13.Text =
                    dataGridView1.Rows[e.RowIndex].Cells["Email"].Value.ToString();
                frm.textBox3.Text =
                    dataGridView1.Rows[e.RowIndex].Cells["FirstName"].Value.ToString();
                frm.textBox4.Text =
                    dataGridView1.Rows[e.RowIndex].Cells["LastName"].Value.ToString();

                frm.comboBox2.DisplayMember = "RoleName";
                frm.comboBox2.ValueMember = "RoleId";
                frm.comboBox2.DataSource = db.Roles.ToList();

                frm.comboBox2.Text =
                     dataGridView1.Rows[e.RowIndex].Cells["Role"].Value.ToString();
                frm.ShowDialog();

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            var frm = new Form32_AddNewAUser();

            frm.comboBox2.DisplayMember = "RoleName";
            frm.comboBox2.ValueMember = "RoleId";
            frm.comboBox2.DataSource = db.Roles.ToList();


            frm.ShowDialog();
        }
    }
}
