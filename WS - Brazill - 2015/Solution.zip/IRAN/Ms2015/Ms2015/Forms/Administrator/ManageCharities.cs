﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Administrator
{
    public partial class ManageCharities : Masters.Authorizd
    {
        public ManageCharities()
        {
            InitializeComponent();
        }

        List<Models.Charity> charities =
            new List<Models.Charity>();

        private void ManageCharities_Load(object sender, EventArgs e)
        {
            MyRefresh();
        }

        private void MyRefresh()
        {
            charities = db.Charities.ToList();
            dataGridView1.DataSource =
                charities.Select(x => new
                {
                    Logo = File.ReadAllBytes("CharityLogo/" + x.CharityLogo),
                    Name = x.CharityName,
                    Description = x.CharityDescription
                }).ToList();
            dataGridView1.Columns[0].DisplayIndex = 3;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var frm = new Form27_AddEditCharity();
            frm.ShowDialog();
            MyRefresh();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                var frm = new Form27_AddEditCharity();
                frm.this_charity = charities[e.RowIndex];
                frm.ShowDialog();
                MyRefresh();
            }
        }
    }
}
