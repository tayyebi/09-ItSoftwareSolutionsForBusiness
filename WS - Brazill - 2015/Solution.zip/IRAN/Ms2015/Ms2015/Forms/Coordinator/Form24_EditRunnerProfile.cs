﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Coordinator
{
    public partial class Form24_EditRunnerProfile : Masters.Authorizd
    {

        private int runnerID;
        private int registrationId;
        private string email;

        public Form24_EditRunnerProfile(int RunnerId, int RegistrationId, string Email)
        {
            runnerID = RunnerId;
            registrationId = RegistrationId;
            email = Email;

            InitializeComponent();
        }

        private void Form24_EditRunnerProfile_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {

            var user = db.Users.Where(x => x.Email == email).FirstOrDefault();
            db.Users.Attach(user);

            if (
                textBox_name.Text == string.Empty ||
                textBox3.Text == string.Empty ||
                textBox4.Text == string.Empty ||
                dateTimePicker1.Text == string.Empty ||
                comboBox1.Text == string.Empty ||
                comboBox2.Text == string.Empty
                )
            {
                MessageBox.Show("All fields are required");
                return;
            }

            string password = textBox1.Text;

            if (password != string.Empty)
            {
                string err = string.Empty;

                if (password.Length < 6)
                    err += "\r\n - " + "Password must be at least 6 characters";

                char[] uppercaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
                bool upper = false;

                foreach (var a in uppercaseLetters)
                {
                    foreach (var b in password.ToCharArray())
                    {
                        if (a == b)
                            upper = true;
                    }
                }
                if (!upper)
                    err += "\r\n - " + "Password must contain at least one upperacase letter";

                char[] numericLetters = "123456789".ToCharArray();
                bool number = false;

                foreach (var a in numericLetters)
                {
                    foreach (var b in password.ToCharArray())
                    {
                        if (a == b)
                            number = true;
                    }
                }
                if (!number)
                    err += "\r\n - " + "Password must contain at least one numeric letter";

                char[] sybmolicLetter = "!@#$%^&".ToCharArray();
                bool symbol = false;

                foreach (var a in sybmolicLetter)
                {
                    foreach (var b in password.ToCharArray())
                    {
                        if (a == b)
                            symbol = true;
                    }
                }
                if (!symbol)
                    err += "\r\n - " + "Password must contain at least one symbolic letter";

                if (password != textBox2.Text)
                {
                    MessageBox.Show("Password and its confirm didn't match");
                    return;

                }

                if (err != string.Empty)
                {
                    MessageBox.Show(err);
                    return;
                }
                user.Password = password;
            }


            var age = DateTime.Now - dateTimePicker1.Value;
            if (age.TotalDays / 365.4 < 10)
            {
                MessageBox.Show("You must have at least 10 years old");
                return;

            }

            user.FirstName = textBox3.Text;
            user.LastName = textBox4.Text;
            user.RoleId = "R";
            db.SaveChanges();

            var runner = db.Runners.Where(x => x.RunnerId == runnerID).FirstOrDefault();
            db.Runners.Attach(runner);
            runner.RunnerId = runnerID;
            runner.CountryCode = comboBox2.SelectedValue.ToString();
            runner.DateOfBirth = dateTimePicker1.Value;
            runner.Email = textBox_name.Text;
            runner.Gender = comboBox1.SelectedValue.ToString();
            db.SaveChanges();

            var registration = db.Registrations.Where(x => x.RegistrationId == registrationId).FirstOrDefault();
            db.Registrations.Attach(registration);
            registration.RegistrationStatusId = Convert.ToByte(comboBox3.SelectedValue.ToString());
            db.SaveChanges();

            DialogResult = DialogResult.OK;
        }
    }
}