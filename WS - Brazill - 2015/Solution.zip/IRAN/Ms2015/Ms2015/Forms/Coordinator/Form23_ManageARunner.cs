﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Coordinator
{
    public partial class Form23_ManageARunner : Masters.Authorizd
    {
        public Models.View_RunnerDetails current_selected_runner { get; set; }
        int RegistrationId;
        public Form23_ManageARunner(int registrationId)
        {
            InitializeComponent();
            RegistrationId = registrationId;
        }

        private void Form23_ManageARunner_Load(object sender, EventArgs e)
        {
            MyRefresh();
        }

        private void MyRefresh()
        {
            current_selected_runner = db.View_RunnerDetails.Where(x => x.RegistrationId == RegistrationId).FirstOrDefault();

            label20.Text = current_selected_runner.Email;
            label21.Text = current_selected_runner.FirstName;
            label22.Text = current_selected_runner.LastName;
            label23.Text = current_selected_runner.Gender;
            label24.Text = current_selected_runner.DateOfBirth.ToString();
            label25.Text = current_selected_runner.CountryName;
            label26.Text = current_selected_runner.CharityName;
            label27.Text = current_selected_runner.SponsorshipTarget.ToString("$ 00.00");
            label28.Text = "Option " + current_selected_runner.RaceKitOptionId;

            label29.Text = db.RunnerEvents.
                Where(x => x.RunnerId == current_selected_runner.RunnerId)
                .Select(x => x.EventName)
                .ToList().
                Aggregate("", (current, next) => current + "\r\n" + next);



            var rrr = db.RunnerEvents.
                Where(x => x.RunnerId == current_selected_runner.RunnerId)
                .Select(x => x.EventName)
                .ToList();

            if (current_selected_runner.RegistrationStatusId >= 2)
            {
                pictureBox_payment.BackgroundImage =
                    global::Ms2015.Properties.Resources.Check;
                if (current_selected_runner.RegistrationStatusId >= 3)
                {
                    pictureBox_racekit.BackgroundImage =
                         global::Ms2015.Properties.Resources.Check;
                    if (current_selected_runner.RegistrationStatusId >= 4)
                    {
                        pictureBox_attend.BackgroundImage =
                                 global::Ms2015.Properties.Resources.Check;
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Form25_CertificatePreview(current_selected_runner.RunnerId).ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var f = new Form24_EditRunnerProfile(current_selected_runner.RunnerId, current_selected_runner.RegistrationId, current_selected_runner.Email);

            f.comboBox3.DisplayMember = "RegistrationStatus";
            f.comboBox3.ValueMember = "RegistrationStatusId";
            f.comboBox3.DataSource = db.RegistrationStatus.ToList();

            f.comboBox1.DisplayMember = "Gender1";
            f.comboBox1.ValueMember = "Gender1";
            f.comboBox1.DataSource = db.Genders.ToList();

            f.comboBox2.DisplayMember = "CountryName";
            f.comboBox2.ValueMember = "CountryCode";
            f.comboBox2.DataSource = db.Countries.ToList();

            f.comboBox1.SelectedValue = current_selected_runner.Gender;
            f.comboBox2.SelectedValue = current_selected_runner.CountryCode;
            f.comboBox3.SelectedValue = current_selected_runner.RegistrationStatusId;

            f.textBox_name.Text = current_selected_runner.Email;
            f.textBox3.Text = current_selected_runner.FirstName;
            f.textBox4.Text = current_selected_runner.LastName;

            f.dateTimePicker1.Value = DateTime.Parse(current_selected_runner.DateOfBirth.ToString());

            f.ShowDialog();
            MyRefresh();

        }
    }
}
