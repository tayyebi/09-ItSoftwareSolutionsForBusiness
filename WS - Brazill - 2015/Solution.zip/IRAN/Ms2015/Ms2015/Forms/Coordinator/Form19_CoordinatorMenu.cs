﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Coordinator
{
    public partial class Form19_CoordinatorMenu : Masters.Authorizd
    {
        public Form19_CoordinatorMenu()
        {
            InitializeComponent();
        }

        private void Form19_CoordinatorMenu_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Hide();
            new Form22_RunnersManagement().ShowDialog();
            Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Hide();
            new Form21_SponsorshipOverview().ShowDialog();
            Show();
        }
    }
}