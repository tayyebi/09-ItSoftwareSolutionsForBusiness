﻿namespace Ms2015.Forms.Coordinator
{
    partial class Form19_CoordinatorMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Size = new System.Drawing.Size(783, 32);
            // 
            // label3
            // 
            this.label3.Size = new System.Drawing.Size(589, 32);
            // 
            // label2
            // 
            this.label2.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label2.Size = new System.Drawing.Size(783, 75);
            this.label2.Text = "Coordinator Menu";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(0, 107);
            this.label4.Size = new System.Drawing.Size(783, 32);
            this.label4.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(650, 0);
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(0, 475);
            this.panel2.Size = new System.Drawing.Size(783, 36);
            // 
            // label1
            // 
            this.label1.Size = new System.Drawing.Size(783, 36);
            this.label1.Text = "59 days 22 hours and 22 minutes until the race starts";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(29)))), ((int)(((byte)(112)))));
            this.button5.Location = new System.Drawing.Point(413, 239);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(342, 86);
            this.button5.TabIndex = 16;
            this.button5.Text = "Sponsorship";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(29)))), ((int)(((byte)(112)))));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(65, 239);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(342, 86);
            this.button4.TabIndex = 17;
            this.button4.Text = "Runners";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Form19_CoordinatorMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(783, 511);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Margin = new System.Windows.Forms.Padding(9, 18, 9, 18);
            this.Name = "Form19_CoordinatorMenu";
            this.Text = "Coordinator Menu";
            this.Load += new System.EventHandler(this.Form19_CoordinatorMenu_Load);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.panel2, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.button4, 0);
            this.Controls.SetChildIndex(this.button5, 0);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
    }
}