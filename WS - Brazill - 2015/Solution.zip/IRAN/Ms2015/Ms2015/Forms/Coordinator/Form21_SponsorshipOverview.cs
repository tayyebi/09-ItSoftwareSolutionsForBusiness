﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Coordinator
{
    public partial class Form21_SponsorshipOverview : Masters.Authorizd
    {
        public Form21_SponsorshipOverview()
        {
            InitializeComponent();
        }

        public class TheOutput
        {
            public byte[] Logo { get; set; }
            public string Name { get; set; }

            public decimal Amount { get; set; }

        }

        private void Form20_SponsorshipOverview_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 1;
            MyRefresh();
        }

        private void MyRefresh()
        {
            var query = (
                from sponsorship in db.Sponsorships

                join registration in db.Registrations
                on sponsorship.RegistrationId equals registration.RegistrationId

                join charity in db.Charities
                on registration.CharityId equals charity.CharityId

                group sponsorship by new
                {
                    charity.CharityId,
                    charity.CharityName,
                    charity.CharityLogo
                }
                into g

                select g

                );

            List<TheOutput> output = new List<TheOutput>();

            output = query
                .ToList()
                .Select(n =>
                new TheOutput
                {
                    Amount = n.Sum(x => x.Amount),
                    Logo = File.ReadAllBytes("CharityLogo/" + n.Key.CharityLogo),
                    Name = n.Key.CharityName
                }
                )
                .ToList();


            label6.Text = output.Count.ToString();
            label8.Text ="$" +  output.Sum(x => x.Amount).ToString();

            switch (comboBox1.Text)
            {
                case "Name":
                    output = output.OrderBy(x => x.Name).ToList();
                    break;
                case "Amount":
                    output = output.OrderBy(x => x.Amount).ToList();
                    break;
            }

            dataGridView1.DataSource = output;

            (dataGridView1.Columns["Logo"]
                 as DataGridViewImageColumn).ImageLayout
                 = DataGridViewImageCellLayout.Zoom;

                
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MyRefresh();
        }
    }
}
