﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Coordinator
{
    public partial class Form22_RunnersManagement : Masters.Authorizd
    {
        public Form22_RunnersManagement()
        {
            InitializeComponent();

            comboBox3.SelectedIndex = 0;
        }


        List<Models.View_RunnersManagement> runners;

        private void Form22_RunnersManagement_Load(object sender, EventArgs e)
        {
            comboBox1.DisplayMember = "RegistrationStatus";
            comboBox1.ValueMember = "RegistrationStatusId";
            comboBox1.DataSource = db.RegistrationStatus.ToList();

            comboBox2.DisplayMember = "EventName";
            comboBox2.ValueMember = "EventId";
            comboBox2.DataSource = db.Events.Where(x => x.MarathonId == 5).ToList();
        }

        private void button2_Click(object sender, EventArgs e)
        {


            int selected_status =
                Convert.ToInt32(comboBox1.SelectedValue.ToString());

            string selected_event =
                comboBox2.SelectedValue.ToString();



            var blob_query = (
                from runner in db.View_RunnersManagement
                select runner
                )
                .Where(x => x.RegistrationStatusId == selected_status
                && x.EventId == selected_event);

            switch (comboBox3.Text)
            {
                case "First Name":
                    blob_query = blob_query.OrderBy(x => x.FirstName);
                    break;
                case "Last Name":
                    blob_query = blob_query.OrderBy(x => x.LastName);
                    break;
                case "EMail":
                    blob_query = blob_query.OrderBy(x => x.Email);
                    break;
                case "Status":
                    blob_query = blob_query.OrderBy(x => x.RegistrationStatus);
                    break;
            }

            runners = blob_query.ToList();

            dataGridView1.DataSource =
                runners
                .Select(x => new
                {
                    x.FirstName,
                    x.LastName,
                    x.Email,
                    x.RegistrationStatus
                })
                .ToList();

            dataGridView1.Columns[0].DisplayIndex = 4;

            label11.Text = runners.Count.ToString();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0) // Edit
            {
                new Form23_ManageARunner(runners[e.RowIndex].RegistrationId).ShowDialog();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Comma Seperated Values|*.csv";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("First Name,Last Name,Email,Gender,Country,Date of Birth,Registration Status,Race Events");
                foreach (var item in runners)
                {
                    sb.Append($"{item.FirstName},{item.LastName},{item.Email},{item.Gender},{item.CountryName},{item.DateOfBirth}");
                    foreach (var eevent in db.RunnerEvents.Where(z => z.RunnerId == item.RunnerId))
                    {
                        sb.Append(", " + eevent.EventName);
                    }
                    sb.Append("\r\n");
                }

                File.WriteAllText(sfd.FileName, sb.ToString());
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var frm = new EmailPopUp();
            var sb = new StringBuilder();

            foreach (var item in runners)
            {
                sb.Append("\"" + item.FirstName + " " + item.LastName + "\"" + " <" + item.Email + ">; ");
            }

            frm.textBox1.Text = sb.ToString();
            frm.ShowDialog();
        }
    }
}
