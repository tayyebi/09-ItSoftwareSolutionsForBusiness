﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Coordinator
{
    public partial class EmailPopUp : Masters.Diaglog
    {
        public EmailPopUp()
        {
            InitializeComponent();
        }

        private void EmailPopUp_Load(object sender, EventArgs e)
        {

        }
    }
}
