﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Coordinator
{
    public partial class Form25_CertificatePreview : Masters.Authorizd
    {
        private int runnerId;
        private List<Models.View_Certificate> certificate;

        public Form25_CertificatePreview(int RunnerID)
        {
            InitializeComponent();
            runnerId = RunnerID;
        }

        private void Form25_CertificatePreview_Load(object sender, EventArgs e)
        {

            certificate =
                db.View_Certificate.Where(x => x.RunnerId == runnerId).ToList();


            comboBox1.DisplayMember = "EventName";
            comboBox1.ValueMember = "EventId";

            var events = (

                from a in certificate


                group a by new { a.EventName, a.EventId } into g

                select g.Key


                )
                .ToList();

            comboBox1.DataSource = events;


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {


            string event_id = comboBox1.SelectedValue.ToString();

            var this_cert = (



                  from a in certificate


                  group a by new
                  {
                      a.FirstName,
                      a.LastName,
                      a.EventName,
                      a.EventId,
                      a.CountryCode,
                      a.RaceTime,
                      a.MarathonId
                  } into g

                  select g


                ).Where(x => x.Key.EventId == event_id).FirstOrDefault();

            if (comboBox1.SelectedValue != null)
            {

                label6.Text = $"Congratulations {this_cert.Key.FirstName + " " + this_cert.Key.LastName} for running in the {this_cert.Key.EventName}. You ran a time of {this_cert.Key.RaceTime} and got a rank of 183rd!";
            }

        }
    }
}
