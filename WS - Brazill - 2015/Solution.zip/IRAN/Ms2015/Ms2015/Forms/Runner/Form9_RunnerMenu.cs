﻿using Ms2015.Masters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Runner
{
    public partial class Form9_RunnerMenu : Authorizd
    {
        public Form9_RunnerMenu()
        {
            InitializeComponent();
        }

        private void Form9_RunnerMenu_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            new ContactInfo().ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Hide();
            new Form5_RegisterForAnEvent().ShowDialog();
            Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            new Form16_EditYourProfile().ShowDialog();
            Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Hide();
            new Form17_MyRaceRersults().ShowDialog();
            Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Hide();
            new Form18_MySponsorship().ShowDialog();
            Show();

        }
    }
}
