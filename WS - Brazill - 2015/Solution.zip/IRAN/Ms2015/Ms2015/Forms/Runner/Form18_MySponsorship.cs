﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Runner
{
    public partial class Form18_MySponsorship : Masters.Authorizd
    {
        public Form18_MySponsorship()
        {
            InitializeComponent();
        }

        private void Form18_MySponsorship_Load(object sender, EventArgs e)
        {
            var query = (
                from a in db.View_Sponsorship
                where a.RunnerId == Program.RunnerId
                select a
                ).ToList();

            label8.Text = "$" + query.Sum(x => x.Amount).ToString();


            var charity = query.FirstOrDefault();

            label5.Text = charity.CharityName;
            label6.Text = charity.CharityDescription;
            pictureBox2.BackgroundImage = Image.FromFile("CharityLogo\\" + charity.CharityLogo);


            label5.Visible =
                label6.Visible = pictureBox2.Visible = true;


            dataGridView1.DataSource = query.Select(x => new { Name = x.SponsorName, x.Amount }).ToList();
        }
    }
}
