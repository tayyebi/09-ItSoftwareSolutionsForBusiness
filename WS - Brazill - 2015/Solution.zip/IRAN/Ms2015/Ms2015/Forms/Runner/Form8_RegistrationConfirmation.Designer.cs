﻿namespace Ms2015.Forms.Runner
{
    partial class Form8_RegistrationConfirmation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Size = new System.Drawing.Size(685, 32);
            // 
            // label3
            // 
            this.label3.Size = new System.Drawing.Size(491, 32);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 30F);
            this.label2.Size = new System.Drawing.Size(685, 73);
            this.label2.Text = "Thank you for registering as a runner!";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 15F);
            this.label4.Location = new System.Drawing.Point(0, 105);
            this.label4.Size = new System.Drawing.Size(685, 77);
            this.label4.Text = "Thank you for registering as a runner in Marathon Skills 2015!\r\n\r\nYou will be con" +
    "tacted soon about payment.";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(552, 0);
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(0, 452);
            this.panel2.Size = new System.Drawing.Size(685, 36);
            // 
            // label1
            // 
            this.label1.Size = new System.Drawing.Size(685, 36);
            this.label1.Text = "72 days 22 hours and 4 minutes until the race starts";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(294, 250);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(128, 56);
            this.button2.TabIndex = 4;
            this.button2.Text = "OK";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form8_RegistrationConfirmation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(685, 488);
            this.Controls.Add(this.button2);
            this.Name = "Form8_RegistrationConfirmation";
            this.Text = "Thank you for registering as a runner in Marathon Skills 2015!";
            this.Load += new System.EventHandler(this.Form8_RegistrationConfirmation_Load);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.panel2, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.button2, 0);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button2;
    }
}