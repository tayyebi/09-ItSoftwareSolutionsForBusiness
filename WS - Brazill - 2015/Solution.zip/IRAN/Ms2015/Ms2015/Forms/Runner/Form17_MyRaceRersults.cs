﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Runner
{
    public partial class Form17_MyRaceRersults : Masters.Authorizd
    {
        public Form17_MyRaceRersults()
        {
            InitializeComponent();
        }


        private void Form17_MyRaceRersults_Load(object sender, EventArgs e)
        {
            var this_runner = db.Runners.Find(Program.RunnerId);


            string age_cat = string.Empty;
            if (this_runner.Age <= 18)
                age_cat = "Under 18";
            else if (this_runner.Age > 70)
                age_cat = "Over 70";
            else if (this_runner.Age > 56 && this_runner.Age <= 70)
                age_cat = "56 to 70";
            else if (this_runner.Age > 40 && this_runner.Age <= 55)
                age_cat = "40 to 55";
            else if (this_runner.Age > 30 && this_runner.Age <= 39)
                age_cat = "30 to 39";
            else if (this_runner.Age > 18 && this_runner.Age <= 29)
                age_cat = "18 to 29";

            label7.Text = age_cat;
            label9.Text = this_runner.Gender;


            var query = (

                from RaceResult in db.View_MyRaceResults


                join Overall in db.View_MyRaceResults
                on RaceResult.EventId equals Overall.EventId

                group new { RaceResult, Overall } by new

                {
                    Runner = RaceResult.RunnerId,
                    Marathon = RaceResult.MarathonName,
                    Event = RaceResult.EventName,
                    RaceTime = RaceResult.RaceTime,
                    Gender = RaceResult.Gender,
                    Age = RaceResult.Age,
                    AgeCategory = RaceResult.Category
                }
                into race_result

                where race_result.Key.Runner == Program.RunnerId

                select new
                {
                    race_result.Key.Marathon,
                    race_result.Key.Event,
                    RaceTime =
                    (int)(race_result.Key.RaceTime / 3600)
                     + " hours and "

                     + (int)((race_result.Key.RaceTime - (((int)(race_result.Key.RaceTime / 3600)) * 3600)) / 60)
                     + " minutes and "

                     + (race_result.Key.RaceTime - (((int)(race_result.Key.RaceTime / 3600)) * 3600) - (((int)((race_result.Key.RaceTime - (((int)(race_result.Key.RaceTime / 3600)) * 3600)) / 60)) * 60))
                     + " seconds"

                    ,
                    Overall = race_result.Count(x => x.Overall.RaceTime <= race_result.Key.RaceTime),
                    Category = race_result.Count(x => x.Overall.RaceTime <= race_result.Key.RaceTime &&
                    x.Overall.Gender == race_result.Key.Gender
                    && x.Overall.Category == race_result.Key.AgeCategory
                    )
                }


                )

                .ToList();

            dataGridView1.DataSource = query;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            new Forms.Public.Form14_PreviousRaceResults().ShowDialog();
            //Close();
            Show();
        }
    }
}
