﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Runner
{
    public partial class Form5_RegisterForAnEvent : Masters.Authorizd
    {
        public Form5_RegisterForAnEvent()
        {
            InitializeComponent();
            uc_Charity1.label14.Visible = false;
            uc_Charity1.button2.Dock = DockStyle.Fill;
        }


        List<Models.Event> events;
        List<Models.RaceKitOption> racekits;




        private void Form5_RegisterForAnEvent_Load(object sender, EventArgs e)
        {
            events = db.Events.Where(x => x.MarathonId == 5).ToList();
            foreach (var item in events)
            {
                checkedListBox1.Items.Add(item.EventName, false);
            }
            comboBox1.ValueMember = "CharityId";
            comboBox1.DisplayMember = "CharityName";
            comboBox1.DataSource = db.Charities.ToList();


            racekits = db.RaceKitOptions.ToList();
            foreach (var item in racekits)
            {
                var rad = new RadioButton { Text = "Option " + item.RaceKitOptionId + ": " + item.RaceKitOption1, Name = "combo_" + item.RaceKitOptionId };

                rad.CheckedChanged += Rad_CheckedChanged;

                var labl = new Label
                {
                    Text = item.Cost.ToString("$ 00")
                };


                rad.Dock = labl.Dock = DockStyle.Top;

                panel3.Controls.Add(labl);
                panel3.Controls.Add(rad);
            }


        }

        private void Rad_CheckedChanged(object sender, EventArgs e)
        {
            TotalAmount = 0;
            RexaRefresh();

        }
        private void checkedListBox1_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            TotalAmount = 0;

            if (e.NewValue == CheckState.Checked)
                TotalAmount += (decimal)events[e.Index].Cost;
            else if (e.NewValue == CheckState.Unchecked)
                TotalAmount -= (decimal)events[e.Index].Cost;
            RexaRefresh();
        }


        decimal TotalAmount = 0;
        int[] SelectedEvents;
        string SelectedOption;


        private void RexaRefresh()
        {
            SelectedEvents = checkedListBox1.CheckedIndices.Cast<int>().ToArray();

            foreach (var cont in panel3.Controls)
            {
                if (cont.GetType() == typeof(RadioButton))
                {
                    RadioButton rd = (RadioButton)cont;
                    if (rd.Checked == true)
                    {
                        SelectedOption = rd.Name.Substring(6, rd.Name.Length - 1 - 5);
                    }
                }
            }

            foreach (var item in SelectedEvents)
                TotalAmount += (decimal)events[item].Cost;

            if (SelectedOption != null)
                TotalAmount += racekits.Where(x => x.RaceKitOptionId == SelectedOption).FirstOrDefault().Cost;

            label11.Text = TotalAmount.ToString("$ 0.0");

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            uc_Charity1.ChangeCharity(Convert.ToInt32(comboBox1.SelectedValue));
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (SelectedEvents == null
                )
            {
                MessageBox.Show("You must select at least one event");
                return;
            }
            if (SelectedOption == string.Empty)
            {
                MessageBox.Show("You must select at least one race kit option");
                return;
            }
            if (maskedTextBox1.Text == string.Empty)
            {
                MessageBox.Show("You must set a target to raise");
                return;
            }
            string the_target = maskedTextBox1.Text.Replace("$ ", string.Empty).Trim();
            if (Convert.ToInt32(the_target == string.Empty ? "0" : the_target) <= 0)
            {
                MessageBox.Show("Target to raise must be a valid positive integer");
                return;
            }



            var reg_stauts_id = db.RegistrationStatus.Where(z => z.RegistrationStatus == "Registered").FirstOrDefault().RegistrationStatusId;

            var registeration = new Models.Registration
            {
                RegistrationDateTime = DateTime.Now,
                CharityId = Convert.ToInt32(comboBox1.SelectedValue.ToString()),
                Cost = TotalAmount,
                RunnerId = Program.RunnerId,
                RegistrationStatusId = reg_stauts_id,
                RaceKitOptionId = SelectedOption,
                SponsorshipTarget = Convert.ToInt32(the_target),
            };
            db.Registrations.Add(registeration);
            db.SaveChanges();

            foreach (var item in SelectedEvents)
            {
                var registration_event =
                    new Models.RegistrationEvent
                    {
                        EventId = events[item].EventId,
                        RegistrationId = registeration.RegistrationId,
                        BibNumber = 1
                    };
                db.RegistrationEvents.Add(registration_event);
                db.SaveChanges();
            }

            DialogResult = DialogResult.OK;
            Hide();
            new Form8_RegistrationConfirmation().ShowDialog();
            Close();
        }
    }
}
