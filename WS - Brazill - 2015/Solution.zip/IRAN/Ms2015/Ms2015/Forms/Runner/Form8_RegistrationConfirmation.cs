﻿using Ms2015.Masters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Runner
{
    public partial class Form8_RegistrationConfirmation : Authorizd
    {
        public Form8_RegistrationConfirmation()
        {
            InitializeComponent();
        }

        private void Form8_RegistrationConfirmation_Load(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
