﻿using Ms2015.Masters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Forms.Runner
{
    public partial class Form16_EditYourProfile : Authorizd
    {
        public Form16_EditYourProfile()
        {
            InitializeComponent();
        }

        Models.Runner this_runner;
        Models.User this_user;

        private void Form16_EditYourProfile_Load(object sender, EventArgs e)
        {
            comboBox1.DisplayMember = "Gender1";
            comboBox1.ValueMember = "Gender1";
            comboBox1.DataSource = db.Genders.ToList();

            comboBox2.DisplayMember = "CountryName";
            comboBox2.ValueMember = "CountryCode";
            comboBox2.DataSource = db.Countries.ToList();

            this_runner = db.Runners.Find(Program.RunnerId);
            this_user = db.Users.Where(x => x.Email == this_runner.Email).FirstOrDefault();

            label13.Text = this_runner.Email;

            textBox3.Text = this_user.FirstName;
            textBox4.Text = this_user.LastName;

            comboBox1.SelectedValue = this_runner.Gender;
            comboBox2.SelectedValue = this_runner.CountryCode;

            dateTimePicker1.Text = (this_runner.DateOfBirth ??
                DateTime.ParseExact("1998/06/06", "yyyy/MM/dd", CultureInfo.CurrentCulture)).
                ToString(dateTimePicker1.CustomFormat);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            db.Runners.Attach(this_runner);
            db.Users.Attach(this_user);

            if (
             textBox3.Text == string.Empty ||
             textBox4.Text == string.Empty ||
             dateTimePicker1.Text == string.Empty ||
             comboBox1.Text == string.Empty ||
             comboBox2.Text == string.Empty
             )
            {
                MessageBox.Show("All fields are required");
                return;
            }



            if (textBox1.Text != string.Empty)
            {
                string password = textBox1.Text;

                string err = string.Empty;

                if (password.Length < 6)
                    err += "\r\n - " + "Password must be at least 6 characters";








                char[] uppercaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
                bool upper = false;

                foreach (var a in uppercaseLetters)
                {
                    foreach (var b in password.ToCharArray())
                    {
                        if (a == b)
                            upper = true;
                    }
                }
                if (!upper)
                    err += "\r\n - " + "Password must contain at least one upperacase letter";



                char[] numericLetters = "123456789".ToCharArray();
                bool number = false;

                foreach (var a in numericLetters)
                {
                    foreach (var b in password.ToCharArray())
                    {
                        if (a == b)
                            number = true;
                    }
                }
                if (!number)
                    err += "\r\n - " + "Password must contain at least one numeric letter";





                char[] sybmolicLetter = "!@#$%^&".ToCharArray();
                bool symbol = false;

                foreach (var a in sybmolicLetter)
                {
                    foreach (var b in password.ToCharArray())
                    {
                        if (a == b)
                            symbol = true;
                    }
                }
                if (!symbol)
                    err += "\r\n - " + "Password must contain at least one symbolic letter";

                if (password != textBox2.Text)
                {
                    MessageBox.Show("Password and its confirm didn't match");
                    return;

                }


                if (err != string.Empty)
                {
                    MessageBox.Show(err);
                    return;
                }

                this_user.Password
                     = password;
            }

            var age = DateTime.Now - dateTimePicker1.Value;
            if (age.TotalDays / 365.4 < 10)
            {
                MessageBox.Show("You must have at least 10 years old");
                return;

            }




            this_user.FirstName = textBox3.Text;
            this_user.LastName = textBox4.Text;

            this_runner.Gender = comboBox1.SelectedValue.ToString();
            this_runner.CountryCode = comboBox2.SelectedValue.ToString();

            this_runner.DateOfBirth = dateTimePicker1.Value;



            db.Entry(this_runner).State = System.Data.Entity.EntityState.Modified;
            db.Entry(this_user).State = System.Data.Entity.EntityState.Modified;

            db.SaveChanges();

            MessageBox.Show("Save successfuly");
            Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
