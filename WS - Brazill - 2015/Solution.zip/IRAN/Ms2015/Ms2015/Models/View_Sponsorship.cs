namespace Ms2015.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class View_Sponsorship
    {
        [Key]
        [Column(Order = 0)]
        public decimal Amount { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int CharityId { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(100)]
        public string CharityName { get; set; }

        [StringLength(2000)]
        public string CharityDescription { get; set; }

        [StringLength(50)]
        public string CharityLogo { get; set; }

        [Key]
        [Column(Order = 3)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int RunnerId { get; set; }

        [Key]
        [Column(Order = 4)]
        [StringLength(150)]
        public string SponsorName { get; set; }
    }
}
