namespace Ms2015.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class View_RunnerDetails
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int CharityId { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(100)]
        public string CharityName { get; set; }

        [Key]
        [Column(Order = 2)]
        public decimal Cost { get; set; }

        [Key]
        [Column(Order = 3)]
        public decimal SponsorshipTarget { get; set; }

        [Key]
        [Column(Order = 4)]
        [StringLength(1)]
        public string RaceKitOptionId { get; set; }

        [Key]
        [Column(Order = 5)]
        [StringLength(80)]
        public string RaceKitOption { get; set; }

        [Key]
        [Column(Order = 6)]
        [StringLength(100)]
        public string Email { get; set; }

        [StringLength(80)]
        public string FirstName { get; set; }

        [StringLength(80)]
        public string LastName { get; set; }

        [Key]
        [Column(Order = 7)]
        [StringLength(10)]
        public string Gender { get; set; }

        public DateTime? DateOfBirth { get; set; }

        [Key]
        [Column(Order = 8)]
        [StringLength(3)]
        public string CountryCode { get; set; }

        [Key]
        [Column(Order = 9)]
        [StringLength(100)]
        public string CountryName { get; set; }

        [Key]
        [Column(Order = 10)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int RegistrationId { get; set; }

        [Key]
        [Column(Order = 11)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int RunnerId { get; set; }

        [Key]
        [Column(Order = 12)]
        public byte RegistrationStatusId { get; set; }

        [Key]
        [Column(Order = 13)]
        [StringLength(80)]
        public string RegistrationStatus { get; set; }
    }
}
