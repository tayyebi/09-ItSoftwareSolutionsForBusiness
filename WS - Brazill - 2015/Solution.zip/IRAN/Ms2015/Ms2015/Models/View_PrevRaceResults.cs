namespace Ms2015.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class View_PrevRaceResults
    {
        [Key]
        [Column(Order = 0)]
        public byte MarathonId { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(80)]
        public string MarathonName { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(6)]
        public string EventId { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(50)]
        public string EventName { get; set; }

        [Key]
        [Column(Order = 4)]
        [StringLength(10)]
        public string Gender { get; set; }

        public int? Age { get; set; }

        [Key]
        [Column(Order = 5)]
        [StringLength(8)]
        public string Category { get; set; }

        public int? RaceTime { get; set; }

        [StringLength(80)]
        public string FirstName { get; set; }

        [StringLength(80)]
        public string LastName { get; set; }

        [Key]
        [Column(Order = 6)]
        [StringLength(3)]
        public string CountryCode { get; set; }

        [Key]
        [Column(Order = 7)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int RunnerId { get; set; }
    }
}
