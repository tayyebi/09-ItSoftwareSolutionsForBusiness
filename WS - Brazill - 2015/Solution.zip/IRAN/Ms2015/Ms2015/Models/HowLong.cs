namespace Ms2015.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("HowLong")]
    public partial class HowLong
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(50)]
        public string Name { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(3000)]
        public string Image { get; set; }

        [Key]
        [Column(Order = 2)]
        public decimal Value { get; set; }

        [Key]
        [Column(Order = 3)]
        public bool Speed { get; set; }

        [Key]
        [Column(Order = 4)]
        public bool Lenght { get; set; }
    }
}
