﻿using Ms2015.Masters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.UserControls
{
    public partial class Dia_Charity : Diaglog
    {
        public Dia_Charity()
        {
            InitializeComponent();
        }

        private void Dia_Charity_Load(object sender, EventArgs e)
        {

        }
    }
}
