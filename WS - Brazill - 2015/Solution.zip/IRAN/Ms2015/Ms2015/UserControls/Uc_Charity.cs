﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Ms2015.Models;

namespace Ms2015.UserControls
{
    public partial class Uc_Charity : UserControl
    {
        public Uc_Charity()
        {
            InitializeComponent();
        }


        Models.Charity this_charity;

        public void ChangeCharity(int id)
        {
             this_charity = new MainModel().Charities.Find(id);
            label14.Text = this_charity.CharityName;
        }


        private void button2_Click(object sender, EventArgs e)
        {

            var dia = new Dia_Charity();
            dia.pictureBox1.BackgroundImage = Image.FromFile("CharityLogo/" + this_charity.CharityLogo);
            dia.label2.Text = this_charity.CharityName;
            dia.textBox1.Text = this_charity.CharityDescription;
            dia.ShowDialog();

        }
    }
}
