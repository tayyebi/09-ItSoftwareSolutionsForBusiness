﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.UserControls
{
    public partial class Uc_HowLong : UserControl
    {
        public Forms.Public.Form15_HowLongIsAMarathon MyParent { get; set; }

        public Models.HowLong ThisLong { get; set; }


        public Uc_HowLong(Models.HowLong this_long)
        {
            InitializeComponent();

            ThisLong = this_long;
            pictureBox1.BackgroundImage = Image.FromFile("how-long-is-a-marathon-images/" + ThisLong.Image);
            label1.Text = ThisLong.Name;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MyParent.pictureBox2.BackgroundImage = Image.FromFile("how-long-is-a-marathon-images/" + ThisLong.Image);
            MyParent.label7.Text = ThisLong.Name;

            if (ThisLong.Lenght)
            {
                MyParent.label5.Text = $"{ThisLong.Name} are {ThisLong.Value}m in lenght so {(int)(42000 / ThisLong.Value)} would fit into the marathon lenght";

            }
            else
            {

                var hours = 45 / ThisLong.Value;
                var total_seconds = hours * 3600;

                var minutes = (int)(total_seconds / 60);
                var seconds = (int)(total_seconds - (minutes * 60));

                MyParent.label5.Text = $"{ThisLong.Name} travels in {ThisLong.Value}km/h so would complete the marathon in {minutes} minutes and {seconds} seconds";

            }
        }

    }
}
