﻿using Ms2015.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Masters
{
    public partial class Father : Adam
    {
        public MainModel db = new MainModel();
        public Father()
        {
            InitializeComponent();
        }

        private void Father_Load(object sender, EventArgs e)
        {

        }

        private void Father_TextChanged(object sender, EventArgs e)
        {
            label2.Text = Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
