﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015.Masters
{
    public partial class Diaglog : Adam
    {
        public Diaglog()
        {
            InitializeComponent();
        }

        private void Diaglog_Load(object sender, EventArgs e)
        {

        }
    }
}
