﻿using Ms2015.Forms.Administrator;
using Ms2015.Models;
using System;
using System.Collections.Generic;
using System.Linq;

using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms2015
{
    static class Program
    {

        public static Models.User logged_in_user;
        public static int RunnerId = 361;

        [STAThread]
        static void Main()
        {
            Application.ThreadException += (sender, args) => MyError(sender, args.Exception);
            AppDomain.CurrentDomain.UnhandledException += (sender, args) => MyError(sender, args.ExceptionObject as Exception);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
        
            Application.Run(new Form1_MainScreen());
        }

        private static void MyError(object sender, Exception e)
        {
            MessageBox.Show("There was an error: \n\r" + e.Message);
        }
    }
}
