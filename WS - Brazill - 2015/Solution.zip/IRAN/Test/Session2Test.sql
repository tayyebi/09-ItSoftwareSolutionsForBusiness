
select * from RegistrationEvent where RegistrationId >= 5114 order by RegistrationId desc
select * from [Registration] where RegistrationId >= 5114 order by RegistrationId desc


delete Registration where RegistrationId >= 5114
delete RegistrationEvent where RegistrationId >= 5114